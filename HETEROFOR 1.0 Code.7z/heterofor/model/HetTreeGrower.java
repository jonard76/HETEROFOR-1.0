/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model;

import java.io.Serializable;

/**
 * A superclass for the Heterofor tree growth options.
 * 
 * @author M. Jonard - March 2016
 */
public abstract class HetTreeGrower implements Serializable {
	
	public abstract HetTree getTree();
	
	public abstract HetTreeRadiationStatus getRadiationStatus();
	
	public abstract double getParUseEfficiency();

	public abstract double getGrossPrimaryProduction_kgC();

	public abstract double getMaintenanceRespiration_kgC();

	public abstract double getLeafRetranslocation_kgC();

	public abstract double getFineRootRetranslocation_kgC();

	public abstract double getNetPrimaryProduction_kgC();
	
	public abstract HetFunctionalCompartmentsProduction getProduction();
	
	public abstract double getTotalStructuralBiomassToAllocate_kgC();

	public abstract double getDeltaAboveGroundStructuralBiomass_kgC();
	
	public abstract double getDeltaDbh2Height(); //fa-31.10.2018
	
	public abstract double getDeltaG(); //fa-02.11.2018

	public abstract double getDeltaHeight();

	public abstract double getDeltaDbh_cm();

	// fc+mj+fa-14.11.2017
	public abstract HetYearlyTranspirationMemory getYearlyTranspirationMemory();

}
