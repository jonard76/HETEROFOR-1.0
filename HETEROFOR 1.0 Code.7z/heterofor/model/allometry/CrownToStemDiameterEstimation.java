/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.allometry;

import java.io.Serializable;
import java.util.StringTokenizer;

import jeeb.lib.util.Check;


/**
 * An estimation function for the crown to stem diameter ratio.
 * 
 * @author M. Jonard - November 2013
 */
public class CrownToStemDiameterEstimation extends HetSimpleFunction implements Serializable {
	public double a;
	public double b;
	public double c;
	public double d; // mg / g
	
	/**
	 * Constructor.
	 */
	public CrownToStemDiameterEstimation (String str) throws Exception { // e.g. crownToStemDiameterEstimation(1.2;2.23;1.25;520)
		if (!str.startsWith ("crownToStemDiameterEstimation(")) {
			throw new Exception ("CrownToStemDiameterEstimation error, string should start with \"crownToStemDiameterEstimation(\": "+str);
		}
		String s = str.replace ("crownToStemDiameterEstimation(", "");
		s= s.replace (')', ' ');
		s = s.trim ();
		StringTokenizer st = new StringTokenizer (s, " ;");
		a = Check.doubleValue (st.nextToken ());
		b = Check.doubleValue (st.nextToken ());
		c = Check.doubleValue (st.nextToken ());
		d = Check.doubleValue (st.nextToken ());
			
	}
	
	/**
	 * Calculates the allometry for the given values.
	 */
	public double result (double c130_cm) {
		
		double c130Inv = 1d / c130_cm;
		
		double res = a + b * c130_cm + c * c130Inv + d * (c130Inv * c130Inv);
		
		return res;
	}
	
	public String toString () {
		return "crownToStemDiameterEstimation("+a+";"+b+";"+c+";"+d+")";
	}

}
