/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.allometry;

import java.io.Serializable;
import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * An allometry to calculate leaf biomass (kgC).
 * 
 * @author M. Jonard - November 2013
 */
public class LeafBiomassAllometry implements Serializable {

	public double alpha;
	public double beta;
	public double gamma;
	public double leafCarbonConcentration; // mg / g

	/**
	 * Constructor.
	 */
	public LeafBiomassAllometry(String str) throws Exception { // e.g.
																// leafBiomassAllometry(1.2;2.23;1.25;520)
		if (!str.startsWith("leafBiomassAllometry(")) {
			throw new Exception("LeafBiomassAllometry error, string should start with \"leafBiomassAllometry(\": "
					+ str);
		}
		String s = str.replace("leafBiomassAllometry(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		alpha = Check.doubleValue(st.nextToken());
		beta = Check.doubleValue(st.nextToken());
		gamma = Check.doubleValue(st.nextToken());
		leafCarbonConcentration = Check.doubleValue(st.nextToken());

	}

	/**
	 * Calculates the allometry for the given values.
	 */
	public double result(double prevDbh_cm, double newDbh_cm, double mean2CrownRadius_m, double leafRetranslocationRate) {

		double res = alpha * Math.pow(Math.PI * newDbh_cm, beta)
				* Math.pow((2 * mean2CrownRadius_m) / (prevDbh_cm / 100d), gamma) * (leafCarbonConcentration / 1000d)
				/ 1000d;

		// System.out.println ("LeafBiomassAllometry...");
		// System.out.println ("prevDbh_cm:              "+prevDbh_cm);
		// System.out.println ("newDbh_cm:               "+newDbh_cm);
		// System.out.println ("mean2CrownRadius_m:      "+mean2CrownRadius_m);
		// System.out.println
		// ("leafRetranslocationRate: "+leafRetranslocationRate);
		// System.out.println ("alpha:          "+alpha);
		// System.out.println ("beta:           "+beta);
		// System.out.println ("gamma:          "+gamma);
		// System.out.println
		// ("leafCarbonConcentration: "+leafCarbonConcentration);
		// System.out.println ("-> biomass: "+res);
		// System.out.println ();

		return res;
	}

	public String toString() {
		return "leafBiomassAllometry(" + alpha + ";" + beta + ";" + gamma + ";" + leafCarbonConcentration + ")";
	}

}
