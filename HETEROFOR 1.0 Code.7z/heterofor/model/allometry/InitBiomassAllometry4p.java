/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.allometry;

import java.io.Serializable;
import java.util.StringTokenizer;

import jeeb.lib.util.Check;


/**
 * An allometry to calculate initial biomass for some tree compartments.
 * 
 * @author M. Jonard - November 2013
 */
public class InitBiomassAllometry4p implements Serializable {

	public double a;
	public double b;
	public double c;
	public double d;
	
	/**
	 * Constructor.
	 */
	public InitBiomassAllometry4p (String str) throws Exception { // e.g. initBiomassAllometry4p(1.2;2.23;0.04;-1.25)
		if (!str.startsWith ("initBiomassAllometry4p(")) {
			throw new Exception ("InitBiomassAllometry4p error, string should start with \"initBiomassAllometry4p(\": "+str);
		}
		String s = str.replace ("initBiomassAllometry4p(", "");
		s= s.replace (')', ' ');
		s = s.trim ();
		StringTokenizer st = new StringTokenizer (s, " ;");
		a = Check.doubleValue (st.nextToken ());
		b = Check.doubleValue (st.nextToken ());
		c = Check.doubleValue (st.nextToken ());
		d = Check.doubleValue (st.nextToken ());
			
	}
	
	/**
	 * Calculates the allometry for the given values.
	 */
	public double result (double dbh_cm, double height, double mean2CrownRadius_m) {
		return a / 1000000d * Math.pow (dbh_cm,  b) * Math.pow (height, c) * Math.pow ((2 * mean2CrownRadius_m) / (dbh_cm / 100d), d); 
	}

	public String toString() {
		return "initBiomassAllometry4p(" + a + ";" + b + ";" + c  + ";" + d + ")";
	}

}
