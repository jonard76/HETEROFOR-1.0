/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.allometry;

import java.io.Serializable;

/**
 * A superclass for f(x1, x2) functions.
 * 
 * @author F. de Coligny - September 2016
 */
public abstract class HetFunction2Variables implements Serializable {

	/**
	 * A convenient method to decode a HetFunction2Variables
	 */
	static public HetFunction2Variables getFunction(String encodedFunction) throws Exception {
		if (encodedFunction.startsWith("leaflessStemflow")
				|| encodedFunction.startsWith("leavedStemflow")) { // fc+mj+lw-17.10.2016
			return new HetStemflowFunction(encodedFunction);
			
		} else if (encodedFunction.startsWith("seedlingHeightToDiameterRatio")) {
			return new HetSeedlingHeightToDiameterRatio(encodedFunction);
		
		} else if (encodedFunction.startsWith("seedlingHeightGrowth")) {
			return new HetSeedlingHeightGrowth(encodedFunction);
		
		} else {
			throw new Exception("HetFunction2Variables, unknown function: " + encodedFunction);
		}

	}

	/**
	 * A f(x1, x2) method, returns y.
	 */
	public abstract double result(double x1, double x2);

}
