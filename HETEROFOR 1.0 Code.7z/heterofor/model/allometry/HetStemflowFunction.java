/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing the fraction of small branch biomass based on total
 * branch biomass.
 *
 * @author M. Jonard, L. de Wergifosse, F. de Coligny - September 2016
 */
public class HetStemflowFunction extends HetFunction2Variables {
	
	private double c;
	private double d;

	public HetStemflowFunction(String str) throws Exception { // e.g.
		// leaflessStemflow(-9.08;0.16)
		
		// fc+mj+lw-17.10.2016 added leavedStemflow
		if (!str.startsWith("leaflessStemflow(")
				&& !str.startsWith("leavedStemflow(")) {
			throw new Exception(
					"HetStemflowFunction error, string should start with \"leaflessStemflow(\" OR \"leavedStemflow(\": " + str);
		}
		String s = null;
		if (str.startsWith("leaflessStemflow(")) {
			s = str.replace("leaflessStemflow(", "");
		} else {
			s = str.replace("leavedStemflow(", "");
		}
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		c = Check.doubleValue(st.nextToken());
		d = Check.doubleValue(st.nextToken());
		
	}
	
	/**
	 * c130 (cm), rainfall (mm)
	 */
	@Override
	public double result(double c130, double rainfall) {
		
		double y = c * rainfall + d * c130 * rainfall;
		
		y = Math.max(0,  y);
		
		return y;
	}

	public String toString() {
		return "leaflessStemflow(" + c + ";" + d + ")";
	}

}
