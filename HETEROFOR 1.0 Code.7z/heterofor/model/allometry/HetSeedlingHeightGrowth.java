package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing seedling height growth.
 * 
 * @author M. Jonard, B. Ryelandt, F. de Coligny - October 2018
 */
public class HetSeedlingHeightGrowth extends HetFunction2Variables {
	
	private double a;
	private double b;

	/**
	 * Constructor.
	 */
	public HetSeedlingHeightGrowth(String str) throws Exception { 
		
		// e.g. seedlingHeightToDiameterRatio(80.1122;-7.80176;0)
		
		if (!str.startsWith("seedlingHeightGrowth(")) {
			throw new Exception("HetSeedlingHeightGrowth error, string should start with \"seedlingHeightGrowth(\": "
					+ str);
		}
		String s = str.replace("seedlingHeightGrowth(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());

	}
	
	
	
	/**
	 * Returns height increment, m.
	 */
	public double result(double transmittance, double height_m) {
			
		double term = 1d + Math.exp(1 - transmittance / b);
		
		return (a * Math.pow(height_m * 100d, 0.5) * 1d / term) / 100d;
		
	}
	
	
	
	

	public String toString() {
		return "seedlingHeightGrowth(" + a + ";" + b + ")";
	}
	
	

}
