/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.allometry;

import heterofor.model.HetScene;
import heterofor.model.HetTree;

import java.io.Serializable;
import java.util.Random;
import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function for tree height growth based on potential x modifiers approach.
 * 
 * @author M. Jonard, F. de Coligny - December 2016
 */
public class PotentialModifiersHeightGrowth implements Serializable {
	public double P0;
	public double P1;
	public double P2;
	public double P3;
	public double k1;
	public double k2;
	public double k3;
	public double residual; // standard deviation

	/**
	 * Constructor.
	 */
	public PotentialModifiersHeightGrowth(String str) throws Exception { // e.g.
		// PotentialModifiersHeightGrowth(0.112299;0.002982;0;-0.016800;0;0;0.656141;0.139559)
		if (!str.startsWith("PotentialModifiersHeightGrowth(")) {
			throw new Exception(
					"PotentialModifiersHeightGrowth error, string should start with \"PotentialModifiersHeightGrowth(\": "
							+ str);
		}
		String s = str.replace("PotentialModifiersHeightGrowth(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		P0 = Check.doubleValue(st.nextToken());
		P1 = Check.doubleValue(st.nextToken());
		P2 = Check.doubleValue(st.nextToken());
		P3 = Check.doubleValue(st.nextToken());
		k1 = Check.doubleValue(st.nextToken());
		k2 = Check.doubleValue(st.nextToken());
		k3 = Check.doubleValue(st.nextToken());
		residual = Check.doubleValue(st.nextToken());

	}

	/**
	 * Calculates the function for the given value of light competition index.
	 */
	public double result(HetTree tree, HetScene scene, double deltaDbh2Height, double lightCompetitionIndex,
			Random random) {

		double dbh_cm = tree.getDbh();
		double dbh_m = dbh_cm / 100d;
		// double c130 = dbh_cm * Math.PI; // cm
		// double lnC130 = Math.log(c130);
		double height = tree.getHeight(); // m
		double height_cm = height * 100d; // cm

		// Residual standard deviation
		double error = random.nextGaussian() * residual;

		double d2hd2 = deltaDbh2Height / (dbh_m * dbh_m);

		double deltaHeight = (P0 + P1 * d2hd2 + P2 * d2hd2 * d2hd2 + P3 * d2hd2 * d2hd2 * d2hd2)
				* Math.exp(k1 * height_cm / dbh_cm) * Math.exp(k2 * lightCompetitionIndex) * Math.exp(k3 * height)
				+ error;

		// fc+mj-30.4.2015 deltaHeight was bounded, to be adapted later with
		// species specific parameters
		if (deltaHeight > d2hd2) {
			deltaHeight = d2hd2;
		}
		if (deltaHeight < -0.4) {
			deltaHeight = -0.4;
		}
		if (deltaHeight > 0.8) {
			deltaHeight = 0.8;
		}

		return deltaHeight;

	}

	public String toString() {
		return "PotentialModifiersHeightGrowth(" + P0 + ";" + P1 + ";" + P2 + ";" + P3 + ";" + k1 + ";" + k2 + ";" + k3
				+ ";" + residual + ")";
	}

}
