/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing the fraction of coarse branch biomass based on total
 * branch biomass.
 * 
 * @author F. de Coligny - March 2016
 */
public class HetCoarseBranchFracFunction extends HetSimpleFunction {

	private double a;
	private double b;
	
	/**
	 * Constructor.
	 */
	public HetCoarseBranchFracFunction(String str) throws Exception { // e.g.
																	// coarseBranchFracFunction(0.08;-0.26)
		if (!str.startsWith("coarseBranchFracFunction(")) {
			throw new Exception(
					"HetCoarseBranchFracFunction error, string should start with \"coarseBranchFracFunction(\": " + str);
		}
		String s = str.replace("coarseBranchFracFunction(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());

	}
	
	
	@Override
	public double result(double branchBiomass) {
		
		return (a * branchBiomass) / (b + branchBiomass);
		
	}

	public String toString() {
		return "coarseBranchFracFunction(" + a + ";" + b + ")";
	}


}
