/*
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their
 * permission.
 * It can be shared by the modellers of the Capsis co-development community
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory
 * for further information about licenses in Capsis.
 */

package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing sapwood area based on diameter.
 * Units for sapwood area: cm�					// fa-02.03.2017
 *
 * @author M. Jonard, L. de Wergifosse, F. de Coligny - October 2016
 */
public class HetSapwoodArea extends HetSimpleFunction {

	private double a;
	private double b;
	private double c;

	/**
	 * Constructor.
	 */
	public HetSapwoodArea(String str) throws Exception { // e.g.
																	// sapwoodArea(0.08;-0.26;0.32478)
		if (!str.startsWith("sapwoodArea(")) {
			throw new Exception(
					"HetSapwoodArea error, string should start with \"sapwoodArea(\": " + str);
		}
		String s = str.replace("sapwoodArea(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());

	}


	/**
	 * diameter (cm)
	 */
	@Override
	public double result(double diameter) {

		double sa = a + b * diameter + c * diameter * diameter;

		double minSa = diameter / 2d * diameter / 2d * Math.PI - (diameter - 3d) / 2d * (diameter - 3d) / 2d * Math.PI;
		double maxSa = diameter / 2d * diameter / 2d * Math.PI;
		if (diameter < 3)
			minSa = maxSa;

		sa = Math.max(sa, minSa);
		sa = Math.min(sa, maxSa);

		return sa;	// fa-02.03.2017 cm2

	}

	public String toString() {
		return "sapwoodArea(" + a + ";" + b + ";" + c + ")";
	}



}
