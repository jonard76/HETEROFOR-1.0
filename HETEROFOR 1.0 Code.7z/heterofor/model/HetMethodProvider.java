/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import jeeb.lib.util.Log;
import capsis.defaulttype.Tree;
import capsis.kernel.GScene;
import capsis.lib.samsaralight.SLCrownPart;
import capsis.lib.samsaralight.SLLightableTree;
import capsis.util.TreeDbhComparator;
import capsis.util.methodprovider.DdomProvider;
import capsis.util.methodprovider.DgProvider;
import capsis.util.methodprovider.GProvider;
import capsis.util.methodprovider.HdomProvider;
import capsis.util.methodprovider.LAIProvider;
import capsis.util.methodprovider.NProvider;

/**
 * The method provider for Heterofor. Contains calculation methods that can be
 * detected by external tools. Some extensions may evaluate their compatibility
 * with Heterofor by requesting this object.
 * 
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetMethodProvider implements DgProvider, HdomProvider, DdomProvider, LAIProvider, NProvider, GProvider {

	/**
	 * Dg: Diameter of the mean tree (cm) : sqrt (Sum(d^2) / n).
	 */
	public double getDg(GScene stand, Collection trees) {
		try {
			if (trees == null)
				return -1d;

			if (trees.isEmpty())
				return 0d; // if no trees, return 0

			double cum = 0;
			double Dg = 0;
			for (Iterator i = trees.iterator(); i.hasNext();) {
				Tree t = (Tree) i.next();
				double d = t.getDbh();
				cum += d * d;
			}

			if (trees.size() != 0)
				Dg = Math.sqrt(cum / trees.size());

			return Dg;
		} catch (Exception e) {
			Log.println(Log.ERROR, "HetMethodProvider.getDg ()", "Error while computing Dg", e);
			return -1d;
		}
	}

	/**
	 * Dominant height: mean height of the 100 trees / ha with bigger Dbh (cm).
	 */
	public double getHdom(GScene stand, Collection trees) {
		try {
			if (trees == null)
				return -1d;

			if (trees.isEmpty())
				return 0d; // if no trees, return 0

			// Sorting is necessary
			Object[] trees2 = trees.toArray();
			Arrays.sort(trees2, new TreeDbhComparator(false)); // false: sort in
																// descending
																// order / true:
																// sort in
																// ascending
																// order

			double Hdom = 0;
			double sum = 0;
			int dominantTreeNb = (int) (stand.getArea() / 100);
			if (trees2.length < dominantTreeNb)
				dominantTreeNb = trees2.length;

			for (int k = 0; k < dominantTreeNb; k++) {
				Tree t = (Tree) trees2[k];
				sum += t.getHeight();
			}
			if (dominantTreeNb > 0)
				Hdom = sum / dominantTreeNb;

			return Hdom;
		} catch (Exception e) {
			Log.println(Log.ERROR, "HetMethodProvider.getHdom ()", "Error while computing Hdom", e);
			return -1d;
		}
	}

	/**
	 * Canopy base height: mean crown base height of the 100 trees / ha with smaller Dbh
	 * (cm).
	 */
	public double getCanopyBaseHeight(GScene stand, Collection trees) {
		try {
			if (trees == null)
				return -1d;

			if (trees.isEmpty())
				return 0d; // if no trees, return 0

			// Sorting is necessary
			Object[] trees2 = trees.toArray();
			Arrays.sort(trees2, new TreeDbhComparator(true)); // false: sort in
																// descending
																// order / true:
																// sort in
																// ascending
																// order

			double cbh = 0;
			double sum = 0;
			int dominantTreeNb = (int) (stand.getArea() / 100);
			if (trees2.length < dominantTreeNb)
				dominantTreeNb = trees2.length;

			for (int k = 0; k < dominantTreeNb; k++) {
				HetTree t = (HetTree) trees2[k];
				sum += t.getCrownBaseHeight();
			}

			if (dominantTreeNb > 0)
				cbh = sum / dominantTreeNb;

			return cbh;
		} catch (Exception e) {
			Log.println(Log.ERROR, "HetMethodProvider.getCanopyBaseHeight ()",
					"Error while computing canopyBaseHeight", e);
			return -1d;
		}
	}

	/**
	 * Dominant diameter: Quadratic mean Dbh of the 100 trees / ha with bigger
	 * Dbh (cm).
	 */
	public double getDdom(GScene stand, Collection trees) {
		try {
			if (trees == null)
				return -1d;

			if (trees.isEmpty())
				return 0d; // if no trees, return 0

			// Sorting is necessary
			Object[] trees2 = trees.toArray();
			Arrays.sort(trees2, new TreeDbhComparator(false)); // false: sort in
																// descending
																// order / true:
																// sort in
																// ascending
																// order

			double Ddom = 0;
			double cum = 0;
			int dominantTreeNb = (int) (stand.getArea() / 100);
			if (trees2.length < dominantTreeNb)
				dominantTreeNb = trees2.length;

			for (int k = 0; k < dominantTreeNb; k++) {
				Tree t = (Tree) trees2[k];
				double d = t.getDbh();
				cum += d * d;
			}

			if (dominantTreeNb > 0)
				Ddom = Math.sqrt(cum / dominantTreeNb);

			return Ddom;
		} catch (Exception e) {
			Log.println(Log.ERROR, "HetMethodProvider.getDdom ()", "Error while computing Ddom", e);
			return -1d;
		}
	}

	/**
	 * stand LAI
	 * 
	 * @author GL 17-05-2013
	 */
	@Override
	public double getLAI(GScene stand, Collection trees) {
		try {
			if (trees == null)
				return -1d;

			if (trees.isEmpty())
				return 0d; // if no trees, return 0

			double la = 0;
			for (Iterator i = trees.iterator(); i.hasNext();) {
				SLLightableTree t = (SLLightableTree) i.next();

				List<SLCrownPart> crownParts = t.getCrownParts();

				for (SLCrownPart crownPart : crownParts) {
					la += crownPart.getLeafArea();
				}

			}

			return la / stand.getPlot().getArea(); // LAI : m2/m2

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetMethodProvider.getLAI ()", "Error while computing LAI", e);
			return -1d;
		}
	}

	/**
	 * Number of trees (i.e. living trees).
	 */
	@Override
	public double getN(GScene stand, Collection trees) {
		if (trees == null)
			return 0;
		return trees.size();
	}

	/**
	 * Basal area (m2).
	 */
	@Override
	public double getG(GScene stand, Collection trees) {
		if (trees == null)
			return 0;
		double G = 0;
		for (Iterator i = trees.iterator(); i.hasNext();) {
			Tree t = (Tree) i.next();
			double radius = t.getDbh() / 2d; // dbh & radius: cm
			G += Math.PI * radius * radius;
		}
		return G / 10000d; // G: m2
	}

}
