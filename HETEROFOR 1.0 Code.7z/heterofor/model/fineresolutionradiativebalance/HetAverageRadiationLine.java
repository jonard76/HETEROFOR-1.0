/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.fineresolutionradiativebalance;

import java.io.Serializable;

/**
 * A line with average radiation information calculated from corresponding meteo
 * lines from several consecutive years
 * 
 * These lines are stored in an HetAverageRadiation object.
 * 
 * @author F. André, F. de Coligny - April 2017
 */
public class HetAverageRadiationLine implements Serializable {

	public int month;
	public int doy;
	public int hour;
	public double globalRadiation_MJm2; //
	public double diffuseToGlobalRatio; // [0, 1]

	/**
	 * Constructor
	 */
	public HetAverageRadiationLine(int month, int doy, int hour, double radiation_MJm2, double diffuseToGlobalRatio) {
		this.month = month;
		this.doy = doy;
		this.hour = hour;
		
		this.globalRadiation_MJm2 = radiation_MJm2;
		this.diffuseToGlobalRatio = diffuseToGlobalRatio;

	}

	public String toString () {
		return "HetAverageRadiationLine"
				+" month: "+month
				+" doy: "+doy
				+" hour: "+hour
				+" globalRadiation_MJm2: "+globalRadiation_MJm2
				+" diffuseToGlobalRatio: "+diffuseToGlobalRatio;
	}
	
}
