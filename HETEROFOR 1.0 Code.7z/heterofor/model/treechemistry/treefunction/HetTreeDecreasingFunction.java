/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.treechemistry.treefunction;

import heterofor.model.treechemistry.HetTreeCompartment;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A concentration function for an element in a tree compartment.
 * 
 * @author M. Jonard - March 2016
 */
public class HetTreeDecreasingFunction extends HetTreeFunction {

	private double a;
	private double b;
	private double c;
	private double d;
	private double e;
	private double k;
	private double residualSd;
	
	/**
	 * Constructor.
	 */
	public HetTreeDecreasingFunction(String str) throws Exception { // e.g.
		// decreasing(2.15;11.07;-0.76;0;0.64;0;0)
		if (!str.startsWith("decreasing(")) {
			throw new Exception("HetTreeDecreasingFunction error, string should start with \"decreasing(\": " + str);
		}
		String s = str.replace("decreasing(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());
		d = Check.doubleValue(st.nextToken());
		e = Check.doubleValue(st.nextToken());
		k = Check.doubleValue(st.nextToken());
		residualSd = Check.doubleValue(st.nextToken());

	}

	/**
	 * Constructor 2.
	 */
	public HetTreeDecreasingFunction(double a, double b, double c, double d, double e, double k, double residualSd) {
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.e = e;
		this.k = k;
		this.residualSd = residualSd;
	}

	/**
	 * Returns a concentration value for the given compartment.
	 */
	@Override
	public double getValue(HetTreeCompartment compartment) {

		// Later: add a random residual
		return a + b * Math.exp(c * Math.pow(compartment.diameter, e)) + d * compartment.diameter;

	}
	
	public String toString () {
		return "decreasing("+a+";"+b+";"+c+";"+d+";"+e+";"+k+";"+residualSd+")";
	}

}
