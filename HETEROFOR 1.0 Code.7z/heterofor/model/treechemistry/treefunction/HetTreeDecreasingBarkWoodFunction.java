/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.treechemistry.treefunction;

import heterofor.model.treechemistry.HetTreeCompartment;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A concentration function for an element in a tree compartment.
 * 
 * @author M. Jonard - March 2016
 */
public class HetTreeDecreasingBarkWoodFunction extends HetTreeFunction {

	// bark parameters
	private double a1;
	private double b1;
	private double c1;
	private double d1;
	private double e1;
	private double k1;
	private double residualSd1;

	// wood parameters
	private double a2;
	private double b2;
	private double c2;
	private double d2;
	private double e2;
	private double k2;
	private double residualSd2;

	// wood proportion parameters
	private double a;
	private double b;
	private double c;
	
	/**
	 * Constructor.
	 */
	public HetTreeDecreasingBarkWoodFunction(String str) throws Exception { // e.g.
		// decreasingBarkWood(0;10.459;0.023;-0.456;1;-0.211;1.83; 0.748;2.275;-0.24;0;1;-0.365;0.69; 0.936;-0.154;-0.261)
		if (!str.startsWith("decreasingBarkWood(")) {
			throw new Exception("HetTreeDecreasingBarkWoodFunction error, string should start with \"decreasingBarkWood(\": " + str);
		}
		String s = str.replace("decreasingBarkWood(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a1 = Check.doubleValue(st.nextToken());
		b1 = Check.doubleValue(st.nextToken());
		c1 = Check.doubleValue(st.nextToken());
		d1 = Check.doubleValue(st.nextToken());
		e1 = Check.doubleValue(st.nextToken());
		k1 = Check.doubleValue(st.nextToken());
		residualSd1 = Check.doubleValue(st.nextToken());

		a2 = Check.doubleValue(st.nextToken());
		b2 = Check.doubleValue(st.nextToken());
		c2 = Check.doubleValue(st.nextToken());
		d2 = Check.doubleValue(st.nextToken());
		e2 = Check.doubleValue(st.nextToken());
		k2 = Check.doubleValue(st.nextToken());
		residualSd2 = Check.doubleValue(st.nextToken());
		
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());

	}

	/**
	 * Returns a concentration value for the given compartment.
	 */
	@Override
	public double getValue(HetTreeCompartment compartment) {

		double woodProportion = a + b * Math.exp(c * compartment.diameter);
		double barkProportion = 1 - woodProportion;
		
		HetTreeDecreasingFunction f1 = new HetTreeDecreasingFunction(a1, b1, c1, d1, e1, k1, residualSd1);
		double barkConcentration = f1.getValue(compartment);
		
		HetTreeDecreasingFunction f2 = new HetTreeDecreasingFunction(a2, b2, c2, d2, e2, k2, residualSd2);
		double woodConcentration = f2.getValue(compartment);
				
		// Later: add a random residual
		return barkProportion * barkConcentration + woodProportion * woodConcentration; 

	}
	
	public String toString () {
		return "decreasingBarkWood("+a1+";"+b1+";"+c1+";"+d1+";"+e1+";"+k1+";"+residualSd1
				+a2+";"+b2+";"+c2+";"+d2+";"+e2+";"+k2+";"+residualSd2
				+a+";"+b+";"+c+")";
	}

}








