/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.treechemistry;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * HetTreeElement is a chemical element in a tree (mainly nutrients).
 * 
 * @author M. Jonard - February 2016
 */
public class HetTreeElement implements Serializable {

	public static final String C = "C";
	public static final String N = "N";
	public static final String P = "P";
	public static final String S = "S";
	public static final String Ca = "Ca";
	public static final String Mg = "Mg";
	public static final String K = "K";
	public static final String Na = "Na";
	public static final String Al = "Al";
	public static final String Mn = "Mn";
	public static final String Fe = "Fe";
	public static final String Cl = "Cl";
	public static final String Si = "Si";

	public static List<String> elementNames;

	static {
		elementNames = new ArrayList<>();
		elementNames.add(C);
		elementNames.add(N);
		elementNames.add(P);
		elementNames.add(S);
		elementNames.add(Ca);
		elementNames.add(Mg);
		elementNames.add(K);
		elementNames.add(Na);
		elementNames.add(Al);
		elementNames.add(Mn);
		elementNames.add(Fe);
		elementNames.add(Cl);
		elementNames.add(Si);
	}

}
