/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.nutrientlimitation;

import heterofor.model.HetElementState;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetScene;
import heterofor.model.HetSpecies;
import heterofor.model.HetTree;
import heterofor.model.soil.HetHorizon;
import heterofor.model.soil.HetSoil;
import heterofor.model.soilchemistry.HetChemicalElement;
import heterofor.model.treechemistry.HetTreeCompartment;
import heterofor.model.treechemistry.HetTreeElement;

import java.util.HashMap;
import java.util.Map;

/**
 * Compute tree potential uptake.
 * 
 * @author M. Jonard - May 2016
 */
public class PotentialtUptakeCalculator {

	private HetInitialParameters ip;
	private int vegetationPeriod;
	private HetScene refScene;
	private HetTree refTree;

	private HetElementState potentialUptake;

	// key: horizonId_eName -> pot uptake for this tree
	private Map<String, Double> horizonPotentialUptake;

	/**
	 * Constructor.
	 */
	public PotentialtUptakeCalculator(HetInitialParameters ip,
			int vegetationPeriod, HetScene refScene, HetTree refTree) {
		this.ip = ip;
		this.vegetationPeriod = vegetationPeriod;
		this.refScene = refScene;
		this.refTree = refTree;

		potentialUptake = new HetElementState();
		horizonPotentialUptake = new HashMap<>();
	}

	public void execute() throws RuntimeException {

		// Soil chemistry is optional
		if (!refScene.isSoilChemistryAvailable())
			return;

		double area_m2 = refScene.getArea();
		HetSpecies sp = refTree.getSpecies();
		HetSoil soil = refScene.getSoil();

		double waterInwardVelocity = 5.67E-9; // m/s

		HetTreeCompartment frc = refTree
				.getTreeCompartment(HetTreeCompartment.ROOTS_FINE);
		double rootRadius = 0.5 * frc.diameter / 100d; // m
		HetTreeCompartment mc = refTree
				.getTreeCompartment(HetTreeCompartment.MYCORRHIZAE);
		double hyphaRadius = 0.5 * mc.diameter / 100d; // m

		Map<String, Double> nutrientUptakeMap = new HashMap<>();
		Map<String, Double> horizonPotentialUptakeMap = new HashMap<>();

		for (HetHorizon h : soil.getHorizons()) {
			double horizonFineRootLength = h.fineRootProportion
					* refTree.getFineRootLength();
			double horizonHyphaLength = h.fineRootProportion
					* refTree.getHyphaLength();

			Map<String, Double> solutionConcentrations = h
					.getSolutionConcentrations();
			for (String eName : solutionConcentrations.keySet()) {
				HetChemicalElement ce = ip.getChemicalElement(eName);
				double conc = solutionConcentrations.get(eName);

				double horizonDiffusionCoef = 0;

				double nutrientUptake = 0;
				if (ce.diffusionCoefficient > 0 && h.totalFineRootLength > 0) {
					horizonDiffusionCoef = h.meanWaterContent * h.tortuosityFactor
							* ce.diffusionCoefficient; // m2/s

					// Fine root
					double rootInfluenceZoneRadius = Math
							.sqrt((h.volume * area_m2)
									/ (Math.PI * h.totalFineRootLength));
					double rho = rootInfluenceZoneRadius / rootRadius;
					double nu = waterInwardVelocity
							/ ((4d * Math.PI * h.totalFineRootLength * horizonDiffusionCoef) / area_m2);

					double G = geometryFunction(rho, nu);

					nutrientUptake = 2 * Math.PI * horizonFineRootLength
							* horizonDiffusionCoef * (rho * rho - 1) / (2 * G)
							* conc * 60 * 60 * 24 * vegetationPeriod; // g
				}

				// Hypha
				double nutrientUptake2 = 0;
				if (ce.diffusionCoefficient > 0
						&& sp.hyphaToRootLengthRatio > 0
						&& h.totalFineRootLength > 0) {
					double totalHyphaLength = h.totalFineRootLength
							* sp.hyphaToRootLengthRatio;
					double hyphaInfluenceZoneRadius = Math
							.sqrt((h.volume * area_m2)
									/ (Math.PI * totalHyphaLength));
					double rho2 = hyphaInfluenceZoneRadius / hyphaRadius;
					double nu2 = 0; // no waterInward

					double G2 = geometryFunction(rho2, nu2);

					nutrientUptake2 = 2 * Math.PI * horizonHyphaLength
							* horizonDiffusionCoef * (rho2 * rho2 - 1)
							/ (2 * G2) * conc * 60 * 60 * 24 * vegetationPeriod; // g
				}

				// Sum uptake for all eNames
				if (!nutrientUptakeMap.containsKey(eName))
					nutrientUptakeMap.put(eName, 0d);

				double prevUptake = nutrientUptakeMap.get(eName);
				nutrientUptakeMap.put(eName, prevUptake + nutrientUptake
						+ nutrientUptake2);

				String key = "" + h.id + "_" + eName; // here eName is a soil
														// solution name
				horizonPotentialUptakeMap.put(key, nutrientUptake
						+ nutrientUptake2); // g

			}
		}

		try {
			potentialUptake = new HetElementState();

			// "C"
			potentialUptake.setValue(HetTreeElement.C, 0d);

			// "N"
			double Nam = nutrientUptakeMap.get("Nam");
			double Nnit = nutrientUptakeMap.get("Nnit");
			potentialUptake.setValue(HetTreeElement.N, Nam + Nnit);

			// "P"
			double P = nutrientUptakeMap.get("P");
			potentialUptake.setValue(HetTreeElement.P, P);

			// "S"
			double S6 = nutrientUptakeMap.get("S(6)");
			potentialUptake.setValue(HetTreeElement.S, S6);

			// "Ca"
			double Ca = nutrientUptakeMap.get("Ca");
			potentialUptake.setValue(HetTreeElement.Ca, Ca);

			// "Mg"
			double Mg = nutrientUptakeMap.get("Mg");
			potentialUptake.setValue(HetTreeElement.Mg, Mg);

			// "K"
			double K = nutrientUptakeMap.get("K");
			potentialUptake.setValue(HetTreeElement.K, K);

			// "Na"
			double Na = nutrientUptakeMap.get("Na");
			potentialUptake.setValue(HetTreeElement.Na, Na);

			// "Al"
			double Al = nutrientUptakeMap.get("Al");
			potentialUptake.setValue(HetTreeElement.Al, Al);

			// ""Mn"
			double Mn2 = nutrientUptakeMap.get("Mn(2)");
			potentialUptake.setValue(HetTreeElement.Mn, Mn2);

			// "Fe"
			double Fe3 = nutrientUptakeMap.get("Fe(3)");
			potentialUptake.setValue(HetTreeElement.Fe, Fe3);

			// "Cl"
			double Cl = nutrientUptakeMap.get("Cl");
			potentialUptake.setValue(HetTreeElement.Cl, Cl);

			// "Si"
			double Si = nutrientUptakeMap.get("Si");
			potentialUptake.setValue(HetTreeElement.Si, Si);

			// Horizon potential uptake, change from key = soil solution to key
			// = treeElement
			for (int id = 1; id <= 9; id++) {

				String hId = "" + id;

				// "C"
				horizonPotentialUptake.put(hId + "_" + HetTreeElement.C, 0d);

				// "N"
				Nam = horizonPotentialUptakeMap.get(hId + "_" + "Nam");
				Nnit = horizonPotentialUptakeMap.get(hId + "_" + "Nnit");
				horizonPotentialUptake.put(hId + "_" + HetTreeElement.N, Nam
						+ Nnit);

				// "P"
				P = horizonPotentialUptakeMap.get(hId + "_" + "P");
				horizonPotentialUptake.put(hId + "_" + HetTreeElement.P, P);

				// "S"
				S6 = horizonPotentialUptakeMap.get(hId + "_" + "S(6)");
				horizonPotentialUptake.put(hId + "_" + HetTreeElement.S, S6);

				// "Ca"
				Ca = horizonPotentialUptakeMap.get(hId + "_" + "Ca");
				horizonPotentialUptake.put(hId + "_" + HetTreeElement.Ca, Ca);

				// "Mg"
				Mg = horizonPotentialUptakeMap.get(hId + "_" + "Mg");
				horizonPotentialUptake.put(hId + "_" + HetTreeElement.Mg, Mg);

				// "K"
				K = horizonPotentialUptakeMap.get(hId + "_" + "K");
				horizonPotentialUptake.put(hId + "_" + HetTreeElement.K, K);

				// "Na"
				Na = horizonPotentialUptakeMap.get(hId + "_" + "Na");
				horizonPotentialUptake.put(hId + "_" + HetTreeElement.Na, Na);

				// "Al"
				Al = horizonPotentialUptakeMap.get(hId + "_" + "Al");
				horizonPotentialUptake.put(hId + "_" + HetTreeElement.Al, Al);

				// ""Mn"
				Mn2 = horizonPotentialUptakeMap.get(hId + "_" + "Mn(2)");
				horizonPotentialUptake.put(hId + "_" + HetTreeElement.Mn, Mn2);

				// "Fe"
				Fe3 = horizonPotentialUptakeMap.get(hId + "_" + "Fe(3)");
				horizonPotentialUptake.put(hId + "_" + HetTreeElement.Fe, Fe3);

				// "Cl"
				Cl = horizonPotentialUptakeMap.get(hId + "_" + "Cl");
				horizonPotentialUptake.put(hId + "_" + HetTreeElement.Cl, Cl);

				// "Si"
				Si = horizonPotentialUptakeMap.get(hId + "_" + "Si");
				horizonPotentialUptake.put(hId + "_" + HetTreeElement.Si, Si);

			}

		} catch (Exception e) {
			throw e;
			// fc-11.5.2016 e detail is not available in log...
			// throw new Exception ("PotentialUptakeCalculator error", e);
		}

	}

	private double geometryFunction(double rho, double nu) {
		// Geometry function

		if (nu == 0) {

			double a = (1 - 3 * rho * rho) / 4;
			double b = (Math.pow(rho, 4) * Math.log(rho)) / (rho * rho - 1);
			double G = 0.5 * (a + b);

			return G;

		} else {

			double a = 1d / (2 * (nu + 1));
			double b = (1d - rho * rho) / 2d;
			double c = (rho * rho * (Math.pow(rho, 2 * nu) - 1)) / (2 * nu);
			double d = (rho * rho * (Math.pow(rho, 2 * nu) - 1) * (nu + 1))
					/ (2 * nu * (Math.pow(rho, 2 * nu + 2) - 1));
			double e = (1 - Math.pow(rho, 2 * nu + 4) * (nu + 1))
					/ ((2 * nu + 4) * (Math.pow(rho, 2 * nu + 2) - 1));
			double G = a * (b + c + d + e);

			return G;

		}
	}

	public HetElementState getPotentialUptake() {
		return potentialUptake;
	}

	public Map<String, Double> getHorizonPotentialUptake() {
		return horizonPotentialUptake;
	}

}
