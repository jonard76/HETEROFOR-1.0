/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model;

import java.util.List;

import jeeb.lib.util.Import;
import jeeb.lib.util.Record;
import jeeb.lib.util.fileloader.FileLoader;

/**
 * This class allows to store in a map the content of the fructification's observations file.
 * 
 * @author N. Beudez - November 2017
 */
public class HetFructificationFileLoader extends FileLoader {

	public List<HetFructificationRecord> fructificationObservationList;	

	/**
	 * Constructor.
	 */
	public HetFructificationFileLoader() throws Exception {
	
		super();
	}

	@Override
	protected void checks() throws Exception {
	}
	
	/**
	 * An observation of fructification in the file.
	 * 
	 * @author N. Beudez - November 2017
	 */
	@Import
	static public class HetFructificationRecord extends Record {

		public int year;
		public String speciesName;
		public double fruitLitterFall; // kg/ha
		
		public  HetFructificationRecord(String line) throws Exception {

			super(line);
		}
	}
}
