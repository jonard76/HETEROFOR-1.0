/*
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their
 * permission.
 * It can be shared by the modellers of the Capsis co-development community
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory
 * for further information about licenses in Capsis.
 */

package heterofor.model;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import capsis.defaulttype.SpatializedTree;
import capsis.defaulttype.plotofcells.RoundMask;
import capsis.kernel.GScene;
import capsis.kernel.Step;
import capsis.lib.regeneration.RGTree;
import capsis.lib.samsaralight.SLCrownFraction;
import capsis.lib.samsaralight.SLCrownPart;
import capsis.lib.samsaralight.SLEllipsoidalCrownPart;
import capsis.lib.samsaralight.SLLightableTree;
import capsis.lib.samsaralight.SLTreeLightResult;
import capsis.lib.samsaralight.SLTrunk;
import heterofor.model.HetInventoryLoader.TreeConcentrationLine;
import heterofor.model.treechemistry.HetFoliarChemistryThresholds;
import heterofor.model.treechemistry.HetLitterCompartment;
import heterofor.model.treechemistry.HetTreeChemistryDistribution;
import heterofor.model.treechemistry.HetTreeCompartment;
import heterofor.model.treechemistry.HetTreeElement;
import jeeb.lib.defaulttype.SimpleCrownDescription;
import jeeb.lib.defaulttype.TreeWithCrownProfile;
import jeeb.lib.util.Log;
import jeeb.lib.util.Vertex3d;

/**
 * HetTree is the description of a tree in Heterofor. The HetScene contains a
 * list of HetTree objects. Each tree has a unique id in the scene. When
 * creating a scene for a new time step, the trees are 'copied' with the same id
 * and new dimensions are calculated (see HetModel.processEvolution ()).
 *
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetTree extends SpatializedTree implements SLLightableTree, RGTree, SimpleCrownDescription {

	/**
	 * The properties that do not change in time for a tree are located in an
	 * Immutable inner class to save space (e.g. id, x, y, z, species...).
	 *
	 * @see capsis.defaulttype.SpatializedTree.Immutable
	 * @see capsis.defaulttype.Tree.Immutable
	 */
	// public static class Immutable extends SpatializedTree.Immutable {
	// private double[][] crownProfile; // crownRadius relatively to tree height
	//
	// }

	private static final double CROWN_EPSILON = 0.1;
	private static final double DECENTERED_RADIUS_EPSILON = 0.5;

	private static int logTag; // a technical boolean to write in log only few
								// times fc-22.11.2012
	private static int maxLogTag = 5; // a technical boolean to write in log
										// only few times
										// fc-22.11.2012

	private SLTreeLightResult lightResult;

	private List<SLCrownPart> crownParts; // fc+gl+mj+bc - 19.6.2012
	private SLTrunk trunk;

	private HetSpecies species;
	private double hlce; // height at the largest crown extension (m)
	private double hcb; // height of the crown base (m)
	private double rnorth; // crown radius in the North direction (m)
	private double reast; // crown radius in the East direction (m)
	private double rsouth; // crown radius in the South direction (m)
	private double rwest; // crown radius in the West direction (m)
	private String crownForm; // Ec, Ed, Bc, Bd, M
	private double leafLitterAmount_kgOM; // kg OM
	private double branchLitterFall_kgC;
	private double rootLitterFall_kgC;
	private double rootLitterCorrectionFactor; // mj+fa-24.10.2018
	private double fineRootLitterFall_kgC;
	private double mycorrhizaeLitterFall_kgC;
	private double fruitLitterFall_kgC = 0d; // fa+mj-01.12.2017

	// mj+fc-30.4.2015 LAD and T options now in species
	// private int LADoption; // see HetInitialParameters
	// private int Toption; // see HetInitialParameters (GL 21/05/2013)

	private boolean virtual = false; // GL 11/03/13. By default, all created
										// tree are real. During
										// the buffer creation, the created
										// trees are virtual (se in
										// HetModel)
	private int virtualOriginalTreeId; // if virtual is true, id of the tree
										// which was copied to make this virtual
										// tree fc+mj-23.3.2016
	private List<Integer> virtualTreeIdsBasedOnMe;

	private double mean2CrownRadius; // quadratic mean crown radius (cm)

	private double leafBiomass_kgC; // kgC
	private double leafBiomass_kgOM; // kgOM mj+fa-20.03.2018
	private double branchBiomass_kgC; // kgC
	private double stemBiomass_kgC; // kgC
	private double rootBiomass_kgC; // kgC = belowGroundBiomass
	private double fineRootBiomass_kgC; // kgC
	private double mycorrhizaeBiomass_kgC; // kgC

	private double defoliation; // %, kgC/100kgC, fc+mj-9.3.2017

	private double fineRootCConcentration;
	private double SRL; // Specific root length (m/g)

	private double fineRootLength; // m
	private double fineRootVolume; // m3
	private double fineRootDiameter; // cm

	private double stemVolume;
	private double stemCylinderDiameter; // cm

	private double hyphaLength; // m

	// Variables calculated during growth, based on the past year production
	// (can be exported in a
	// file)

	private double interceptedParRadiation;
	private double lightCompetitionIndex;
	private double parUseEfficiency;

	private double grossPrimaryProduction_kgC;
	private double maintenanceLeafRespiration_kgC; // fc-et-al-20.1.2017
													// (yearly)

	// private double stemLivingFraction;
	private double maintenanceRespiration_kgC;
	private double leafRetranslocation_kgC;
	private double fineRootRetranslocation_kgC;
	private double netPrimaryProduction_kgC;

	private double leafBiomassProduction_kgC;
	private double fineRootBiomassProduction_kgC;
	private double mycorrhizaeBiomassProduction_kgC;

	private double totalStructuralBiomassToAllocate_kgC;
	// private double branchLitterFall_kgC;
	// private double rootLitterFall_kgC;
	private double deltaAboveGroundStructuralBiomass_kgC;
	private double deltaDbh2Height; // fa-31.10.2018
	private double deltaHeight; // fa-02.11.2018
	private double deltaG; // fa-02.11.2018
	private double residual;
	private double stemAllocationCoefficient;
	private double rootAllocationCoefficient;
	private double branchAllocationCoefficient;

	// Last dbh increment
	private double deltaDbh_cm = -1; // cm

	// fc+mj-29.2.2016 Added tree compartments
	private Map<String, HetTreeCompartment> treeCompartments; // key is
																// compartment
																// name
	// fc+mj-29.2.2016 Added litter compartments
	private Map<String, HetLitterCompartment> litterCompartments; // key is
																	// compartment
	// name

	// For each element known by HetFoliarChemistryThresholds for this species,
	// gives the matching nutrient status
	private HetElementState nutrientStatusMap;

	private HetElementState potentialUptake; // g
	// key: horizonId_eName -> potential uptake for this tree
	private Map<String, Double> horizonPotentialUptake; // g
	private HetElementState requirement; // g
	private HetElementState retranslocation; // g
	private HetElementState demand; // g

	// fc+mj-7.12.2016
	private HetElementState deficientDemand; // g
	private HetElementState optimalDemand; // g

	private HetElementState actualUptake; // g

	private double fineRootToFoliageRatio; // fc+mj-28.9.2016

	private double nppToGppRatio; // fc+mj-28.9.2016
	private double nppToGppRatioForNextYear; // fa-29.10.2018, used when nppToGppRatio = f(DdIndex)

	// private double transpiration; // l

	// nb-18.09.2017
	private double yearlyTranspiration;
	private double yearlyPotentialTranspiration;
	
	//fa-06.12.2018
	double LADup = 0d;
	double LADdown = 0d;
	double crownVolumeUp = 0d;
	double crownVolumeDown = 0d;
	double uflb = 0d;
	double SLAup = 0d;
	double SLAdown = 0d;

	/**
	 * Constructor for a new HetTree (first time). The Immutable object is
	 * created in the superclasses and completed for this level with
	 * crownProfile.
	 */
	public HetTree(int id, GScene scene, HetSpecies species, double dbh, double height, double hlce, double hcb,
			double rnorth, double reast, double rsouth, double rwest, double x, double y, double z, String crownForm,
			HetTreeChemistryDistribution treeChemistryDistribution,
			HetFoliarChemistryThresholds foliarChemistryThresholds,
			List<TreeConcentrationLine> treeConcentrationLines) {

		super(id, scene, 0, height, dbh, false, x, y, z); // age = 0, marked =
															// false (unused)

		this.species = species;
		this.hlce = hlce;
		this.hcb = hcb;
		this.rnorth = rnorth;
		this.reast = reast;
		this.rsouth = rsouth;
		this.rwest = rwest;
		this.crownForm = crownForm;

		// fc+mj-12.9.2017
//		nppToGppRatio = species.nppToGppRatio; //fa-29.10.2018: commented, not applicable if nppToGpp = f(DdIndex)

		if (reast == 0)
			this.reast += CROWN_EPSILON;
		if (rnorth == 0)
			this.rnorth += CROWN_EPSILON;
		if (rwest == 0)
			this.rwest += CROWN_EPSILON;
		if (rsouth == 0)
			this.rsouth += CROWN_EPSILON;
		if (getHeight() == hlce)
			this.hlce -= CROWN_EPSILON;
		if (hlce == hcb)
			this.hcb -= CROWN_EPSILON;

		// this.leafLitterAmount = (species.leafLitterAmountAlpha * Math.pow
		// (Math.PI * dbh,
		// species.leafLitterAmountBeta)) / 1000d;

		// this.LADoption = LADoption;
		// this.Toption = Toption;

		lightResult = new SLTreeLightResult(this);

		mean2CrownRadius = Math.sqrt((rnorth * rnorth + reast * reast + rsouth * rsouth + rwest * rwest) / 4d);

		// Biomass treeCompartments
		leafBiomass_kgC = species.leafBiomassAllometry.result(dbh, dbh, mean2CrownRadius,
				species.leafRetranslocationRate);

		// fc+mj+fa-14.11.2017 initBranchBiomassAllometry and
		// initStemBiomassAllometry may be null
		// (NA in species file), specific code if so
		double aboveGroundStructuralBiomass_kgC = 0;
		if (species.initBranchBiomassAllometry == null && species.initStemBiomassAllometry == null) {
			// default biomass initialisation
			double delevoyHeight = getHDelevoy(species, dbh, height);
			double dbh_m = dbh / 100d;
			stemBiomass_kgC = species.stemFormFactor * (dbh_m * dbh_m * delevoyHeight)
					* (species.stemVolumetricMass * 0.5);
			aboveGroundStructuralBiomass_kgC = (species.aboveBiomassAlpha
					+ species.aboveBiomassBeta * Math.pow(dbh_m * dbh_m * height, species.aboveBiomassGamma)) * 0.5d;
			branchBiomass_kgC = aboveGroundStructuralBiomass_kgC - stemBiomass_kgC;

		} else {
			// functions from the species file
			branchBiomass_kgC = species.initBranchBiomassAllometry.result(dbh, height, mean2CrownRadius);
			stemBiomass_kgC = species.initStemBiomassAllometry.result(dbh, height, mean2CrownRadius);
			aboveGroundStructuralBiomass_kgC = branchBiomass_kgC + stemBiomass_kgC;
		}

		// Stem
		// double stemBiomass_kgOM = stemBiomass_kgC / 0.5; // kg organic matter
		// stemVolume = stemBiomass_kgOM / species.stemVolumetricMass; // m3
		// double delevoyHeight = getHDelevoy(species, dbh, height);
		// stemCylinderDiameter = Math.sqrt((4d * stemVolume) / (Math.PI *
		// delevoyHeight)) * 100d; // cm

		// Roots / Fine roots

		// fc+mj-9.12.2016
		fineRootToFoliageRatio = 1;

		rootBiomass_kgC = species.rootToShootRatio * aboveGroundStructuralBiomass_kgC;
		fineRootBiomass_kgC = leafBiomass_kgC;

		// fineRootCConcentration value does not matter much at init time
		fineRootCConcentration = 500;
		double fineRootBiomass_gOM = (fineRootBiomass_kgC * 1000d) / (fineRootCConcentration / 1000d);

		// TMP value for SRL at init time
		SRL = (species.minSRL + species.maxSRL) / 2d;

		fineRootLength = fineRootBiomass_gOM * SRL; // m
		fineRootVolume = (fineRootBiomass_gOM / 1000d) / species.rootVolumetricMass; // m3
		fineRootDiameter = Math.sqrt(fineRootVolume / (Math.PI * fineRootLength)) * 2 * 100; // cm

		// Mycorrhizae
		hyphaLength = fineRootLength * species.hyphaToRootLengthRatio; // m
		double mycorrhizaeBiomass_kgOM = (hyphaLength / (species.specificHyphaLength * 1000d)) / 1000d; // kgOM
		mycorrhizaeBiomass_kgC = mycorrhizaeBiomass_kgOM * 0.5;

		// fc+mj-2.3.2016
		// Fine roots
		HetTreeCompartment fineRootCompartment = new HetTreeCompartment(HetTreeCompartment.ROOTS_FINE);
		fineRootCompartment.init(this);
		// We use a tmp fine root compartment to get the fine root C
		// concentration
		fineRootCConcentration = treeChemistryDistribution.getConcentration(species.getName(), fineRootCompartment,
				HetTreeElement.C);

		// Before SRL
		// Create the tree treeCompartments read in the inventory file, at least
		// LEAVES_UPPER_CURRENT
		for (TreeConcentrationLine l : treeConcentrationLines) {
			if (l.speciesName.equals(species.getName())) {

				HetTreeCompartment treeCompartment = l.getTreeCompartment();
				this.addTreeCompartment(treeCompartment);

			}
		}

		// Before SRL
		this.updateNutrientStatusMap(foliarChemistryThresholds);

		// Compute specific root length based on nutrient status
		SRL = fineRootSensitivityToNutrientStatus(foliarChemistryThresholds, species.minSRL, species.maxSRL);

		updateStemAndLitters(getLeafCarbonConcentration());

	}

	/**
	 * At simulation initialisation time, tree initialisation is finished in
	 * different steps. For newly created trees (recruitment), this init can be
	 * done in one single pass by calling this method.
	 */
	public void finishTreeInitialisation(HetInitialParameters ip) throws Exception {

		HetScene scene = (HetScene) this.getScene();

		createSLStructures(ip, scene);

		initTreeCompartments(ip);

		createLitterCompartments(scene, ip);

	}

	// Finish trees construction: SLCrownParts, LAD, SLTrunk if needed
	public void createSLStructures(HetInitialParameters ip, HetScene scene) {
		// fc-29.6.2017
		if (ip.samsaFileLoader.isTrunkInterception())
			this.createSLTrunk();

		this.createSLCrownParts(ip.LADNeighbourhoodDistance, scene); // including
																		// LAD
	}

	/**
	 * Initialisation time: for all the loaded (or recruited) trees, init their
	 * tree compartments with mineral element concentrations.
	 */
	public void initTreeCompartments(HetInitialParameters ip) throws Exception {

		// Get the mandatory LEAVES_UPPER_CURRENT compartment
		HetTreeCompartment luc = null;
		for (HetTreeCompartment c : this.getTreeCompartments()) {

			if (c.name.equals(HetTreeCompartment.LEAVES_UPPER_CURRENT)) {
				luc = c;
				break;
			}
		}
		if (luc == null)
			throw new Exception(
					"HetInitialParameters, could not find the mandatory LEAVES_UPPER_CURRENT compartment for tree "
							+ this.getId() + " (" + this.getSpecies().getName() + ")");

		this.createTreeCompartments(luc, ip);

	}

	/**
	 * Creates the missing compartments for the given tree, based on
	 * LEAVES_UPPER_CURRENT concentrations. Note: the given tree must contain
	 * the luc compartment.
	 */
	public void createTreeCompartments(HetTreeCompartment luc, HetInitialParameters ip) {
		String speciesName = this.getSpecies().getName();

		Set<String> existingCompartmentNames = new HashSet<>();
		for (HetTreeCompartment c : this.getTreeCompartments()) {

			// Init existing compartment biomass and diameter
			c.init(this);

			existingCompartmentNames.add(c.name);
		}

		for (String cName : HetTreeCompartment.compartmentNames) {
			if (!existingCompartmentNames.contains(cName)) {
				// Create the missing compartment

				HetTreeCompartment newCompartment = new HetTreeCompartment(cName);

				// Init new compartment biomass and diameter
				newCompartment.init(this);

				this.addTreeCompartment(newCompartment);

				for (String eName : HetTreeElement.elementNames) {

					double lucConc = luc.getConcentration(eName);
					double lucMeanConc = ip.treeChemistryDistribution.getConcentration(speciesName, luc, eName);

					double conc = ip.treeChemistryDistribution.getConcentration(speciesName, newCompartment, eName);

					double deviationCoefficient = 1;
					if (lucMeanConc != 0) {
						deviationCoefficient = 1 + (lucConc - lucMeanConc) / lucMeanConc;
					}
					double newConc = conc * deviationCoefficient;

					newCompartment.setConcentration(eName, newConc);

				}

			}
		}

	}

	/**
	 * Creates the litter compartments for an alive tree, based on
	 * LEAVES_UPPER_CURRENT. fc+mj-11.5.2016
	 */
	public void createLitterCompartments(HetScene scene, HetInitialParameters ip) {

		createLitterCompartment(scene, HetLitterCompartment.LEAVES, this.getLeafLitterAmount_kgOM() * 0.5, ip);
		createLitterCompartment(scene, HetLitterCompartment.BRANCHES, this.getBranchLitterFall_kgC(), ip);
		createLitterCompartment(scene, HetLitterCompartment.ROOTS, this.getRootLitterFall_kgC(), ip);
		createLitterCompartment(scene, HetLitterCompartment.FINE_ROOTS, this.getFineRootLitterFall_kgC(), ip);
		createLitterCompartment(scene, HetLitterCompartment.MYCORRHIZAE, this.getMycorrhizaeLitterFall_kgC(), ip);
		createLitterCompartment(scene, HetLitterCompartment.FRUITS, this.getFruitLitterFall_kgC(), ip); // fa+mj-01.12.2017

	}

	/**
	 * Basic method to create a litter compartment with the given name and
	 * biomass in the given tree. The tree must contain its luc (i.e.
	 * LEAVES_UPPER_CURRENT tree compartment).
	 */
	public void createLitterCompartment(HetScene scene, String compartmentName, double biomass_kgC,
			HetInitialParameters ip) {

		HetLitterCompartment litterCompartment = new HetLitterCompartment(compartmentName);
		litterCompartment.setBiomass(biomass_kgC);

		String speciesName = this.getSpecies().getName();
		HetTreeCompartment luc = this.getTreeCompartment(HetTreeCompartment.LEAVES_UPPER_CURRENT); // i.e.
																									// luc

		for (String eName : HetTreeElement.elementNames) {

			double conc = ip.litterChemistryDistribution.getConcentration(speciesName, litterCompartment, eName);

			double lucConc = luc.getConcentration(eName);
			double lucMeanConc = ip.treeChemistryDistribution.getConcentration(speciesName, luc, eName);

			double deviationCoefficient = 1;
			if (lucMeanConc != 0) {
				deviationCoefficient = 1 + (lucConc - lucMeanConc) / lucMeanConc;
			}
			double newConc = conc * deviationCoefficient;

			if (scene.isInitialScene()) {
				// Is there site data overriding the species file data ?
				String key = speciesName + '.' + compartmentName;
				HetInventoryLoader.LitterConcentrationLine litterConcentration = ip.litterConcentrationMap.get(key);
				if (litterConcentration != null) {
					double siteConc = litterConcentration.getLitterCompartment(this).getConcentration(eName);
					newConc = siteConc;
				}
			}

			litterCompartment.setConcentration(eName, newConc);
		}

		this.addLitterCompartment(litterCompartment);

	}

	public double getLeafCarbonConcentration() {
		return this.getTreeCompartment(HetTreeCompartment.LEAVES_UPPER_CURRENT).getConcentration(HetTreeElement.C);
	}

	public double getLitterBiomass_kgC(String litterCompartmentName) {

		if (litterCompartmentName.equals(HetLitterCompartment.LEAVES)) {
			return getLeafLitterAmount_kgOM() * 0.5;
		} else if (litterCompartmentName.equals(HetLitterCompartment.BRANCHES)) {
			return getBranchLitterFall_kgC();
		} else if (litterCompartmentName.equals(HetLitterCompartment.ROOTS)) {
			return getRootLitterFall_kgC();
		} else if (litterCompartmentName.equals(HetLitterCompartment.FINE_ROOTS)) {
			return getFineRootLitterFall_kgC();
		} else if (litterCompartmentName.equals(HetLitterCompartment.MYCORRHIZAE)) {
			return getMycorrhizaeLitterFall_kgC();
		} else if (litterCompartmentName.equals(HetLitterCompartment.FRUITS)) { // fa+mj-01.12.2017
			return getFruitLitterFall_kgC();
		}
		return -1; // error

	}

	public void updateBiomasses(HetFunctionalCompartmentsProduction production) {

		setLeafBiomass(production.newLeafBiomass_kgC);
		setLeafBiomassProduction_kgC(production.newLeafBiomassProduction_kgC);
		setFineRootBiomass(production.newFineRootBiomass_kgC);
		setFineRootBiomassProduction_kgC(production.newFineRootBiomassProduction_kgC);
		setFineRootLength(production.newFineRootLength);
		setFineRootVolume(production.newFineRootVolume);
		setFineRootDiameter(production.newFineRootDiameter);
		setHyphaLength(production.newHyphaLength);
		setMycorrhizaeBiomass_kgC(production.newMycorrhizaeBiomass_kgC);
		setMycorrhizaeBiomassProduction_kgC(production.newMycorrhizaeBiomassProduction_kgC);

		updateStemAndLitters(getLeafCarbonConcentration());

	}

	public void updateStemAndLitters(double leafCarbonConcentration) {

		HetSpecies treeSpecies = this.getSpecies();

		//
		double stemBiomass_kgOM = stemBiomass_kgC / 0.5; // kg organic matter
		stemVolume = stemBiomass_kgOM / species.stemVolumetricMass; // m3
		double delevoyHeight = getHDelevoy(species, dbh, height);
		stemCylinderDiameter = Math.sqrt((4d * stemVolume) / (Math.PI * delevoyHeight)) * 100d; // cm

		// fc+mj+br-1.10.2018 removed leafCarbonConcentration from species file,
		// now passed as an argument

		this.leafLitterAmount_kgOM = leafBiomass_kgC * (1 - species.leafRetranslocationRate)
				* (1000d / leafCarbonConcentration);
		// mj+fa-20.03.2018
		this.leafBiomass_kgOM = leafBiomass_kgC * (1000d / leafCarbonConcentration);

		// branchLitterFall_kgC = species.branchRelativeLossRate *
		// branchBiomass_kgC;

		// if (this.getSpecies().getId() == 1) // Oak
		// branchLitterFall_kgC = species.branchLitterP1 *
		// this.lightCompetitionIndex / 0.6 * Math.pow(2 * this.mean2CrownRadius
		// * 100d , species.branchLitterP2); //fa+mj-01.12.2017.
		// else if (this.getSpecies().getId() == 3) // Hornbeam
		// branchLitterFall_kgC = species.branchLitterP1 * Math.pow(dbh ,
		// species.branchLitterP2); //fa+mj-01.12.2017.
		// else // Beech and others
		// branchLitterFall_kgC = species.branchLitterP1 *
		// this.lightCompetitionIndex / treeSpecies.meanLightCompetitionIndex *
		// Math.pow(dbh , species.branchLitterP2); //fa+mj-01.12.2017.
		// branchLitterFall_kgC = Math.min(branchLitterFall_kgC,
		// branchBiomass_kgC / 3d); //mj+fa-06.12.2017

		if (this.getSpecies().getId() == 1) // Oak
			branchLitterFall_kgC = species.branchLitterP1 * this.lightCompetitionIndex
					/ treeSpecies.meanLightCompetitionIndex * Math.pow(dbh, species.branchLitterP2)
					* Math.pow((2 * this.mean2CrownRadius * 100d) / dbh, species.branchLitterP2);
		else // Beech and others
			branchLitterFall_kgC = species.branchLitterP1 * this.lightCompetitionIndex
					/ treeSpecies.meanLightCompetitionIndex * Math.pow(dbh, species.branchLitterP2);
		branchLitterFall_kgC = Math.min(branchLitterFall_kgC, branchBiomass_kgC / 6d); // mj+fa-06.12.2017

		// rootLitterFall_kgC = species.rootRelativeLossRate * rootBiomass_kgC;
		double rootRelativeLossRate = species.rootRelativeLossRate;
		if (branchBiomass_kgC != 0d)
			rootRelativeLossRate = branchLitterFall_kgC / branchBiomass_kgC; // fa+mj-01.12.2017
		rootLitterFall_kgC = rootRelativeLossRate * rootBiomass_kgC; // fa+mj-01.12.2017

		fineRootLitterFall_kgC = fineRootBiomass_kgC * (1 - species.fineRootRetranslocationRate)
				* species.fineRootRelativeLossRate;
		mycorrhizaeLitterFall_kgC = mycorrhizaeBiomass_kgC; // To be reviewed
															// LATER
	}

	/**
	 * Constructor for growth time.
	 */
	public HetTree(HetTree refTree) {

		super(refTree, null, 0, 0, 0, false);

		this.species = refTree.species;

		// fc+mj-12.9.2017
//		nppToGppRatio = species.nppToGppRatio; //fa-29.10.2018: commented, not applicable if nppToGpp = f(DdIndex)
		nppToGppRatio = refTree.getNppToGppRatioForNextYear();
	}

	/**
	 * Add a TREE compartment in the tree
	 */
	public void addTreeCompartment(HetTreeCompartment c) {
		if (treeCompartments == null)
			treeCompartments = new HashMap<>();
		treeCompartments.put(c.name, c);
	}

	public List<HetTreeCompartment> getTreeCompartments() {
		return new ArrayList<>(treeCompartments.values());
	}

	public HetTreeCompartment getTreeCompartment(String compartmentName) {
		return treeCompartments.get(compartmentName);
	}

	/**
	 * Returns the list of tree compartments with the given type, e.g.
	 * HetTreeCompartment.TYPE_LEAF
	 */
	public List<HetTreeCompartment> getTreeCompartmentsForType(String compartmentType) {
		List<HetTreeCompartment> comps = new ArrayList<>();
		for (HetTreeCompartment c : getTreeCompartments()) {
			if (c.getType().equals(compartmentType)) {
				comps.add(c);
			}
		}
		return comps;
	}

	/**
	 * Add a LITTER compartment in the tree
	 */
	public void addLitterCompartment(HetLitterCompartment c) {
		if (litterCompartments == null)
			litterCompartments = new HashMap<>();
		litterCompartments.put(c.name, c);
	}

	public List<HetLitterCompartment> getLitterCompartments() {
		return new ArrayList<>(litterCompartments.values());
	}

	public HetLitterCompartment getLitterCompartment(String compartmentName) {
		return litterCompartments.get(compartmentName);
	}

	public void updateNutrientStatusMap(HetFoliarChemistryThresholds foliarChemistryThresholds) {
		nutrientStatusMap = new HetElementState();

		String speciesName = this.species.getName();
		List<String> availableElementNames = foliarChemistryThresholds.getElementNames(speciesName);

		for (String eName : availableElementNames) {

			HetTreeCompartment luc = treeCompartments.get(HetTreeCompartment.LEAVES_UPPER_CURRENT);
			double eConcentration = luc.getConcentration(eName);

			double deficiencyConcentration = foliarChemistryThresholds.getDeficiencyConcentration(speciesName, eName);
			double optimumConcentration = foliarChemistryThresholds.getOptimumConcentration(speciesName, eName);

			double eStatus = (eConcentration - deficiencyConcentration)
					/ (optimumConcentration - deficiencyConcentration);

			// System.out.println("HetTree eName: " + eName +
			// " eConcentration: " + eConcentration
			// + " deficiencyConcentration: " + deficiencyConcentration +
			// " optimumConcentration: "
			// + optimumConcentration);
			// System.out.println(" -> eStatus: " + eStatus +
			// " (before bounding)");

			// fc+mj-8.12.2016 removed this bounding
			// eStatus = Math.max(0, eStatus);
			// eStatus = Math.min(1, eStatus);

			nutrientStatusMap.setValue(eName, eStatus);
		}

	}

	public HetElementState getNutrientStatusMap() {
		return nutrientStatusMap;
	}

	// fc-10.1.2018 REMOVED, refactored, call tree.getLightResult ().resetEnergy
	// () instead
	// fc-15.5.2014 MJ found double energy in Heterofor after an intervention
	// public void resetEnergy() {
	// if (lightResult != null)
	// lightResult.setImpactNumber(0);
	// if (trunk != null)
	// trunk.resetEnergy();
	// if (crownParts != null) {
	// for (SLCrownPart cp : crownParts) {
	// cp.resetEnergy();
	// }
	// }
	// }

	public void updateMean2CrownRadius() {
		mean2CrownRadius = Math.sqrt((rnorth * rnorth + reast * reast + rsouth * rsouth + rwest * rwest) / 4d);
	}

	/**
	 * Clones a HetTree: first calls super.clone () (primitive types like
	 * boolean, int, double... and references are copied). Then clones the
	 * HetTree 'object type' instance variables (i.e. not primitive).
	 */
	@Override
	public Object clone() {

		// fc+fa-16.5.2017 This clone () is called when estimating demand and
		// when creating virtual trees to fill gaps at init time

		try {
			HetTree t = (HetTree) super.clone();

			// fc-22.6.2017 REMOVED, managed in HetModel.copyLight ()
			// t.treeLight = lightResult.getCopy(t);

			// fc-23.6.2017 create a new TreeLight, needed for next
			// processLighting ()
			t.lightResult = new SLTreeLightResult(t);

			if (crownParts != null) {
				List<SLCrownPart> l = new ArrayList<SLCrownPart>();
				for (SLCrownPart part : crownParts) {
					SLCrownPart copy = part.clone();
					l.add(copy);
				}
				t.crownParts = l;
			}

			if (trunk != null) {
				t.trunk = trunk.clone();
			}

			t.scene = null;

			return t;
		} catch (Exception e) {
			Log.println(Log.ERROR, "HetTree.clone ()", "Error while cloning tree: " + this, e);
			return null;
		}

	}

	public double getPastDbh(int numberOfYears) {
		/*
		 * try { GScene s = this.getScene(); int date0 = s.getDate(); while
		 * (date0 - s.getDate() < numberOfYears) { Step prevStep = (Step)
		 * s.getStep().getFather(); s = prevStep.getScene(); }
		 *
		 * HetScene pastScene = (HetScene) s; HetTree pastTree = (HetTree)
		 * pastScene.getTree(this.getId());
		 *
		 * return pastTree.getDbh();
		 *
		 * } catch (Exception e) { double pastDbh = dbh - numberOfYears *
		 * species.defaultDeltaDbh;
		 *
		 * return pastDbh; }
		 */

		// mj+fa-04.09.2017
		try {
			int n = 0;
			GScene s = this.getScene();
			Step currentStep = (Step) s.getStep();
			boolean rootStepReached = currentStep.isRoot();
			if (rootStepReached) {
				double pastDbh = dbh - numberOfYears * species.defaultDeltaDbh;
				// double pastDbh = dbh - numberOfYears * 0.01; // 0.01: low
				// value
				// chosen for
				// reducing
				// maintenance
				// respiration
				// of trees with
				// small crown
				return pastDbh;
			} else {
				int date0 = s.getDate();
				while (date0 - s.getDate() < numberOfYears) {
					if (!rootStepReached) {
						Step prevStep = (Step) s.getStep().getFather();
						s = prevStep.getScene();
						n += 1;
						rootStepReached = prevStep.isRoot();
					} else {
						HetScene pastScene = (HetScene) s;
						HetTree pastTree = (HetTree) pastScene.getTree(this.getId());

						double deltaDbh = (double) (dbh - pastTree.getDbh()) / n;
						double pastDbh = dbh - numberOfYears * deltaDbh;

						return pastDbh;
					}

					// if (prevStep.isRoot()) throw new Exception();
				}

				HetScene pastScene = (HetScene) s;
				HetTree pastTree = (HetTree) pastScene.getTree(this.getId());

				return pastTree.getDbh();
			}

		} catch (Exception e) {

			double pastDbh = dbh - numberOfYears * species.defaultDeltaDbh;
			// double pastDbh = dbh - numberOfYears * 0.01; // 0.01: low value
			// chosen for
			// reducing
			// maintenance
			// respiration
			// of trees with
			// small crown
			return pastDbh;
		}

	}

	static public double getHDelevoy(HetSpecies species, double dbh, double height) {
		// double a = species.stemGirthTaperA;
		// double girthTaper = (dbh * Math.PI - a * dbh * Math.PI) / (height -
		// 1.3);
		// girthTaper = girthTaper < 1 ? 1 : girthTaper;

		// fc+mj+fa-14.11.2017
		double girth = dbh * Math.PI;
		double tenPcHeightGirth = species.tenPcHeightGirth.result(girth, height);
		double sixtyPcHeightRelativeGirth = species.sixtyPcHeightRelativeGirth.result(tenPcHeightGirth);

		double girthTaper = (1 - sixtyPcHeightRelativeGirth) * tenPcHeightGirth / (height / 2d);

		return 1.3 + (girth - girth / 2d) / girthTaper;
	}

	/**
	 * Computation of maintenance respiration for a considered biomass
	 * compartment.
	 */
	public double getMaintenanceRespiration(double specificRespirationRate, double compBiomass,
			double compLivingFraction, double compNConcentration, double q10, double currentTemperature,
			double referenceTemperature) {

		return specificRespirationRate * compBiomass * compLivingFraction * compNConcentration
				* Math.pow(q10, (currentTemperature - referenceTemperature) / 10d);

	}

	// /**
	// * Creates the litter compartments for this tree.
	// */
	// public void updateLitterCompartments () {
	//
	// HetLitterCompartment leavesLitterCompartments = new
	// HetLitterCompartment(HetLitterCompartment.LEAVES);
	// leavesLitterCompartments.setBiomass(leafLitterAmount_kgOM * 0.5);
	//
	//
	// }

	/**
	 * Compute fine root to foliage ratio and specific root length based on
	 * nutrient status.
	 */
	protected double fineRootSensitivityToNutrientStatus(HetFoliarChemistryThresholds foliarChemistryThresholds,
			double min, double max) {

		String speciesName = species.getName();
		List<String> availableElementNames = foliarChemistryThresholds.getElementNames(speciesName);

		double range = max - min;
		// double eMax = 0;
		double eMax = 1; // MJ 17.12.2016

		for (String eName : availableElementNames) {
			double eSensitivity = species.nutrientGrowthSensitivity.getValue(eName);

			double eStatus = nutrientStatusMap.getValue(eName);

			// fc+mj-9.12.2016 bounded status
			eStatus = Math.max(0, eStatus);
			eStatus = Math.min(1, eStatus);

			double eRange = range * eSensitivity;

			double eValue = eRange + min - eRange * eStatus;
			if (eValue > eMax)
				eMax = eValue;
		}

		return eMax;

	}

	/**
	 * Retruns true if this tree is still alive, false if it dies.
	 */
	// public boolean isStillAlive () {
	//
	// double defoliation = leafBiomass_kgC /
	// species.leafBiomassAllometry.result
	// (getDbh (), getDbh (), mean2CrownRadius,
	// species.leafRetranslocationRate);
	// if (defoliation < species.defoliationThreshold) return false;
	//
	// return true;
	//
	// }

	/**
	 * The SamsaraLight library related trunk may be created or not depending on
	 * a SamsaraLight file property. This optional method may be called for all
	 * trees after SamsaraLight library initialization.
	 */
	public void createSLTrunk() {

		// Create the trunk
		trunk = new SLTrunk(getX(), getY(), getZ(), dbh, hcb);

	}

	public void createSLCrownParts(double LADNeighbourhoodDistance, HetScene scene) {

		int LADTreeNumber = (int) Math
				.ceil(2d / 10000d * Math.PI * LADNeighbourhoodDistance * LADNeighbourhoodDistance);

		HetPlot plot = (HetPlot) scene.getPlot();
		RoundMask m = new RoundMask(plot, LADNeighbourhoodDistance, true);
		Collection neighbourTrees = m.getTreesNear(this);
		neighbourTrees.add(this); // we add this tree

		List<HetTree> l1 = getHighestTrees(neighbourTrees, LADTreeNumber);
		List<HetTree> l2 = getLowestTrees(neighbourTrees, LADTreeNumber);

		double highestMean = calculateHighestMean(l1);
		double lowestMean = calculateLowestMean(l2);

		if (logTag < maxLogTag) { // Control trace

			StringBuffer b = new StringBuffer("-- HetTree.createSLCrownParts () tree id: " + this.getId() + "...\n");
			b.append("species: " + species.getName() + "\n");
			b.append("dbh: " + getDbh() + "\n");
			b.append("height: " + getHeight() + "\n");
			b.append("hlce: " + hlce + "\n");
			b.append("hcb: " + hcb + "\n");
			b.append("reast: " + reast + "\n");
			b.append("rnorth: " + rnorth + "\n");
			b.append("rwest: " + rwest + "\n");
			b.append("rsouth: " + rsouth + "\n");
			b.append("leafLitterAmount_kgOM: " + leafLitterAmount_kgOM + "\n");
			b.append("LADNeighbourhoodDistance: " + LADNeighbourhoodDistance + "\n");
			b.append("LADTreeNumber: " + LADTreeNumber + "\n");

			b.append("HetTree.getHighestTrees ()...\n");
			for (HetTree t : l1) {
				b.append("Id " + t.getId() + " height: " + t.getHeight() + "\n");
			}

			b.append("HetTree.getLowestTrees ()...\n");
			for (HetTree t : l2) {
				b.append("Id " + t.getId() + " hcb: " + t.getHcb() + "\n");
			}
			b.append("highestMean: " + highestMean + "\n");
			b.append("lowestMean: " + lowestMean + "\n");
			HetReporter.printInLog("Heterofor", b.toString());

		}

		// XXX Create a crown part for this tree
		if (crownForm.equals("Ec")) {
			crownParts = createECrown(LADNeighbourhoodDistance, LADTreeNumber, highestMean, lowestMean, true); // centered
																												// =
																												// true
		} else if (crownForm.equals("Ed")) {
			crownParts = createECrown(LADNeighbourhoodDistance, LADTreeNumber, highestMean, lowestMean, false);
		} else if (crownForm.equals("Bc")) {
			crownParts = createBCrown(LADNeighbourhoodDistance, LADTreeNumber, highestMean, lowestMean, true);
		} else if (crownForm.equals("Bd")) {
			crownParts = createBCrown(LADNeighbourhoodDistance, LADTreeNumber, highestMean, lowestMean, false);
		} else if (crownForm.equals("M")) {
			crownParts = createMCrown(LADNeighbourhoodDistance, LADTreeNumber, highestMean, lowestMean);
		}

		// fc-29.11.2012
		for (SLCrownPart part : crownParts) {
			part.setExtinctionCoefficient(species.extinctionCoefficient);
		}

		logTag++;

	}

	/**
	 * Build a (centered or not) crown with 1 part: Ec & Ed.
	 */
	private List<SLCrownPart> createECrown(double LADNeighbourhoodDistance, int LADTreeNumber, double highestMean,
			double lowestMean, boolean centered) {

		double x0 = 0;
		double y0 = 0;
		double a = 0;
		double b = 0;

		double c = (getHeight() - hcb) / 2.;
		double z0 = getZ() + getHeight() - c;

		if (centered) { // Ec
			x0 = getX();
			y0 = getY();
			a = (reast + rwest) / 2.;
			b = (rnorth + rsouth) / 2.;

		} else { // Ed
			double[] translatedValues = translateCrownCenter();
			x0 = translatedValues[0];
			y0 = translatedValues[1];
			a = translatedValues[2];
			b = translatedValues[3];

		}

		SLEllipsoidalCrownPart f1 = new SLEllipsoidalCrownPart(x0, y0, z0, a, b, c);

		// LAD
		double V = f1.getVolume();

		double LAD = calculateSingleLADValue(V, highestMean, lowestMean);
		f1.setLeafAreaDensity(LAD); // for turbid medium

		if (logTag < maxLogTag) { // Control trace

			StringBuffer bu = new StringBuffer("-- HetTree.createEcCrown ()...\n");

			bu.append("species.LAD: " + species.LAD + "\n");
			// bu.append("species.SLAup: " + species.SLAup + "\n");
			// bu.append("species.SLAdown: " + species.SLAdown + "\n");
			bu.append("species.SLAtop: " + species.SLAtop + "\n");
			bu.append("species.SLAbottom: " + species.SLAbottom + "\n");
			bu.append("species.UFLB: " + species.UFLB + "\n");

			bu.append("V: " + V + "\n");
			String o = getLADoption() == HetSpecies.MEAN_LAD ? "MEAN_LAD"
					: getLADoption() == HetSpecies.MEAN_SLA ? "MEAN_SLA"
							: getLADoption() == HetSpecies.QUERGUS_LAD ? "QUERGUS_LAD" : "SLA_MODEL";

			bu.append("LADoption: " + o + "\n");
			bu.append("LAD: " + LAD + "\n");

			o = getToption() == HetSpecies.MEAN_T ? "MEAN_T"
					: getLADoption() == HetSpecies.QUERGUS_T ? "QUERGUS_T" : "MEAN_T";
			bu.append("Toption: " + o + "\n");
			// bu.append ("T: " + 0d + "\n"); //TODO

			HetReporter.printInLog("Heterofor", bu.toString());

		}

		List<SLCrownPart> crownParts = new ArrayList<SLCrownPart>();
		crownParts.add(f1);

		return crownParts;

	}

	/**
	 * Build a (centered or not) crown with 2 parts: Bc & Bd.
	 */
	private List<SLCrownPart> createBCrown(double LADNeighbourhoodDistance, int LADTreeNumber, double highestMean,
			double lowestMean, boolean centered) {

		double x0 = 0;
		double y0 = 0;
		double a = 0;
		double b = 0;

		double rup = height - hlce;
		double rdown = hlce - hcb;
		double z0 = getZ() + hlce;

		if (centered) { // Bc
			x0 = getX();
			y0 = getY();
			a = (reast + rwest) / 2.;
			b = (rnorth + rsouth) / 2.;

		} else { // Bd
			double[] translatedValues = translateCrownCenter();
			x0 = translatedValues[0];
			y0 = translatedValues[1];
			a = translatedValues[2];
			b = translatedValues[3];

		}

		SLEllipsoidalCrownPart f1 = new SLEllipsoidalCrownPart(x0, y0, z0, a, b, rup, true); // topPart
																								// =
																								// true
		SLEllipsoidalCrownPart f2 = new SLEllipsoidalCrownPart(x0, y0, z0, a, b, rdown, false); // topPart
																								// =
																								// false

		// LAD
		double Vup = f1.getVolume();
		double Vdown = f2.getVolume();

		double[] LADvalues = calculateLADValues(Vup, Vdown, highestMean, lowestMean);
		double LADup = LADvalues[0];
		double LADdown = LADvalues[1];
		double uflb = LADvalues[2];
		
		//fa-06.12.2018
		this.setLADup(LADup); 
		this.setLADdown(LADdown);
		this.setCrownVolumeUp(Vup);
		this.setCrownVolumeDown(Vdown);
		this.setUflb(uflb);

		if (logTag < maxLogTag) { // Control trace

			StringBuffer bu = new StringBuffer("-- HetTree.createBcCrown ()...\n");

			bu.append("species.LADup: " + species.LADup + "\n");
			bu.append("species.LADdown: " + species.LADdown + "\n");
			// bu.append("species.SLAup: " + species.SLAup + "\n");
			// bu.append("species.SLAdown: " + species.SLAdown + "\n");
			bu.append("species.SLAtop: " + species.SLAtop + "\n");
			bu.append("species.SLAbottom: " + species.SLAbottom + "\n");
			bu.append("species.UFLB: " + species.UFLB + "\n");

			bu.append("rup: " + rup + "\n");
			bu.append("rdown: " + rdown + "\n");
			bu.append("Vup: " + Vup + "\n");
			bu.append("Vdown: " + Vdown + "\n");
			bu.append("uflb: " + uflb + "\n");
			String o = getLADoption() == HetSpecies.MEAN_LAD ? "MEAN_LAD"
					: getLADoption() == HetSpecies.MEAN_SLA ? "MEAN_SLA"
							: getLADoption() == HetSpecies.QUERGUS_LAD ? "QUERGUS_LAD" : "SLA_MODEL";

			bu.append("LADoption: " + o + "\n");
			bu.append("LADup: " + LADup + "\n");
			bu.append("LADdown: " + LADdown + "\n");

			o = getToption() == HetSpecies.MEAN_T ? "MEAN_T"
					: getLADoption() == HetSpecies.QUERGUS_T ? "QUERGUS_T" : "MEAN_T";
			bu.append("Toption: " + o + "\n");

			HetReporter.printInLog("Heterofor", bu.toString());

		}

		f1.setLeafAreaDensity(LADup); // for turbid medium
		f2.setLeafAreaDensity(LADdown); // for turbid medium

		List<SLCrownPart> crownParts = new ArrayList<SLCrownPart>();
		crownParts.add(f1);
		crownParts.add(f2);

		return crownParts;

	}

	/**
	 * Translates the Ellipsoid origin in order to pass through the 4 points
	 * defined by the 4 radius. Calculates the new values for the 2
	 * semi-principal axes a and b.
	 *
	 * @return a double[] containing {x0, y0, a, b} in this order
	 */
	private double[] translateCrownCenter() {

		double reast = Math.max(this.reast, DECENTERED_RADIUS_EPSILON);
		double rwest = Math.max(this.rwest, DECENTERED_RADIUS_EPSILON);
		double rnorth = Math.max(this.rnorth, DECENTERED_RADIUS_EPSILON);
		double rsouth = Math.max(this.rsouth, DECENTERED_RADIUS_EPSILON);

		double x0 = (reast * reast - rwest * rwest) / (2 * (reast + rwest));
		double y0 = (rnorth * rnorth - rsouth * rsouth) / (2 * (rnorth + rsouth));
		// double z0 = hlce;

		double numerator = -(x0 * x0 * y0 * y0) + (rsouth + y0) * (rsouth + y0) * (reast - x0) * (reast - x0);
		double denominator = reast * reast - 2 * reast * x0;
		double b = Math.sqrt(numerator / denominator);
		double a = ((reast - x0) * b) / Math.sqrt(b * b - y0 * y0);

		return new double[] { getX() + x0, getY() + y0, a, b };
	}

	/**
	 * Build a crown with 8 parts: M
	 */
	private List<SLCrownPart> createMCrown(double LADNeighbourhoodDistance, int LADTreeNumber, double highestMean,
			double lowestMean) {

		double x0 = getX();
		double y0 = getY();
		double z0 = getZ() + hlce;

		double rup = height - hlce;
		double rdown = hlce - hcb;

		// Crown: eight 8ths of ellipsoid
		SLCrownFraction f1 = new SLCrownFraction(x0, y0, z0, reast, rnorth, rup);
		SLCrownFraction f2 = new SLCrownFraction(x0, y0, z0, reast, -rsouth, rup);
		SLCrownFraction f3 = new SLCrownFraction(x0, y0, z0, -rwest, -rsouth, rup);
		SLCrownFraction f4 = new SLCrownFraction(x0, y0, z0, -rwest, rnorth, rup);
		SLCrownFraction f5 = new SLCrownFraction(x0, y0, z0, reast, rnorth, -rdown);
		SLCrownFraction f6 = new SLCrownFraction(x0, y0, z0, reast, -rsouth, -rdown);
		SLCrownFraction f7 = new SLCrownFraction(x0, y0, z0, -rwest, -rsouth, -rdown);
		SLCrownFraction f8 = new SLCrownFraction(x0, y0, z0, -rwest, rnorth, -rdown);

		// LAD
		double Vup = f1.getVolume() + f2.getVolume() + f3.getVolume() + f4.getVolume();
		double Vdown = f5.getVolume() + f6.getVolume() + f7.getVolume() + f8.getVolume();

		double[] LADvalues = calculateLADValues(Vup, Vdown, highestMean, lowestMean);
		double LADup = LADvalues[0];
		double LADdown = LADvalues[1];
		double uflb = LADvalues[2];

		if (logTag < maxLogTag) { // Control trace

			StringBuffer b = new StringBuffer("-- HetTree.createMCrown ()...\n");

			b.append("species.LADup: " + species.LADup + "\n");
			b.append("species.LADdown: " + species.LADdown + "\n");
			// b.append("species.SLAup: " + species.SLAup + "\n");
			// b.append("species.SLAdown: " + species.SLAdown + "\n");
			b.append("species.SLAtop: " + species.SLAtop + "\n");
			b.append("species.SLAbottom: " + species.SLAbottom + "\n");
			b.append("species.UFLB: " + species.UFLB + "\n");

			b.append("rup: " + rup + "\n");
			b.append("rdown: " + rdown + "\n");
			b.append("Vup: " + Vup + "\n");
			b.append("Vdown: " + Vdown + "\n");
			b.append("uflb: " + uflb + "\n");
			String o = getLADoption() == HetSpecies.MEAN_LAD ? "MEAN_LAD"
					: getLADoption() == HetSpecies.MEAN_SLA ? "MEAN_SLA"
							: getLADoption() == HetSpecies.QUERGUS_LAD ? "QUERGUS_LAD" : "SLA_MODEL";

			b.append("LADoption: " + o + "\n");
			b.append("LADup: " + LADup + "\n");
			b.append("LADdown: " + LADdown + "\n");

			o = getToption() == HetSpecies.MEAN_T ? "MEAN_T"
					: getLADoption() == HetSpecies.QUERGUS_T ? "QUERGUS_T" : "MEAN_T";
			b.append("Toption: " + o + "\n");

			HetReporter.printInLog("Heterofor", b.toString());

		}

		f1.setLeafAreaDensity(LADup); // for turbid medium
		f2.setLeafAreaDensity(LADup); // for turbid medium
		f3.setLeafAreaDensity(LADup); // for turbid medium
		f4.setLeafAreaDensity(LADup); // for turbid medium
		f5.setLeafAreaDensity(LADdown); // for turbid medium
		f6.setLeafAreaDensity(LADdown); // for turbid medium
		f7.setLeafAreaDensity(LADdown); // for turbid medium
		f8.setLeafAreaDensity(LADdown); // for turbid medium

		List<SLCrownPart> crownParts = new ArrayList<SLCrownPart>();
		crownParts.add(f1);
		crownParts.add(f2);
		crownParts.add(f3);
		crownParts.add(f4);
		crownParts.add(f5);
		crownParts.add(f6);
		crownParts.add(f7);
		crownParts.add(f8);

		return crownParts;
	}

	/**
	 * Calculates the LAD for crowns with a single ellipsoid (crownForm: Ec, Ed)
	 */
	private double calculateSingleLADValue(double V, double highestMean, double lowestMean) {

		HetScene scene = (HetScene) this.getScene();

		double LAD = 0;
		if (getLADoption() == HetSpecies.MEAN_LAD) {
			LAD = species.LAD;

		} else if (getLADoption() == HetSpecies.MEAN_SLA) {
			double SLAdown = (species.SLAtop - species.SLAbottom) / (highestMean - lowestMean)
					* (scene.getMeanLowerCrownHeightMap().get(this.getSpecies().getId()) - lowestMean)
					+ species.SLAbottom;
			double SLAup = (species.SLAtop - species.SLAbottom) / (highestMean - lowestMean)
					* (scene.getMeanUpperCrownHeightMap().get(this.getSpecies().getId()) - lowestMean)
					+ species.SLAbottom;
			double meanSLA = species.UFLB * SLAup + (1 - species.UFLB) * SLAdown;
			LAD = meanSLA * leafBiomass_kgOM / V;

		} else if (getLADoption() == HetSpecies.QUERGUS_LAD) {
			LAD = getQuergusLAD(species.getName(), dbh);

		} else { // SLA_MODEL
			double h = (getHeight() + hcb) / 2d;

			// fc+mj-15.5.2013
			/*
			 * double SLA = (species.SLAintercept - species.SLAdown) /
			 * (highestMean - lowestMean) * (h - lowestMean) + species.SLAdown;
			 * SLA = Math.max(SLA, species.SLAtop); SLA = Math.min(SLA,
			 * species.SLAdown);
			 */
			// fc+mj-15.5.2013

			// ldw+mj-24.8.2017
			// double SLA = (species.SLAintercept - species.SLAbottom) /
			// (highestMean - lowestMean) * (h - lowestMean)
			// + species.SLAbottom;
			// fa-22.01.2018
			double SLA = (species.SLAtop - species.SLAbottom) / (highestMean - lowestMean) * (h - lowestMean)
					+ species.SLAbottom;
			SLA = Math.max(SLA, species.SLAtop);
			SLA = Math.min(SLA, species.SLAbottom);

			LAD = SLA * leafBiomass_kgOM / V;

		}
		return LAD;

	}

	/**
	 * Calculates the LAD for crowns with an up and a down part (crownForm: Bc,
	 * Bd, M)
	 */
	private double[] calculateLADValues(double Vup, double Vdown, double highestMean, double lowestMean) {

		HetScene scene = (HetScene) this.getScene();

		double uflb = Math.max(species.UFLB, Vup / (Vup + Vdown));
		double LADup = 0;

		if (getLADoption() == HetSpecies.MEAN_LAD) {
			LADup = species.LADup;

		} else if (getLADoption() == HetSpecies.MEAN_SLA) {
			double SLAup = (species.SLAtop - species.SLAbottom) / (highestMean - lowestMean)
					* (scene.getMeanUpperCrownHeightMap().get(this.getSpecies().getId()) - lowestMean)
					+ species.SLAbottom;
			LADup = SLAup * leafBiomass_kgOM * uflb / Vup;

		} else if (getLADoption() == HetSpecies.QUERGUS_LAD) {
			LADup = getQuergusLAD(species.getName(), dbh);

		} else { // SLA_MODEL
			double h = (getHeight() + hlce) / 2d;

			// // fc+mj-15.5.2013
			// double SLAup = (species.SLAintercept - species.SLAdown) /
			// (highestMean - lowestMean) * (h - lowestMean)
			// + species.SLAdown;
			// SLAup = Math.max(SLAup, species.SLAtop);
			// SLAup = Math.min(SLAup, species.SLAdown);
			// // fc+mj-15.5.2013

			// mj+fa-24.11.2017
			// double SLAup = (species.SLAintercept - species.SLAbottom) /
			// (highestMean - lowestMean) * (h - lowestMean)
			// + species.SLAbottom;
			// fa-22.01.2018
			double SLAup = (species.SLAtop - species.SLAbottom) / (highestMean - lowestMean) * (h - lowestMean)
					+ species.SLAbottom;
			SLAup = Math.max(SLAup, species.SLAtop);
			SLAup = Math.min(SLAup, species.SLAbottom);
			
			this.setSLAup(SLAup); // fa-06.12.2018

			LADup = SLAup * leafBiomass_kgOM * uflb / Vup;

		}

		double LADdown = 0;
		if (getLADoption() == HetSpecies.MEAN_LAD) {
			LADdown = species.LADdown;

		} else if (getLADoption() == HetSpecies.MEAN_SLA) {
			double SLAdown = (species.SLAtop - species.SLAbottom) / (highestMean - lowestMean)
					* (scene.getMeanLowerCrownHeightMap().get(this.getSpecies().getId()) - lowestMean)
					+ species.SLAbottom;
			LADdown = SLAdown * leafBiomass_kgOM * (1 - uflb) / Vdown;

		} else if (getLADoption() == HetSpecies.QUERGUS_LAD) {
			LADdown = getQuergusLAD(species.getName(), dbh);

		} else { // SLA_MODEL
			double h = (hcb + hlce) / 2d;

			// // fc+mj-15.5.2013
			// double SLAdown = (species.SLAintercept - species.SLAdown) /
			// (highestMean - lowestMean) * (h - lowestMean)
			// + species.SLAdown;
			// SLAdown = Math.max(SLAdown, species.SLAtop);
			// SLAdown = Math.min(SLAdown, species.SLAdown);
			// // fc+mj-15.5.2013

			// mj+fa-24.11.2017
			// double SLAdown = (species.SLAintercept - species.SLAbottom) /
			// (highestMean - lowestMean) * (h - lowestMean)
			// + species.SLAbottom;
			// fa-22.01.2018
			double SLAdown = (species.SLAtop - species.SLAbottom) / (highestMean - lowestMean) * (h - lowestMean)
					+ species.SLAbottom;
			SLAdown = Math.max(SLAdown, species.SLAtop);
			SLAdown = Math.min(SLAdown, species.SLAbottom);
			
			this.setSLAdown(SLAdown); // fa-06.12.2018

			LADdown = SLAdown * leafBiomass_kgOM * (1 - uflb) / Vdown;

		}

		return new double[] { LADup, LADdown, uflb };
	}

	/**
	 * Computes the mean height of the given trees
	 */
	private double calculateHighestMean(List<HetTree> l) {
		int n = l.size();
		double v = 0;
		for (HetTree t : l) {
			// v += t.getHeight();
			v += (t.getHeight() + t.getHlce()) / 2d; // fa-19.03.2018
		}
		return v / n;
	}

	/**
	 * Computes the mean hcb of the given trees
	 */
	private double calculateLowestMean(List<HetTree> l) {
		int n = l.size();
		double v = 0;
		for (HetTree t : l) {
			// v += t.getHcb();
			v += (t.getHcb() + t.getHlce()) / 2d; // fa-19.03.2018
		}
		return v / n;
	}

	/**
	 * Sorts the given tree list by decreasing order of tree height and returns
	 * the n highest trees (n = LADTreeNumber).
	 */
	private List<HetTree> getHighestTrees(Collection neighbourTrees, int LADTreeNumber) {
		try {
			List l1 = new ArrayList(neighbourTrees);
			Collections.sort(l1, new Comparator() {

				// @Override
				// public int compare(Object o1, Object o2) {
				// HetTree t1 = (HetTree) o1;
				// HetTree t2 = (HetTree) o2;
				// int res = 0;
				// if (t1.getHeight() < t2.getHeight()) {
				// res = -1;
				// } else if (t1.getHeight() > t2.getHeight()) {
				// res = 1;
				// } else {
				// res = t1.getId() - t2.getId();
				// }
				// }

				@Override
				public int compare(Object o1, Object o2) {
					HetTree t1 = (HetTree) o1;
					HetTree t2 = (HetTree) o2;
					if (t1.getHeight() > t2.getHeight()) {
						return -1;
					} else if (t1.getHeight() < t2.getHeight()) {
						return 1;
					} else {
						return t1.getId() - t2.getId();
					}
				}

			});

			// Take the n biggest
			List<HetTree> l2 = new ArrayList<HetTree>();
			int count = 0;
			for (Iterator i = l1.iterator(); i.hasNext();) {
				HetTree t = (HetTree) i.next();
				l2.add(t);
				count++;
				if (count >= LADTreeNumber)
					break; // enough
			}

			return l2;
		} catch (Throwable t) { // fc+mj-29.4.2015 try to find out: comparator
								// contract violated
			String m = "HetTree.getHighestTrees() (around treeId: " + getId()
					+ "): could not sort these trees due to an exception...";
			for (Object nei : neighbourTrees) {
				HetTree tree = (HetTree) nei;
				m += "\n  Tree id: " + tree.getId() + " height: " + tree.getHeight();
			}
			HetReporter.printInStandardOutput(m);
			throw t;
		}
	}

	/**
	 * Sorts the given tree list by increasing order of tree hcb and returns the
	 * n trees with the lowest hcb (n = LADTreeNumber).
	 */
	private List<HetTree> getLowestTrees(Collection neighbourTrees, int LADTreeNumber) {

		List l1 = new ArrayList(neighbourTrees);
		Collections.sort(l1, new Comparator() {

			@Override
			public int compare(Object o1, Object o2) {
				HetTree t1 = (HetTree) o1;
				HetTree t2 = (HetTree) o2;
				if (t1.getHcb() < t2.getHcb()) {
					return -1;
				} else if (t1.getHcb() > t2.getHcb()) {
					return 1;
				} else {
					return t1.getId() - t2.getId();
				}
			}

		});
		// Take the n lowest
		List<HetTree> l2 = new ArrayList<HetTree>();
		int count = 0;
		for (Iterator i = l1.iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();
			l2.add(t);
			count++;
			if (count >= LADTreeNumber)
				break; // enough
		}
		return l2;
	}

	// /** Create an Immutable object whose class is declared at one level of
	// the hierarchy.
	// * This is called only in constructor for new logical object in
	// superclass.
	// * If an Immutable is declared in subclass, subclass must redefine this
	// method
	// * (same body) to create an Immutable defined in subclass.
	// */
	// @Override
	// protected void createImmutable () {immutable = new Immutable ();}

	/**
	 * Convenient method.
	 */
	protected Immutable getImmutable() {
		return (Immutable) immutable;
	}

	public List<Integer> getVirtualTreeIdsBasedOnMe() {
		return virtualTreeIdsBasedOnMe;
	}

	public void setVirtualTreeIdsBasedOnMe(List<Integer> virtualTreeIdsBasedOnMe) {
		this.virtualTreeIdsBasedOnMe = virtualTreeIdsBasedOnMe;
	}

	/**
	 * Returns a copy of the tree, with null crownParts, treeCompartments,
	 * litterCompartments and nutrientStatusMap. fc+mj-11.5.2016
	 */
	public HetTree getCopy() {
		HetTree copy = (HetTree) clone();

		copy.crownParts = null;
		copy.trunk = null;
		copy.treeCompartments = null;
		copy.litterCompartments = null;
		copy.nutrientStatusMap = null;

		return copy;

	}

	/**
	 * Give a copy and shift the crown part (). It is used to create virtual
	 * trees. It requires shifting tree coordinates afterward. e.g Shiftx = Xnew
	 * - Xold See in HetModel.
	 */
	public HetTree getCopy(HetScene scene, int newId, double xShift, double yShift, double zShift) {
		HetTree copy = (HetTree) clone();

		// fc-23.6.2017 ADDED, virtual trees need a lightResult != null for
		// first
		// processLighting
		copy.lightResult = lightResult.getCopy(copy);

		// fc+mj-23.3.2016 the virtual copy knows I'm the original
		copy.virtualOriginalTreeId = getId();

		// fc+mj-23.3.2016 I know which virtual copies of me were made
		if (virtualTreeIdsBasedOnMe == null)
			virtualTreeIdsBasedOnMe = new ArrayList<>();
		virtualTreeIdsBasedOnMe.add(newId);

		copy.scene = scene;
		copy.cell = null;
		copy.immutable = new Immutable();
		copy.immutable.id = newId;

		if (crownParts != null) {
			List<SLCrownPart> l = new ArrayList<SLCrownPart>();
			for (SLCrownPart part : crownParts) {
				SLCrownPart c = part.getCopy(xShift, yShift, zShift); // translated
																		// =
																		// true:
																		// move
																		// to
																		// the
																		// given
																		// location
				l.add(c);
			}
			copy.crownParts = l;
		}

		if (trunk != null) {
			copy.trunk = trunk.getCopy(xShift, yShift, zShift); // translated =
																// true: move to
																// the
																// given
																// location
		}

		return copy;
	}

	/**
	 * A string representation of this object.
	 */
	@Override
	public String toString() {

		// // fc-23.6.2017 investigating lightResult
		// String detail = ", ";
		// if (getTreeLight() == null) {
		// detail += "tl: null";
		// } else {
		// detail += "tl: ok";
		// }
		//
		// return "HetTree_" + getId() + detail;

		return "HetTree_" + getId();

	}

	// TreeWithCrownProfile interface

	public String getName() {
		return "HetTree " + getId();
	}

	// @Override
	// public double[][] getCrownProfile() {
	// return getImmutable().crownProfile;
	// }

	/**
	 * SimpleCrownDescription interface
	 */
	@Override
	public double getCrownBaseHeight() {
		return hcb;
	}

	/**
	 * SimpleCrownDescription interface
	 */
	@Override
	public double getCrownRadius() {
		return mean2CrownRadius;
	}

	/**
	 * SimpleCrownDescription interface
	 */
	@Override
	public Color getCrownColor() {
		return getSpecies().color;
	}

	/**
	 * SimpleCrownDescription interface
	 */
	@Override
	public int getCrownType() {
		return TreeWithCrownProfile.SPHERIC_CROWN; // or CONIC_CROWN
	}

	/**
	 * Bounding box min, relative to (x,y,z)
	 */
	public Vertex3d getRelativeMin() {
		return new Vertex3d(getX() - getCrownRadius(), getY() - getCrownRadius(), getZ());
	}

	/**
	 * Bounding box max, relative to (x,y,z)
	 */
	public Vertex3d getRelativeMax() {
		return new Vertex3d(getX() + getCrownRadius(), getY() + getCrownRadius(), getZ() + getHeight());
	}

	// end-of-TreeWithCrownProfile interface

	public SLTreeLightResult getLightResult() {
		return lightResult;
	}

	public void setLightResult(SLTreeLightResult t) {
		lightResult = t;
	}

	public double getHlce() {
		return hlce;
	}

	public double getHcb() {
		return hcb;
	}

	public double getRnorth() {
		return rnorth;
	}

	public double getReast() {
		return reast;
	}

	public double getRsouth() {
		return rsouth;
	}

	public double getRwest() {
		return rwest;
	}

	public HetSpecies getSpecies() {
		return species;
	}

	// @Override
	// public char getCrownShape() {
	// return getSpecies ().getSLSpeciesSettings().crownShape;
	// }

	@Override
	public List<SLCrownPart> getCrownParts() {
		return crownParts;
	}

	public SLTrunk getTrunk() {
		return trunk;
	}

	@Override
	public double getCrownTransmissivity() {
		if (getToption() == HetSpecies.MEAN_T) { // gl-21.05.2013
			return species.crownTransmissivity; // fc-29.11.2012
		} else if (getToption() == HetSpecies.QUERGUS_T) {
			return getQuergusCrownOpen(species.getName(), dbh);
		} else {
			HetReporter.printInLog("HetTree.getCrownTransmissivity : Wrong Toption");
			return species.crownTransmissivity;
		}
	}

	public boolean isVirtual() {
		return virtual;
	}

	public void setVirtual(boolean virtual) {
		this.virtual = virtual;
	}

	/**
	 * get LAD as it is computed in Quergus
	 *
	 * @param speciesName
	 *            - species name (you'd better spell it right)
	 * @param dbh
	 *            - tree diameter in cm
	 */
	public double getQuergusLAD(String speciesName, double dbh) {

		double lad = 0d;
		double circ = dbh * Math.PI;
		try {
			if (speciesName.equals("quercus")) {
				lad = 1.207 - 0.01037 * circ + 0.00003094 * circ * circ;
			} else if (speciesName.equals("fagus")) {
				lad = 1.72 - 0.01879 * circ + 0.00006267 * circ * circ;
			} else if (speciesName.equals("betulus")) {
				lad = 0.6;
			} else if (speciesName.equals("carpinus")) {
				lad = 0.6;
			} else if (speciesName.equals("coniferous")) {
				lad = 0.6;
			} else if (speciesName.equals("broadleaved")) {
				lad = 0.6;
			} else {
				throw new Exception(
						"HetSpecies.getQuergusLAD() - wrong species name : use only quercus, fagus, betulus, carpinus, coniferous or broadleaved. and not : "
								+ speciesName);
			}
		} catch (Exception e) {
			Log.println(Log.ERROR, "HetSpecies.getQuergusLAD ()", "Error computing crown LAD: ", e);
			e.printStackTrace();
		}
		return lad;

	}

	/**
	 * get LAD as it is computed in Quergus
	 *
	 * @param speciesName
	 *            - species name (you'd better spell it right)
	 * @param dbh
	 *            - tree diameter in cm
	 */
	public double getQuergusCrownOpen(String speciesName, double dbh) {

		double porosity = 0d;
		double circ = dbh * Math.PI;

		try {

			if (speciesName.equals("quercus")) {
				porosity = 34.207 - 0.2813 * circ + 0.0007336 * circ * circ;
			} else if (speciesName.equals("fagus")) {
				porosity = 7.886 - 0.029 * circ;
			} else if (speciesName.equals("betulus")) {
				porosity = 13.03;
			} else if (speciesName.equals("carpinus")) {
				porosity = 9.26;
			} else if (speciesName.equals("coniferous")) {
				porosity = 3.5;
			} else if (speciesName.equals("broadleaved")) {
				porosity = 10;
			} else {
				throw new Exception(
						"HetTree.getQuergusCrownOpenness() - wrong species name : use only quercus, fagus, betulus, carpinus, coniferous or broadleaved. and not : "
								+ speciesName);
			}
		} catch (Exception e) {
			Log.println(Log.ERROR, "HetTree.getQuergusCrownOpenness()", "Error computing crown openness: ", e);
			e.printStackTrace();
		}

		return porosity / 100d;
	}

	/**
	 * A default delta dbh for this tree.
	 */
	public double getDefaultDeltaDbh() {
		return species.defaultDeltaDbh;
	}

	/**
	 * A default delta height for this tree, based on a height diameter
	 * relationship, may be used in inverseGrowth in certain cases.
	 */
	public double getDefaultDeltaHeight() {
		HetSpecies sp = getSpecies();

		double dbh0 = getDbh();
		double dbh1 = dbh0 + sp.defaultDeltaDbh;

		// fc+mj+br-2.10.2018
		// double girth0 = dbh0 * Math.PI;
		// double girth1 = dbh1 * Math.PI;
		//
		// double logGirth0 = Math.log(girth0);
		// double h0 = sp.heightA + sp.heightB * logGirth0 + sp.heightC *
		// logGirth0 * logGirth0
		// + sp.heightD * logGirth0 * logGirth0 * logGirth0;
		//
		// double logGirth1 = Math.log(girth1);
		// double h1 = sp.heightA + sp.heightB * logGirth1 + sp.heightC *
		// logGirth1 * logGirth1
		// + sp.heightD * logGirth1 * logGirth1 * logGirth1;

		// fc+mj+br-2.10.2018 introduced treeHeight function in HetSpecies
		double h0 = sp.treeHeight.result(dbh0);
		double h1 = sp.treeHeight.result(dbh1);

		return h1 - h0; // m.

	}

	// fc+mj+br-2.10.2018 unused
	// public double heightA = 0;
	// public double heightB = -11.91;
	// public double heightC = 7.04;
	// public double heightD = -0.73;

	/**
	 * A convenient method to get tree girth
	 *
	 * @author GL 13/05/2013
	 */
	public double getGirth() {
		return this.dbh * Math.PI;
	}

	public double getDeltaDbh_cm() {
		return deltaDbh_cm;
	}

	/**
	 * A convenient function to get basal area of tree (m)
	 *
	 * @author GL 13/05/2013
	 */
	public double getBasalArea() {
		return Math.PI * (dbh / 100) * (dbh / 100) / 4;
	}

	public static double getCrownEpsilon() {
		return CROWN_EPSILON;
	}

	public static double getDecenteredRadiusEpsilon() {
		return DECENTERED_RADIUS_EPSILON;
	}

	public static int getLogTag() {
		return logTag;
	}

	public static int getMaxLogTag() {
		return maxLogTag;
	}

	public String getCrownForm() {
		return crownForm;
	}

	public double getLeafLitterAmount_kgOM() {
		return leafLitterAmount_kgOM;
	}

	public int getLADoption() {
		return species.LADoption;
	}

	public int getToption() {
		return species.Toption;
	}

	public double getMean2CrownRadius() {
		return mean2CrownRadius;
	}

	public double getLeafBiomass_kgC() {
		return leafBiomass_kgC;
	}

	public double getBranchBiomass_kgC() {
		return branchBiomass_kgC;
	}

	public double getStemBiomass_kgC() {
		return stemBiomass_kgC;
	}

	public double getRootBiomass_kgC() {
		return rootBiomass_kgC;
	}

	public double getFineRootBiomass_kgC() {
		return fineRootBiomass_kgC;
	}

	public double getFineRootCConcentration() {
		return fineRootCConcentration;
	}

	public double getSRL() {
		return SRL;
	}

	public double getFineRootLength() {
		return fineRootLength;
	}

	public double getFineRootVolume() {
		return fineRootVolume;
	}

	public double getFineRootDiameter() {
		return fineRootDiameter;
	}

	public double getStemVolume() {
		return stemVolume;
	}

	public double getStemCylinderDiameter() {
		return stemCylinderDiameter;
	}

	public double getHyphaLength() {
		return hyphaLength;
	}

	public double getMycorrhizaeBiomass_kgC() {
		return mycorrhizaeBiomass_kgC;
	}

	public double getInterceptedParRadiation() {
		return interceptedParRadiation;
	}

	// fc+mj-13.9.2017
	public double getInterceptedDirectParRadiation() {
		HetTreeRadiationStatus radiationStatus = new HetTreeRadiationStatus(this);
		return radiationStatus.interceptedDirectParRadiation;
	}

	// fc+mj-13.9.2017
	public double getInterceptedDiffuseParRadiation() {
		HetTreeRadiationStatus radiationStatus = new HetTreeRadiationStatus(this);
		return radiationStatus.interceptedDiffuseParRadiation;
	}

	// fc+mj-13.9.2017
	public double getSunlitLeafArea() {
		// double a = 1 - Math.exp(-species.extinctionCoefficient *
		// this.getCrownLAD() * this.getCrownLength());
		HetScene scene = (HetScene) this.getScene(); // mj+fa-20.09.2017
		HetTreeRadiationStatus radiationStatus = new HetTreeRadiationStatus(this); // mj+fa-20.09.2017
//		double a = 1 - Math.exp(-species.extinctionCoefficient * this.getCrownLAD() * this.getCrownLength());
//		double a = 1 - Math.exp(-0.5 * this.getCrownLAD() * this.getCrownVolume()/this.getCrownProjection()); //mj+fa-13.12.2018
		double a = 1 - Math.exp(-species.extinctionCoefficient * this.getCrownLAD() * this.getCrownVolume()/this.getCrownProjection()); //mj+fa-05.02.2019
		// * scene.getCrownProjectionSum_stand() / scene.getArea()); //
		// mj+fa-20.09.2017
		// double sunlitLeafArea = a / species.extinctionCoefficient *
		// this.getCrownProjection();
		double sunlitLeafArea = a / species.extinctionCoefficient * this.getCrownProjection()*radiationStatus.lightCompetitionIndex;
//		double sunlitLeafArea = a / 0.5 * this.getCrownProjection()*radiationStatus.lightCompetitionIndex; //mj+fa-13.12.2018
		// / scene.getCrownProjectionSum_stand() * scene.getArea(); // *
		// radiationStatus.lightCompetitionIndex
		// /
		// this.getSpecies().meanLightCompetitionIndex;
		// //mj+fa-20.09.2017
		return sunlitLeafArea;

	}

	// fc+mj-13.9.2017
	public double getShadedLeafArea() {
		double crownLeafArea = this.getLeafArea();
		double shadedLeafArea = crownLeafArea - getSunlitLeafArea();
		shadedLeafArea = Math.max(shadedLeafArea, 0);
		return shadedLeafArea;

	}

	public double getLightCompetitionIndex() {
		return lightCompetitionIndex;
	}

	public double getParUseEfficiency() {
		return parUseEfficiency;
	}

	public double getGrossPrimaryProduction_kgC() {
		return grossPrimaryProduction_kgC;
	}

	// public double getStemLivingFraction() {
	// return stemLivingFraction;
	// }

	public double getMaintenanceRespiration_kgC() {
		return maintenanceRespiration_kgC;
	}

	public double getLeafRetranslocation_kgC() {
		return leafRetranslocation_kgC;
	}

	public double getFineRootRetranslocation_kgC() {
		return fineRootRetranslocation_kgC;
	}

	public double getNetPrimaryProduction_kgC() {
		return netPrimaryProduction_kgC;
	}

	public double getLeafBiomassProduction_kgC() {
		return leafBiomassProduction_kgC;
	}

	// public void setLeafBiomassProduction_kgC(double
	// leafBiomassProduction_kgC) {
	// this.leafBiomassProduction_kgC = leafBiomassProduction_kgC;
	// }
	//
	// public void setFineRootBiomassProduction_kgC(double
	// fineRootBiomassProduction_kgC) {
	// this.fineRootBiomassProduction_kgC = fineRootBiomassProduction_kgC;
	// }

	public void setFineRootLength(double fineRootLength) {
		this.fineRootLength = fineRootLength;
	}

	public void setFineRootVolume(double fineRootVolume) {
		this.fineRootVolume = fineRootVolume;
	}

	public void setFineRootDiameter(double fineRootDiameter) {
		this.fineRootDiameter = fineRootDiameter;
	}

	public void setHyphaLength(double hyphaLength) {
		this.hyphaLength = hyphaLength;
	}

	public void setMycorrhizaeBiomass_kgC(double mycorrhizaeBiomass_kgC) {
		this.mycorrhizaeBiomass_kgC = mycorrhizaeBiomass_kgC;
	}

	public double getFineRootBiomassProduction_kgC() {
		return fineRootBiomassProduction_kgC;
	}

	public double getMycorrhizaeBiomassProduction_kgC() {
		return mycorrhizaeBiomassProduction_kgC;
	}

	public void setMycorrhizaeBiomassProduction_kgC(double mycorrhizaeBiomassProduction_kgC) {
		this.mycorrhizaeBiomassProduction_kgC = mycorrhizaeBiomassProduction_kgC;
	}

	public void setLeafBiomassProduction_kgC(double leafBiomassProduction_kgC) {
		this.leafBiomassProduction_kgC = leafBiomassProduction_kgC;
	}

	public void setFineRootBiomassProduction_kgC(double fineRootBiomassProduction_kgC) {
		this.fineRootBiomassProduction_kgC = fineRootBiomassProduction_kgC;
	}

	public double getTotalStructuralBiomassToAllocate_kgC() {
		return totalStructuralBiomassToAllocate_kgC;
	}

	public double getBranchLitterFall_kgC() {
		return branchLitterFall_kgC;
	}

	public double getRootLitterFall_kgC() {
		return rootLitterFall_kgC;
	}

	public double getFineRootLitterFall_kgC() {
		return fineRootLitterFall_kgC;
	}
	
	// mj+fa-24.10.2018
	public double getRootLitterCorrectionFactor() {
		return rootLitterCorrectionFactor;
	}
	
	// mj+fa-24.10.2018
	public void setRootLitterCorrectionFactor(double rootLitterCorrectionFactor) {
		this.rootLitterCorrectionFactor = rootLitterCorrectionFactor;
	}

	public double getMycorrhizaeLitterFall_kgC() {
		return mycorrhizaeLitterFall_kgC;
	}

	// fa+mj-04.12.2017
	public double getFruitLitterFall_kgC() {
		return fruitLitterFall_kgC;
	}

	// fa+mj-04.12.2017
	public void setFruitLitterFall_kgC(double fruitLitterFall_kgC) {
		this.fruitLitterFall_kgC = fruitLitterFall_kgC;
	}

	public double getDeltaAboveGroundStructuralBiomass_kgC() {
		return deltaAboveGroundStructuralBiomass_kgC;
	}
	
	// fa-31.10.2018
	public double getDeltaDbh2Height() {
		return deltaDbh2Height;
	}
	
	// fa-02.11.2018
	public double getDeltaHeight() {
		return deltaHeight;
	}
	
	// fa-02.11.2018
	public double getDeltaG() {
		return deltaG;
	}

	public double getResidual() {
		return residual;
	}

	public double getStemAllocationCoefficient() {
		return stemAllocationCoefficient;
	}

	public double getRootAllocationCoefficient() {
		return rootAllocationCoefficient;
	}

	public double getBranchAllocationCoefficient() {
		return branchAllocationCoefficient;
	}

	public void setLeafBiomass(double leafBiomass) {
		this.leafBiomass_kgC = leafBiomass;
	}

	public void setFineRootBiomass(double fineRootBiomass) {
		this.fineRootBiomass_kgC = fineRootBiomass;
	}

	public void setHlce(double hlce) {
		this.hlce = hlce;
	}

	public void setHcb(double hcb) {
		this.hcb = hcb;
	}

	public void setRnorth(double rnorth) {
		this.rnorth = rnorth;
	}

	public void setReast(double reast) {
		this.reast = reast;
	}

	public void setRsouth(double rsouth) {
		this.rsouth = rsouth;
	}

	public void setRwest(double rwest) {
		this.rwest = rwest;
	}

	public void setSpecies(HetSpecies species) {
		this.species = species;

	}

	public void setParUseEfficiency(double parUseEfficiency) {
		this.parUseEfficiency = parUseEfficiency;
	}

	public void setGrossPrimaryProduction_kgC(double grossPrimaryProduction_kgC) {
		this.grossPrimaryProduction_kgC = grossPrimaryProduction_kgC;
	}

	public void setMaintenanceRespiration_kgC(double maintenanceRespiration_kgC) {
		this.maintenanceRespiration_kgC = maintenanceRespiration_kgC;
	}

	public void setLeafRetranslocation_kgC(double leafRetranslocation_kgC) {
		this.leafRetranslocation_kgC = leafRetranslocation_kgC;
	}

	public void setFineRootRetranslocation_kgC(double fineRootRetranslocation_kgC) {
		this.fineRootRetranslocation_kgC = fineRootRetranslocation_kgC;
	}

	public void setNetPrimaryProduction_kgC(double netPrimaryProduction_kgC) {
		this.netPrimaryProduction_kgC = netPrimaryProduction_kgC;
	}

	public void setTotalStructuralBiomassToAllocate_kgC(double totalStructuralBiomassToAllocate_kgC) {
		this.totalStructuralBiomassToAllocate_kgC = totalStructuralBiomassToAllocate_kgC;
	}

	public void setDeltaAboveGroundStructuralBiomass_kgC(double deltaAboveGroundStructuralBiomass_kgC) {
		this.deltaAboveGroundStructuralBiomass_kgC = deltaAboveGroundStructuralBiomass_kgC;
	}
	
	// fa-31.10.2018
	public void setDeltaDbh2Height(double deltaDbh2Height) {
		this.deltaDbh2Height = deltaDbh2Height;
	}
	
	// fa-02.11.2018
	public void setDeltaHeight(double deltaHeight) {
		this.deltaHeight = deltaHeight;
	}
	
	// fa-02.11.2018
	public void setDeltaG(double deltaG) {
		this.deltaG = deltaG;
	}

	public void setStemBiomass_kgC(double stemBiomass_kgC) {
		this.stemBiomass_kgC = stemBiomass_kgC;
	}

	public void setRootBiomass_kgC(double rootBiomass_kgC) {
		this.rootBiomass_kgC = rootBiomass_kgC;
	}

	public void setStemAllocationCoefficient(double stemAllocationCoefficient) {
		this.stemAllocationCoefficient = stemAllocationCoefficient;
	}

	public void setRootAllocationCoefficient(double rootAllocationCoefficient) {
		this.rootAllocationCoefficient = rootAllocationCoefficient;
	}

	public void setBranchAllocationCoefficient(double branchAllocationCoefficient) {
		this.branchAllocationCoefficient = branchAllocationCoefficient;
	}

	public void setBranchBiomass_kgC(double branchBiomass_kgC) {
		this.branchBiomass_kgC = branchBiomass_kgC;
	}

	public void setCrownForm(String crownForm) {
		this.crownForm = crownForm;
	}

	public void setInterceptedParRadiation(double interceptedParRadiation) {
		this.interceptedParRadiation = interceptedParRadiation;
	}

	public void setLightCompetitionIndex(double lightCompetitionIndex) {
		this.lightCompetitionIndex = lightCompetitionIndex;
	}

	public void setSRL(double sRL) {
		SRL = sRL;
	}

	public void setDeltaDbh_cm(double deltaDbh_cm) {
		this.deltaDbh_cm = deltaDbh_cm;
	}

	public void setNutrientStatusMap(HetElementState nutrientStatusMap) {
		this.nutrientStatusMap = nutrientStatusMap;
	}

	public double getHeightDelevoy() {
		return getHDelevoy(species, dbh, height);
	}

	public int getVirtualOriginalTreeId() {
		return virtualOriginalTreeId;
	}

	public void setVirtualOriginalTreeId(int virtualOriginalTreeId) {
		this.virtualOriginalTreeId = virtualOriginalTreeId;
	}

	public HetElementState getPotentialUptake() {
		return potentialUptake;
	}

	public void setPotentialUptake(HetElementState potentialUptake) {
		this.potentialUptake = potentialUptake;
	}

	public Map<String, Double> getHorizonPotentialUptake() {
		return horizonPotentialUptake;
	}

	public void setHorizonPotentialUptake(Map<String, Double> horizonPotentialUptake) {
		this.horizonPotentialUptake = horizonPotentialUptake;
	}

	public HetElementState getRequirement() {
		return requirement;
	}

	public void setRequirement(HetElementState requirement) {
		this.requirement = requirement;
	}

	public HetElementState getRetranslocation() {
		return retranslocation;
	}

	public void setRetranslocation(HetElementState retranslocation) {
		this.retranslocation = retranslocation;
	}

	public HetElementState getDemand() {
		return demand;
	}

	public void setDeficientDemand(HetElementState deficientDemand) {
		this.deficientDemand = deficientDemand;
	}

	public HetElementState getDeficientDemand() {
		return deficientDemand;
	}

	public void setOptimalDemand(HetElementState optimalDemand) {
		this.optimalDemand = optimalDemand;
	}

	public HetElementState getOptimalDemand() {
		return optimalDemand;
	}

	public void setDemand(HetElementState demand) {
		this.demand = demand;
	}

	public HetElementState getActualUptake() {
		return actualUptake;
	}

	public void setActualUptake(HetElementState actualUptake) {
		this.actualUptake = actualUptake;
	}

	// MOVED from HetModel.updateSoilChemistry() fc+mj+lw-6.9.2016
	public HetElementState getLitterNutrientReturn() {
		HetElementState litterNutrientReturn = new HetElementState();

		for (HetLitterCompartment lc : this.getLitterCompartments()) {

			for (String eName : HetTreeElement.elementNames) {
				double value = lc.getNutrientFlux(eName);

				litterNutrientReturn.addValue(eName, value);

			}
		}
		return litterNutrientReturn;
	}

	public double getLeafArea() {
		if (crownParts == null)
			return 0;
		double sum = 0;
		for (SLCrownPart cp : crownParts) {
			sum += cp.getLeafArea();
		}
		return sum;
	}

	public double getCrownVolume() {// MJ + LdW 23/08/2017
		if (crownParts == null)
			return 0;
		double sum = 0;
		for (SLCrownPart cp : crownParts) {
			sum += cp.getVolume();
		}
		return sum;
	}

	public double getCrownLAD() {// MJ + LdW 23/08/2017, m�/m�
		return this.getLeafArea() / this.getCrownVolume();

	}

	public double getCrownLength() {// MJ + LdW 23/08/2017, m
		return height - hcb;

	}

	public double getCrownProjection() {// MJ + LdW 23/08/2017, m�
		return (rnorth * reast + reast * rsouth + rsouth * rwest + rwest * rnorth) * Math.PI / 4; // MJ
																									// +
																									// LdW
																									// 23/08/2017
	}

	// public double getSunlitLeaf(){//MJ + LdW 23/08/2017, m�
	// HetTreeRadiationStatus radiationStatus = this.getRadiationStatus();
	// double a = 1 - Math.exp(-species.extinctionCoefficient *
	// this.getCrownLAD() * this.getCrownLength());
	// return a / species.extinctionCoefficient *
	// radiationStatus.lightCompetitionIndex * this. getCrownProjection(); //MJ
	// + LdW 23/08/2017
	// }

	// public double getShadedLeaf(){//MJ + LdW 23/08/2017, m�

	// return this.getLeafArea()-this.getSunlitLeaf(); //MJ + LdW 23/08/2017
	// }

	public double getFineRootToFoliageRatio() {
		return fineRootToFoliageRatio;
	}

	public void setFineRootToFoliageRatio(double fineRootToFoliageRatio) {
		this.fineRootToFoliageRatio = fineRootToFoliageRatio;
	}

	public double getNppToGppRatio() {
		return nppToGppRatio;
	}

	public void setNppToGppRatio(double nppToGppRatio) {
		this.nppToGppRatio = nppToGppRatio;
	}
	
	//fa-29.10.2018
	public double getNppToGppRatioForNextYear() {
		return nppToGppRatioForNextYear;
	}

	//fa-29.10.2018
	public void setNppToGppRatioForNextYear(double nppToGppRatioForNextYear) {
		this.nppToGppRatioForNextYear = nppToGppRatioForNextYear;
	}

	public double getStemBarkArea() { // m2

		double concC = treeCompartments.get(HetTreeCompartment.STEM).getConcentration(HetTreeElement.C);

		double stemDiameter = getTreeCompartment(HetTreeCompartment.STEM).diameter; // cm
		double stemBarkBiomass = stemBiomass_kgC / (concC / 1000d)
				* species.barkProportionFunction.result(stemDiameter); // kg_OM
		double stemBarkVolume = stemBarkBiomass / species.barkBulkDensity; // m3
		double stemBarkThickness = species.barkThicknessFunction.result(stemDiameter); // cm
		double stemBarkArea = stemBarkVolume / (stemBarkThickness / 100d); // m2

		return stemBarkArea;
	}

	public double getBranchBarkArea() { // m2

		List<HetTreeCompartment> branchCompartments = getTreeCompartmentsForType(HetTreeCompartment.TYPE_BRANCH);

		double bbaSum = 0;
		for (HetTreeCompartment c : branchCompartments) {
			double concC = treeCompartments.get(c.name).getConcentration(HetTreeElement.C);

			double branchDiameter = c.diameter; // cm
			double branchBarkBiomass = c.biomass / (concC / 1000d)
					* species.barkProportionFunction.result(branchDiameter); // kg_OM
			double branchBarkVolume = branchBarkBiomass / species.barkBulkDensity; // m3
			double branchBarkThickness = species.barkThicknessFunction.result(branchDiameter); // cm
			double branchBarkArea = branchBarkVolume / (branchBarkThickness / 100d); // m2
			bbaSum += branchBarkArea;
		}

		return bbaSum;
	}

	// public double getTranspiration() {
	// return transpiration;
	// }
	//
	// public void setTranspiration(double transpiration) {
	// this.transpiration = transpiration;
	// }

	public double getYearlyTranspiration() {
		return yearlyTranspiration;
	}

	public void setYearlyTranspiration(double yearlyTranspiration) {
		this.yearlyTranspiration = yearlyTranspiration;
	}

	public double getYearlyPotentialTranspiration() {
		return yearlyPotentialTranspiration;
	}

	public void setYearlyPotentialTranspiration(double yearlyPotentialTranspiration) {
		this.yearlyPotentialTranspiration = yearlyPotentialTranspiration;
	}

	public double getSapwoodArea(HetTreeCompartment tc) { // fc+mj+lw-19.10.2016
		if (tc.getType().equals(HetTreeCompartment.TYPE_LEAF)
				|| tc.getType().equals(HetTreeCompartment.TYPE_MYCORRHIZAE))
			return 0;

		// fa+mj-02.03.2018
		// OPTION 1
		double sapwoodArea1 = species.sapwoodArea.result(tc.diameter);

		// OPTION 2
		// fa+mj-04.09.2017: sapwood area calculated based on past growth
		double DBH_sapwood = (this.dbh - this.getPastDbh(species.sapwoodYearNumber));
		double sapwoodArea2 = 0d;
		if (tc.diameter > DBH_sapwood)
			sapwoodArea2 = tc.diameter / 2d * tc.diameter / 2d * Math.PI
					- (tc.diameter - DBH_sapwood) / 2d * (tc.diameter - DBH_sapwood) / 2d * Math.PI;
		else
			sapwoodArea2 = tc.diameter / 2d * tc.diameter / 2d * Math.PI;

		// OPTION 3
		double sapwoodArea3 = species.sapwoodArea.result(tc.diameter) * DBH_sapwood
				/ (species.defaultDeltaDbh * species.sapwoodYearNumber);

		// OPTION 4
		double basalArea = tc.diameter / 2d * tc.diameter / 2d * Math.PI;
		double sapwoodArea4 = sapwoodArea1;
		// mj+fa-09.02.2018
		double sapwoodProportion = 0d;
		if (this.getSpecies().getName().equals("quercus")) {
			double crownDevelopmentIndex = this.mean2CrownRadius / (this.dbh / 100d) * (this.height - this.hcb)
					/ this.height;
			sapwoodProportion = 1.5689657 - 0.683276 * Math.log(tc.diameter)
					+ 0.0754902 * Math.log(tc.diameter) * Math.log(tc.diameter) + 0.0159569 * crownDevelopmentIndex;
			sapwoodArea4 = basalArea * sapwoodProportion;
		}
		sapwoodArea4 = Math.min(sapwoodArea4, basalArea);

		// Option choice
		return sapwoodArea1;

		// fa+mj-04.09.2017: removed
		// return species.sapwoodArea.result(tc.diameter);

		// mj+fa-13.12.2017
		// double crownToStemDiameterRatio = this.mean2CrownRadius * 2 /
		// (this.dbh / 100d);
		// double sapwoodArea = species.sapwoodArea.result(tc.diameter);
		// if (species.getName().equals("quercus"))
		// sapwoodArea = species.sapwoodArea.result(tc.diameter) *
		// crownToStemDiameterRatio / 19d;
		// return sapwoodArea;

		// mj-13.12.2017
		// double DBH_sapwood = (dbh - getPastDbh(species.sapwoodYearNumber));
		// double sapwoodArea = species.sapwoodArea.result(tc.diameter);
		// if (this.getScene() != null) {
		// GScene s = this.getScene();
		// Step currentStep = (Step) s.getStep();
		// boolean isRootStep = currentStep.isRoot();
		// if (!isRootStep)
		// sapwoodArea = species.sapwoodArea.result(tc.diameter) *
		// DBH_sapwood/(species.defaultDeltaDbh*species.sapwoodYearNumber);
		// }

	}

	public double getMaintenanceLeafRespiration_kgC() {
		return maintenanceLeafRespiration_kgC;
	}

	public void setMaintenanceLeafRespiration_kgC(double maintenanceLeafRespiration_kgC) {
		this.maintenanceLeafRespiration_kgC = maintenanceLeafRespiration_kgC;
	}

	public void setDefoliation(double defoliation) {
		this.defoliation = defoliation;
	}

	public double getDefoliation() {
		return defoliation;
	}

	@Override
	public int getSpeciesCode() {
		return getSpecies().getValue();
	}

	@Override
	public double getEnergy_MJ() {
		return lightResult.getCrownEnergy();
	}
	
	
	
	
	//fa-06.12.2018
	public void setLADup(double LADup) {
		this.LADup = LADup;
	}
	
	public void setLADdown(double LADdown) {
		this.LADdown = LADdown;
	}
	
	public void setCrownVolumeUp(double crownVolumeUp) {
		this.crownVolumeUp = crownVolumeUp;
	}
	
	public void setCrownVolumeDown(double crownVolumeDown) {
		this.crownVolumeDown = crownVolumeDown;
	}
	
	public void setUflb(double uflb) {
		this.uflb = uflb;
	}
	
	public void setSLAup(double SLAup) {
		this.SLAup = SLAup;
	}
	
	public void setSLAdown(double SLAdown) {
		this.SLAdown = SLAdown;
	}
	
	public double getLADup() {
		return LADup;
	}
	
	public double getLADdown() {
		return LADdown;
	}
	
	public double getCrownVolumeUp() {
		return crownVolumeUp;
	}
	
	public double getCrownVolumeDown() {
		return crownVolumeDown;
	}
	
	public double getUflb() {
		return uflb;
	}
	
	public double getSLAup() {
		return SLAup;
	}
	
	public double getSLAdown() {
		return SLAdown;
	}

}
