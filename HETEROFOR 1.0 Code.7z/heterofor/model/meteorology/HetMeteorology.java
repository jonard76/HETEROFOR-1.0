/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.meteorology;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jeeb.lib.util.Alert;
import jeeb.lib.util.Translator;

/**
 * Meteorology knows meteo for a given period, loaded at start time.
 * 
 * @author M. Jonard, L. de Wergifosse, F. de Coligny - September 2016
 */
public class HetMeteorology implements Serializable {

	public static final String SEP = "_";
	
	/**
	 * True before first passing in the meteorology data duplication part of the completeBufferMap() method (case 
	 * year > lastYearInMeteoFile in this method). False after this first passing.
	 * Can be set to true again using the setMessagesStorageActivated() setter method.
	 */
	private boolean messagesStorageActivated;

	/**
	 * The first year for which meteorology data are available in the meteorology file.
	 */
	private int firstYearInMeteoFile;

	/**
	 * The last year for which meteorology data are available in the meteorology file.
	 */
	private int lastYearInMeteoFile;	

	/**
	 * The meteorology lines of the last year available in the meteorology file.
	 */
	private List<HetMeteoLine> meteoLinesOfLastYearInMeteoFile;
	
	/**
	 * Obtained after the reading of the meteorology file. Contains the meteorology data of the meteorology file and 
	 * is then never completed with other meteorology data (see bufferMap).
	 */
	private Map<HetDate, HetMeteoLine> meteoMap;

	/**
	 * Filled in with the meteorology data of meteoMap and then possibly completed if needed with meteorology data 
	 * of years that are greater than the last year of meteoMap.
	 * Key: year.
	 * Value: an ordered map with key: date (year, month, day, hour) and value: a meteorology line. 
	 */
	private Map<Integer, LinkedHashMap<HetDate, HetMeteoLine>> bufferMap;	

	private double windSpeedMeasurementHeight; // fc+mj+lw-18.10.2016
	private double windSpeedAttenuationCoefficient; // fc+mj+lw-18.10.2016

	static public class HetDate implements Comparable, Serializable {
		public int year;
		public int month;
		public int day;
		public int hour;

		public HetDate(int year, int month, int day, int hour) {
			this.year = year;
			this.month = month;
			this.day = day;
			this.hour = hour;
		}

		@Override
		public int compareTo(Object o) {
			
			HetDate otherDate = (HetDate) o;
			
			if (this.year < otherDate.year) {
				return -1;
			} else if (this.year > otherDate.year) {
				return 1;
			} else { // this.year == otherDate.year
				if (this.month < otherDate.month) {
					return -1;
				} else if (this.month > otherDate.month) {
					return 1;
				} else { // this.month == otherDate.month
					if (this.day < otherDate.day) {
						return -1;
					} else if (this.day > otherDate.day) {
						return 1;
					} else { // this.day == otherDate.day 
						if (this.hour < otherDate.hour) {
							return -1;
						} else if (this.hour > otherDate.hour) {
							return 1;
						} else { // this.hour == otherDate.hour 
							return 0;
						}
					}
				}
			}
			 
		}

		@Override
		public int hashCode() {

			// Suggestion: year*1000000 + month*10000 + day*100 + hour might be fine and < 2147483647 until year 2147
			// Note: 2147483647 = 2^31-1 is the maximum value of an int
			// fc+nb-20.9.2017 (year - 1500) enables a year range of 1500 -> 3647 turned into a technical range of 0 -> 2147
			return (year - 1500) * 1000000 + month * 10000 + day * 100 + hour;
		}

		@Override
		public boolean equals(Object obj) {

			return obj instanceof HetDate && year == ((HetDate) obj).year && month == ((HetDate) obj).month
					&& day == ((HetDate) obj).day && hour == ((HetDate) obj).hour;
		}

		@Override
		public String toString() {
			return year + SEP + month + SEP + day + SEP + hour;
		}

		/**
		 * Compares the dates given as parameters.
		 * 
		 * @param date1 Date to the "year_month_day_hour" or "year_month_day" format
		 * @param date2 Date to the "year_month_day_hour" or "year_month_day" format
		 * @param hourlyDates True if dates are hourly, false if dates are daily
		 * @return -1 if date1 is strictly lower than date2, 1 if date1 is strictly
		 *         greater than date2, 0 if date1 is equal to date2
		 */
		public static int compare(String date1, String date2, boolean hourlyDates) {

			String[] yearMonthDayHourDate1Tab = date1.split(HetMeteorology.SEP);
			String[] yearMonthDayHourDate2Tab = date2.split(HetMeteorology.SEP);

			if (hourlyDates) {

				// hourly dates

				int yearDate1 = Integer.valueOf(yearMonthDayHourDate1Tab[0]);
				int monthDate1 = Integer.valueOf(yearMonthDayHourDate1Tab[1]);
				int dayDate1 = Integer.valueOf(yearMonthDayHourDate1Tab[2]);
				int hourDate1 = Integer.valueOf(yearMonthDayHourDate1Tab[3]);

				int yearDate2 = Integer.valueOf(yearMonthDayHourDate2Tab[0]);
				int monthDate2 = Integer.valueOf(yearMonthDayHourDate2Tab[1]);
				int dayDate2 = Integer.valueOf(yearMonthDayHourDate2Tab[2]);
				int hourDate2 = Integer.valueOf(yearMonthDayHourDate2Tab[3]);

				if (yearDate1 < yearDate2) {
					return -1;
				} else if (yearDate1 > yearDate2) {
					return 1;
				} else {
					// yearDate1 == yearDate2
					if (monthDate1 < monthDate2) {
						return -1;
					} else if (monthDate1 > monthDate2) {
						return 1;
					} else {
						// monthDate1 == monthDate2
						if (dayDate1 < dayDate2) {
							return -1;
						} else if (dayDate1 > dayDate2) {
							return 1;
						} else {
							// dayDate1 == dayDate2
							if (hourDate1 < hourDate2) {
								return -1;
							} else if (hourDate1 > hourDate2) {
								return 1;
							} else {
								// hourDate1 == hourDate2
								return 0;
							}
						}
					}
				}

			} else {

				// daily dates

				int yearDate1 = Integer.valueOf(yearMonthDayHourDate1Tab[0]);
				int monthDate1 = Integer.valueOf(yearMonthDayHourDate1Tab[1]);
				int dayDate1 = Integer.valueOf(yearMonthDayHourDate1Tab[2]);

				int yearDate2 = Integer.valueOf(yearMonthDayHourDate2Tab[0]);
				int monthDate2 = Integer.valueOf(yearMonthDayHourDate2Tab[1]);
				int dayDate2 = Integer.valueOf(yearMonthDayHourDate2Tab[2]);

				if (yearDate1 < yearDate2) {
					return -1;
				} else if (yearDate1 > yearDate2) {
					return 1;
				} else {
					// yearDate1 == yearDate2
					if (monthDate1 < monthDate2) {
						return -1;
					} else if (monthDate1 > monthDate2) {
						return 1;
					} else {
						// monthDate1 == monthDate2
						if (dayDate1 < dayDate2) {
							return -1;
						} else if (dayDate1 > dayDate2) {
							return 1;
						} else {
							// dayDate1 == dayDate2
							return 0;
						}
					}
				}

			}
		}
	}

	/**
	 * Constructor
	 */
	public HetMeteorology() {

		messagesStorageActivated = true;
		firstYearInMeteoFile = Integer.MIN_VALUE;
		lastYearInMeteoFile = -1;
		meteoLinesOfLastYearInMeteoFile = null;
		meteoMap = new LinkedHashMap<>(); // Keep LinkedHashMap to keep the insertion order
		bufferMap = new HashMap<Integer, LinkedHashMap<HetDate, HetMeteoLine>>();
	}

	/**
	 * year, doy -> calendar, to get month, day
	 */
	public static GregorianCalendar getGregorianCalendar(int year, int doy) {

		GregorianCalendar cal = new GregorianCalendar();
		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.DAY_OF_YEAR, doy);

		return cal;
	}

	/**
	 * year, month, day -> doy (day of year in 1, 366))
	 */
	public static int doy(int year, int month, int day) {
		// Get doy
		Calendar cal = new GregorianCalendar();
		cal.set(year, month - 1, day); // month in [0,11]
		int _month = cal.get(Calendar.MONTH);
		int doy = cal.get(Calendar.DAY_OF_YEAR);
		int dom = cal.get(Calendar.DAY_OF_MONTH);
		int wom = cal.get(Calendar.WEEK_OF_MONTH);
		Date sDate = cal.getTime();
		return doy;
	}

	public void addMeteoLine(HetMeteoLine line) {

		HetDate key = new HetDate(line.year, line.month, line.day, line.hour);
		meteoMap.put(key, line);

		// The data in meteo file are ordered.
		if (firstYearInMeteoFile == Integer.MIN_VALUE) {			
			firstYearInMeteoFile = line.year;			
		}
		lastYearInMeteoFile = line.year;
	}

	public HetMeteoLine getMeteoLine(int year, int month, int day, int hour) throws Exception {

		completeBufferMap(year);
		
		// The hashCode() and equals() methods must be redefined in Key class
		HetDate date = new HetDate(year, month, day, hour);
		HetMeteoLine line = bufferMap.get(year).get(date);

		if (line == null)
			throw new Exception("HetMeteorology could not find meteo for date: " + date);

		return line;
	}

	

	
//	public Map<HetDate, HetMeteoLine> getMeteoMap() {
//
//		return meteoMap;
//	}

	/**
	 * Returns the ordered meteorology lines of the given year.
	 * @throws Exception 
	 */
	public ArrayList<HetMeteoLine> getMeteoLines(int year) throws Exception {

		//System.out.println("getMeteoLines, year: " + year);
		
		
//		ArrayList<HetMeteoLine> list = new ArrayList<>();
//		for (HetDate key : meteoMap.keySet()) {
//			if (key.year < year)
//				continue; // jump previous
//			else if (key.year == year)
//				list.add(meteoMap.get(key));
//			else
//				break; // next year was reached: over
//		}
//		return list;

		completeBufferMap(year);

		ArrayList<HetMeteoLine> list = new ArrayList<HetMeteoLine>(bufferMap.get(year).values());

		return list;
	}

	/**
	 * Complete the {@link bufferMap} for the given year. If year <= {@link lastYearInMeteoFile} the meteorology data of meteoMap are 
	 * simply copied. If year > {@link lastYearInMeteoFile} the meteorology data of the {@link lastYearInMeteoFile} are duplicated for 
	 * the given year.
	 * @throws Exception If year is strictly smaller than the first year in meteo file.
	 */
	private void completeBufferMap(int year) throws Exception {

		if (bufferMap.containsKey(year)) {
			return;
		}

		bufferMap.put(year, new LinkedHashMap<HetDate, HetMeteoLine>());

		if (year < firstYearInMeteoFile) {

			throw new Exception("Impossible to get meteo lines for date: " + year  
					+ " which is strictly smaller than the first year available in the meteo file: " + firstYearInMeteoFile);	
			
		} else if ((year >= firstYearInMeteoFile) && (year <= lastYearInMeteoFile)) {

			// The entries of meteoMap are ordered (meteoMap is a LinkedHashMap).
			for (HetDate date : meteoMap.keySet()) {
				if (date.year < year) {
					continue;
				} else if (date.year == year) {
					HetMeteoLine meteoLine = meteoMap.get(date);
					bufferMap.get(year).put(date, meteoLine);
				} else {
					break;
				}
			}

		} else {
			
			if (messagesStorageActivated) {
				Alert.storeMessage(Translator.swap("HetMeteorology.lastYearAvailableInMeteoFile") + ": " + lastYearInMeteoFile + "\n");
				Alert.storeMessage(Translator.swap("HetMeteorology.meteoDataDuplicatedForYear") + ": ");
				messagesStorageActivated = false;
			}
			
			// Store message each time the meteorology data are duplicated.
			// The whole stored messages are printed at the end of HetModel.initializeModel() (call 
			// to the Alert.printStoredMessages() method.			
//			Alert.storeMessage(Translator.swap("HetMeteorology.lastYearAvailableInMeteoFile") + ": " + lastYearInMeteoFile + ". " 
//					+ Translator.swap("HetMeteorology.meteoDataDuplicatedForYear") + ": " + year + ".");
			Alert.storeMessage("" + year);

			// Copy the meteo data of lastYearInMeteoFile.

			if (meteoLinesOfLastYearInMeteoFile == null) {
				meteoLinesOfLastYearInMeteoFile = getMeteoLines(lastYearInMeteoFile);
//				for (HetMeteoLine meteoLine : meteoLinesOfLastYear) {
//					System.out.println("meteoLine: " + meteoLine);
//				}
//				System.out.println("size: " + meteoLinesOfLastYear.size());
			}

			//System.exit(0);
			
			GregorianCalendar cal = new GregorianCalendar();

			if (cal.isLeapYear(lastYearInMeteoFile)) {
				
				for (HetMeteoLine meteoLine : meteoLinesOfLastYearInMeteoFile) {

					HetDate date = new HetDate(year, meteoLine.month, meteoLine.day, meteoLine.hour);

					HetMeteoLine newMeteoLine = new HetMeteoLine(meteoLine);
					newMeteoLine.year = year;

					bufferMap.get(year).put(date, newMeteoLine);
				}
				
				// Case 1: year is not a leap year. Delete all entries for 29/02/year.
				if (!cal.isLeapYear(year)) {
					for (int hour=0 ; hour<24 ; ++hour) {
						bufferMap.get(year).remove(new HetDate(year, 2, 29, hour));
					}						
				}
				
				// Case 2: nothing to do if year is a leap year.

			} else {

				//System.out.println("NON BISSEXTILE");
				
				// Case 1: year is a leap year. Add entries for 29/02/year (all hours of this date): the meteo data 
				// of 28/02/lastYearInMeteoFile are duplicated for 29/02/year.
				if (cal.isLeapYear(year)) {

					for (HetMeteoLine meteoLine : meteoLinesOfLastYearInMeteoFile) {

						HetDate date = new HetDate(year, meteoLine.month, meteoLine.day, meteoLine.hour);

						HetMeteoLine newMeteoLine = new HetMeteoLine(meteoLine);
						newMeteoLine.year = year;

						bufferMap.get(year).put(date, newMeteoLine);

						if ( (meteoLine.month == 2) && (meteoLine.day == 28) ) {
							bufferMap.get(year).put(new HetDate(year, 2, 29, meteoLine.hour), newMeteoLine);
						}
					}
				}
				
				// Case 2: nothing to do if year is not a leap year.
				for (HetMeteoLine meteoLine : meteoLinesOfLastYearInMeteoFile) {

					HetDate date = new HetDate(year, meteoLine.month, meteoLine.day, meteoLine.hour);

					HetMeteoLine newMeteoLine = new HetMeteoLine(meteoLine);
					newMeteoLine.year = year;

					bufferMap.get(year).put(date, newMeteoLine);
				}
			}

		}
	}

	// fa-26.07.2017
	/**
	 * Returns the ordered meteorology lines over the period delimited by startYear and endYear.
	 * @throws Exception 
	 */
	public ArrayList<HetMeteoLine> getMeteoLines(int startYear, int endYear) throws Exception {

//		ArrayList<HetMeteoLine> list = new ArrayList<>();
//		for (HetDate key : meteoMap.keySet()) {
//			if (key.year < startYear)
//				continue; // jump previous
//			else if (key.year >= startYear && key.year <= endYear)
//				list.add(meteoMap.get(key));
//			else
//				break; // end of endYear was reached: over
//		}
//		return list;

		ArrayList<HetMeteoLine> list = new ArrayList<>();

		for (int year = startYear ; year <= endYear ; year++) {
			list.addAll(getMeteoLines(year));
		}

		return list;
	}
	
	/**
	 * Calculates and returns the average air temperature of each day of the
	 * given ordered meteorological lines of a year.
	 * 
	 * @param meteoLinesOfYear
	 *            The list of ordered meteorological lines of a year
	 * @return An ordered map with key: year_month_day string and value: the
	 *         daily average air temperature of the day
	 */
	static public LinkedHashMap<String, Double> calculateDailyAverageAirTemperature(List<HetMeteoLine> meteoLinesOfYear) {

		// Map with key: a year_month_day string, value: the daily average air
		// temperature
		LinkedHashMap<String, Double> dateDailyAverageAirTemperatureMap = new LinkedHashMap<String, Double>();

		// Initialization
		int currentDay = -1;
		double sum = 0.0;
		int cptHour = 0;
		double dailyAverageAirTemperature = 0.0;

		for (HetMeteoLine meteoLine : meteoLinesOfYear) {

			// Calculate average daily airTemperature

			if (currentDay < 0 || meteoLine.day == currentDay) {
				sum += meteoLine.airTemperature;
				cptHour++;
				currentDay = meteoLine.day;
				if (meteoLine.hour < 23)
					continue;
			}

			dailyAverageAirTemperature = sum / cptHour;

			dateDailyAverageAirTemperatureMap.put(meteoLine.year + SEP + meteoLine.month + SEP + meteoLine.day,
					dailyAverageAirTemperature);

			sum = 0.0;
			cptHour = 0;
			currentDay = -1;
		}

		return dateDailyAverageAirTemperatureMap;
	}

	/**
	 * Calculates and returns the average wind speed of each day of the given
	 * ordered meteorological lines of a year.
	 * 
	 * @param meteoLinesOfYear
	 *            The list of ordered meteorological lines of a year
	 * @return An ordered map with key: year_month_day string and value: the
	 *         daily average wind speed of the day
	 */
	static public LinkedHashMap<String, Double> calculateDailyAverageWindSpeed(List<HetMeteoLine> meteoLinesOfYear) {

		// Map with key: a year_month_day string, value: the daily average wind
		// speed
		LinkedHashMap<String, Double> dateDailyAverageWindSpeedMap = new LinkedHashMap<String, Double>();

		// Initialization
		int currentDay = -1;
		double sum = 0.0;
		int cptHour = 0;
		double dailyAverageWindSpeed = 0.0;

		for (HetMeteoLine meteoLine : meteoLinesOfYear) {

			// Calculate average daily wind speed

			if (currentDay < 0 || meteoLine.day == currentDay) {
				sum += meteoLine.windSpeed;
				cptHour++;
				currentDay = meteoLine.day;
				if (meteoLine.hour < 23)
					continue;
			}

			dailyAverageWindSpeed = sum / cptHour;

			dateDailyAverageWindSpeedMap.put(meteoLine.year + SEP + meteoLine.month + SEP + meteoLine.day,
					dailyAverageWindSpeed);

			sum = 0.0;
			cptHour = 0;
			currentDay = -1;
		}

		return dateDailyAverageWindSpeedMap;
	}

	// fa-26.07.2017
	/**
	 * For each day of the given ordered meteorological lines of a year,
	 * calculates and returns the average air temperature over the preceding
	 * period of length 'nDays'.
	 * 
	 * @param meteorology
	 *            : Meteorological lines
	 * @param year
	 *            : Year considered for computations
	 * @param nDays
	 *            : Number of days in the preceding period (current day
	 *            excluded)
	 * @return An ordered map with key: year_month_day string and value: the
	 *         average air temperature over the preceding days
	 * @throws Exception 
	 */
	static public LinkedHashMap<String, Double> calculateAverageAirTemperatureOverPrecedingPeriod(
			HetMeteorology meteorology, int year, int nDays) throws Exception {

		// Map with key: a year_month_day string, value: the average air
		// temperature
		LinkedHashMap<String, Double> dateAverageAirTemperatureOverPrecedingPeriodMap = new LinkedHashMap<String, Double>();

		// Select meteo lines from previous and current years
		ArrayList<HetMeteoLine> meteoLinesOfYearBefore = meteorology.getMeteoLines(year - 1);
		ArrayList<HetMeteoLine> meteoLinesOfYear = meteorology.getMeteoLines(year);

		// Average daily temperatures
		LinkedHashMap<String, Double> dateDailyAverageAirTemperatureOfYearBeforeMap = calculateDailyAverageAirTemperature(meteoLinesOfYearBefore);
		LinkedHashMap<String, Double> dateDailyAverageAirTemperatureOfYearMap = calculateDailyAverageAirTemperature(meteoLinesOfYear);

		// Convert maps to lists
		List<String> keyOfYearBefore = new ArrayList<String>(dateDailyAverageAirTemperatureOfYearBeforeMap.keySet());
		List<Double> dailyAverageAirTemperatureOfYearBefore = new ArrayList<Double>(
				dateDailyAverageAirTemperatureOfYearBeforeMap.values());
		List<String> keyOfYear = new ArrayList<String>(dateDailyAverageAirTemperatureOfYearMap.keySet());
		List<Double> dailyAverageAirTemperatureOfYear = new ArrayList<Double>(
				dateDailyAverageAirTemperatureOfYearMap.values());

		// Construct final lists
		ArrayList<String> lastKeyOfYearBefore = new ArrayList<>(keyOfYearBefore.subList(keyOfYearBefore.size() - nDays,
				keyOfYearBefore.size())); // Select the last #nDays keys of the
											// preceding year
		keyOfYear.addAll(0, lastKeyOfYearBefore); // Add last keys of the
													// preceding year at the
													// beginning (index = 0) of
													// keys of current year
		ArrayList<Double> lastDailyAverageTemperatureOfYearBefore = new ArrayList<>(
				dailyAverageAirTemperatureOfYearBefore.subList(dailyAverageAirTemperatureOfYearBefore.size() - nDays,
						dailyAverageAirTemperatureOfYearBefore.size())); // Select
																			// the
																			// last
																			// #nDays
																			// temperature
																			// average
																			// values
																			// of
																			// the
																			// preceding
																			// year
		dailyAverageAirTemperatureOfYear.addAll(0, lastDailyAverageTemperatureOfYearBefore); // Add
																								// last
																								// temperature
																								// average
																								// values
																								// of
																								// the
																								// preceding
																								// year
																								// at
																								// the
																								// beginning
																								// (index
																								// =
																								// 0)
																								// of
																								// temperature
																								// average
																								// values
																								// of
																								// current
																								// year

		// System.out.println("FirstKeyPrev = " + lastKeyOfYearBefore.get(0) +
		// ", LastKeyPrev = "
		// + lastKeyOfYearBefore.get(lastKeyOfYearBefore.size() - 1) +
		// ", FirstKeyCurrent = "
		// + keyOfYear.get(lastKeyOfYearBefore.size()));

		// Initialization: set window on the first #nDays daily average
		// temperatures and initial computations
		ArrayList<Double> dailyAverageAirTemperatureWindow = new ArrayList<>(dailyAverageAirTemperatureOfYear.subList(
				0, nDays + 1)); // +1 to include current day (first day of
								// current year)
		ArrayList<String> keyOfYearWindow = new ArrayList<>(keyOfYear.subList(0, nDays + 1)); // +1
																								// to
																								// include
																								// current
																								// day
																								// (first
																								// day
																								// of
																								// current
																								// year)
		// Calculate mean
		double sumTemp = 0;
		for (Double dailyAverageAirTemperature : dailyAverageAirTemperatureWindow) {
			sumTemp += dailyAverageAirTemperature;
		}
		double meanTemp = sumTemp / (nDays + 1);

		dateAverageAirTemperatureOverPrecedingPeriodMap.put(keyOfYearWindow.get(keyOfYearWindow.size() - 1), meanTemp);
		// End of initialization

		// Moving window loop over current year
		double tempRemovedLine;
		double tempLastLine;
		for (int i = nDays + 1; i < dailyAverageAirTemperatureOfYear.size(); i++) { // i
																					// is
																					// the
																					// index
																					// of
																					// dailyAverageAirTemperatureOfYear
																					// corresponding
																					// to
																					// the
																					// day
																					// for
																					// which
																					// the
																					// period
																					// average
																					// is
																					// calculated

			// Move window
			tempRemovedLine = dailyAverageAirTemperatureWindow.get(0); // Save
																		// temperature
																		// of
																		// the
																		// first
																		// line,
																		// which
																		// will
																		// be
																		// removed
																		// when
																		// moving
																		// window
			dailyAverageAirTemperatureWindow.remove(0); // Remove first line
			dailyAverageAirTemperatureWindow.add(dailyAverageAirTemperatureOfYear.get(i)); // Add
																							// line
																							// at
																							// last
																							// position
			tempLastLine = dailyAverageAirTemperatureWindow.get(dailyAverageAirTemperatureWindow.size() - 1); // Air
																												// temperature
																												// of
																												// the
																												// last
																												// line
			keyOfYearWindow.remove(0);
			keyOfYearWindow.add(keyOfYear.get(i));

			// Update mean temperature
			sumTemp = sumTemp - tempRemovedLine + tempLastLine;
			meanTemp = sumTemp / (nDays + 1);

			dateAverageAirTemperatureOverPrecedingPeriodMap.put(keyOfYear.get(i), meanTemp);

			// System.out.println("Loop = " + i + ", CurrentDayKey = " +
			// keyOfYear.get(i) + ", FirstDayKeyWindow = "
			// + keyOfYearWindow.get(0));
		}

		// System.out.println("WindowFirstKeyPrev = " + keyOfYearWindow.get(0) +
		// ", WindowLastKeyPrev = "
		// + keyOfYearWindow.get(keyOfYearWindow.size() - 2) +
		// ", WindowFirstKeyCurrent = "
		// + keyOfYearWindow.get(keyOfYearWindow.size() - 1));

		return dateAverageAirTemperatureOverPrecedingPeriodMap;

		/*
		 * // Select meteo lines from previous and current years
		 * ArrayList<HetMeteoLine> meteoLinesOfYearBefore =
		 * meteorology.getMeteoLines(year - 1); ArrayList<HetMeteoLine>
		 * meteoLinesOfYear = meteorology.getMeteoLines(year); // Construct
		 * final list ArrayList<HetMeteoLine> lastMeteoLinesOfYearBefore = new
		 * ArrayList
		 * <>(meteoLinesOfYearBefore.subList(meteoLinesOfYearBefore.size() -
		 * (nHours-24), meteoLinesOfYearBefore.size())); // Select the last
		 * #(nHours-24) meteo lines of the preceding year: nHours-24 for not
		 * considering the first day of the current year
		 * meteoLinesOfYear.addAll(0, lastMeteoLinesOfYearBefore); // Add last
		 * meteo lines of the preceding year at the beginning (index = 0) of
		 * meteo lines of current year
		 * 
		 * // Initialization: set window on the first #nHours meteo lines and
		 * initial computations ArrayList<HetMeteoLine> meteoLinesWindow = new
		 * ArrayList<>(meteoLinesOfYear.subList(0 , nHours)); // Meteo line
		 * window
		 * 
		 * // Calculate mean double sumTemp = 0; for (HetMeteoLine meteoLine :
		 * meteoLinesWindow){ sumTemp += meteoLine.airTemperature; } double
		 * meanTemp = sumTemp / nHours;
		 * 
		 * dateAverageAirTemperatureOverPrecedingPeriodMap.put(meteoLinesWindow.get
		 * (nHours).year + "_" + meteoLinesWindow.get(nHours).month + "_" +
		 * meteoLinesWindow.get(nHours).day + "_" +
		 * meteoLinesWindow.get(nHours).hour, meanTemp);
		 * 
		 * 
		 * 
		 * return dateAverageAirTemperatureOverPrecedingPeriodMap;
		 */
	}

	/**
	 * Identifies and returns the frost state (true or false) of each day of the
	 * given ordered meteorological lines of a year. The rules for calculating
	 * the frost state of a day are: 1) If 5 consecutive frost hours (5
	 * consecutive hours with air temperature < 0) are detected (eventually over
	 * two days) and finish before 12h, then the status frostDay=true is
	 * associated to the current day. 2) If 5 consecutive frost hours (5
	 * consecutive hours with air temperature < 0) are detected and finish after
	 * 12h (eventually can begin before 12h and finish after 12h), then the
	 * status frostDay=false is associated to the current day and the status
	 * frostDay=true is associated to the following day. 3) As soon as the
	 * status of a day is set to frostDay=true, the status of all the following
	 * days are set to frostDay=true.
	 * 
	 * @param meteoLinesOfYear
	 *            The list of ordered meteorological lines of a year
	 * @return An ordered map with key: year_month_day string and value: true if
	 *         the day is a frost day, false otherwise according to the above
	 *         rules.
	 */
	static public LinkedHashMap<String, Boolean> identifyFrostDays(int initMonth, int initDay,
			List<HetMeteoLine> meteoLinesOfYear) {

		// Map with key: a year_month_day string, value: the frost state of the
		// day
		LinkedHashMap<String, Boolean> dateFrostDayMap = new LinkedHashMap<String, Boolean>();

		// Initialization
		boolean frostDayFound = false;
		boolean frostDay = false;
		int cptConsecutiveFrostHours = 0;

		// 1 meteoLine = 1 hour
		for (HetMeteoLine meteoLine : meteoLinesOfYear) {

			if (meteoLine.month < initMonth)
				continue;

			if (meteoLine.month == initMonth && meteoLine.day < initDay)
				continue;

			if (!frostDayFound) {

				double airTemperature = meteoLine.airTemperature;

				if (airTemperature < 0.0) {
					++cptConsecutiveFrostHours;
				} else {
					cptConsecutiveFrostHours = 0;
				}

				if (cptConsecutiveFrostHours == 5 && meteoLine.hour <= 12) {
					frostDayFound = true;
					frostDay = true;
				}

				if (cptConsecutiveFrostHours == 5 && meteoLine.hour > 12) {
					frostDayFound = true;
					frostDay = false;
				}

			}

			if (meteoLine.hour == 23) {
				dateFrostDayMap.put(meteoLine.year + SEP + meteoLine.month + SEP + meteoLine.day, frostDay);
				if (frostDayFound)
					frostDay = true;
			}
		}

		return dateFrostDayMap;
	}

	// fa-26.01.2018
	public int getFirstYearInMeteoFile() {
		return firstYearInMeteoFile;
	}
	
	public int getLastYearInMeteoFile() {
		return lastYearInMeteoFile;
	}

	public void setMessagesStorageActivated(boolean messagesStorageActivated) {
		this.messagesStorageActivated = messagesStorageActivated;
	}

	public double getWindSpeedMeasurementHeight() {
		return windSpeedMeasurementHeight;
	}

	public void setWindSpeedMeasurementHeight(double windSpeedMeasurementHeight) {
		this.windSpeedMeasurementHeight = windSpeedMeasurementHeight;
	}

	public double getWindSpeedAttenuationCoefficient() {
		return windSpeedAttenuationCoefficient;
	}

	public void setWindSpeedAttenuationCoefficient(double windSpeedAttenuationCoefficient) {
		this.windSpeedAttenuationCoefficient = windSpeedAttenuationCoefficient;
	}

	public String toString() {
		return "HetMeteorology: " + meteoMap.size() + " lines";

	}

}
