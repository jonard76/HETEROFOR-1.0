package heterofor.model;

import java.util.Map;
import java.util.Random;

import capsis.lib.regeneration.RGCell;
import capsis.lib.regeneration.RGCohort;
import capsis.lib.regeneration.RGCohortSizeClass;

/**
 * A size class in a HetCohort.
 * 
 * @author M. Jonard, B. Ryelandt, N. Donès, F. de Coligny - October 2018
 */
public class HetCohortSizeClass extends RGCohortSizeClass {

	// fc+mj+br-4.10.2018 Keep a ref at last processLighting () call time,
	// available for understoreyGrowth () call time
	protected double incidentEnergy; // MJ/year

	// fc+mj+br-4.10.2018 this reference must be set every year before calling
	// understoreyGrowth()
	protected Map<String, HetWaterBalance> waterBalanceMap;

	protected double leafAreaAvg; // m2
	protected double biomassAvg; // kgC
	protected double crownProjectionAvg; // m2

	protected double yearlyNPPAvg_kgC;
	protected double yearlyGPP_kgC;
	
	//fa-29.10.2018
	protected double crownToStemDiameter;

	/**
	 * Constructor.
	 */
	public HetCohortSizeClass(int id, HetCohort cohort, double heightAvg, double diameterAvg, int number) {
		// fc-3.10.2018 Added cohort
		super(id, cohort, heightAvg, diameterAvg, number);
	}

	/**
	 * Calculates the energy intercepted by this object and returns the
	 * remaining energy.
	 * 
	 * @param energy
	 *            : available above the object
	 * @param incidentEnergy
	 *            : total energy above canopy
	 * @return energy available below the object
	 */
	@Override
	public double processLighting(RGCell cell, double incidentEnergy, double aboveEnergy) {

		this.incidentEnergy = incidentEnergy;

		HetSpecies sp = (HetSpecies) cohort.getSpecies();

		double cellArea = cell.getArea(); // m2
		double plotArea = cell.getPlot().getArea(); // m2

		if (leafAreaAvg == 0)
			init(cell);

		double classLai = (number * leafAreaAvg) / (cellArea * cover);

		double aboveEnergy_MJm2 = aboveEnergy / cellArea;

		double belowEnergy_MJm2 = (1 - cover) * aboveEnergy_MJm2
				+ cover * aboveEnergy_MJm2 * Math.exp(-sp.extinctionCoefficient * classLai);

		// Transmittance above size class
		transmittance = ((aboveEnergy_MJm2) / (incidentEnergy / cellArea)) * 100;

		// Set absorbed energy in MJ
		setEnergy_MJ((aboveEnergy_MJm2 - belowEnergy_MJm2) * cellArea);

		// Set energy available above Cohort Size Clase
		setEnergy_Above_MJ(aboveEnergy_MJm2 * cellArea);

		// Set energy available below Cohort Size Clase
		setEnergy_Below_MJ(belowEnergy_MJm2 * cellArea);

		if (getEnergy_MJ() == 0)
			HetReporter.printInStandardOutput("Breakpoint in HetCohortSizeClass");

		// Returns energy (remaining) below the saplings in MJ
		return belowEnergy_MJm2 * cellArea;

	}

	/**
	 * Called at first processLightingTime to init the size class.
	 */
	private void init(RGCell cell) {
		
		HetCell refCell = (HetCell) cell;

		// heightAvg comes from the inventory file
		
		// Initialise transmittance for init time
		transmittance = 15;

		updateSeedlingCharacteristics (refCell, this);

		// number comes from the inventory file

		// Cover
		cover = (number * crownProjectionAvg) / refCell.getArea();
		cover = Math.min(cover, 1d);

	}

	/**
	 * Updates the other characteristics of the seedling from heightAvg and transmittance.
	 */
	private void updateSeedlingCharacteristics (HetCell refCell, 
			HetCohortSizeClass klass) { 
		
		HetScene refScene = (HetScene) refCell.getPlot().getScene();
		HetModel model = (HetModel) refScene.getStep().getProject().getModel();
		HetInitialParameters ip = (HetInitialParameters) model.getSettings();
		HetSpecies sp = (HetSpecies) cohort.getSpecies();
		
//		double crownToStemDiameter = 0; // fa-29.10.2018: commented
		klass.crownToStemDiameter = 0;
		
		if (klass.heightAvg < 3) {

			// Trunk diameter (cm) at 0.1 m
			klass.diameterAvg = klass.heightAvg / sp.seedlingHeightToDiameterRatio.result(klass.transmittance, klass.heightAvg) * 100d;

			double aboveBiomassAvg = klass.heightAvg * 0.1; // to be reviewed
			klass.biomassAvg = aboveBiomassAvg + sp.rootToShootRatio * aboveBiomassAvg;

			// To be reviewed
			klass.leafAreaAvg = klass.heightAvg * 0.1;

			// Temporary
//			crownToStemDiameter = 160; //fa-29.10.2018: commented
			klass.crownToStemDiameter = 160;
//			crownToStemDiameter = Math.min(sp.crownToStemDiameterEstimation.result(klass.diameterAvg * Math.PI), 160d);


		} else { // heightAvg >= 3 m

			// Trunk diameter (cm) at 1.3
			klass.diameterAvg = sp.treeHeight.getDbh(heightAvg);

			// Temporary
			double mean2CrownRadius_m = 20 * (klass.diameterAvg / 200d);

			// Warning, when changing the line below, check the same line in
			// init ()
			double newLeafBiomassAvg = sp.leafBiomassAllometry.result(klass.diameterAvg, klass.diameterAvg + sp.defaultDeltaDbh,
					mean2CrownRadius_m, sp.leafRetranslocationRate);

			// Less temporary
			double sla = sp.SLAtop + (sp.SLAbottom - sp.SLAtop) * (100 - klass.transmittance) / 100d;
			klass.leafAreaAvg = newLeafBiomassAvg * 1000d / 510d * sla;

			double diameterAvg_m = klass.diameterAvg / 100d;

			double aboveBiomassAvg = sp.aboveBiomassAlpha
					+ sp.aboveBiomassBeta * Math.pow(diameterAvg_m * diameterAvg_m * klass.heightAvg, sp.aboveBiomassGamma);

			klass.biomassAvg = aboveBiomassAvg + sp.rootToShootRatio * aboveBiomassAvg;
			klass.biomassAvg = klass.biomassAvg + sp.maxFineRootToFoliageRatio * klass.biomassAvg;

//			crownToStemDiameter = Math.min(sp.crownToStemDiameterEstimation.result(klass.diameterAvg * Math.PI), 160d); //fa-29.10.2018: commented
			klass.crownToStemDiameter = Math.min(sp.crownToStemDiameterEstimation.result(klass.diameterAvg * Math.PI), 160d);


		}
		
		double crownRadius_m = crownToStemDiameter * klass.diameterAvg / 200d;
		klass.crownProjectionAvg = Math.PI * crownRadius_m * crownRadius_m;
		
		
	}
	
	
	@Override
	public HetCohortSizeClass understoreyGrowth(RGCohort cohort, RGCell cell) throws Exception {

		HetCohortSizeClass newCohortSizeClass = (HetCohortSizeClass) this.clone();
		
		HetCell refCell = (HetCell) cell;
		HetScene refScene = (HetScene) refCell.getPlot().getScene();
		HetModel model = (HetModel) refScene.getStep().getProject().getModel();
		HetInitialParameters ip = (HetInitialParameters) model.getSettings();
		int newYear = refScene.getDate() + 1;
		HetSpecies sp = (HetSpecies) cohort.getSpecies();

		newCohortSizeClass.growthHeight = sp.seedlingHeightGrowth.result(transmittance, heightAvg);
		newCohortSizeClass.heightAvg = heightAvg + newCohortSizeClass.growthHeight;

		// Transmittance was set by processLighting ()
		
		updateSeedlingCharacteristics (refCell, newCohortSizeClass);
		
		double nppAvg_kgC = newCohortSizeClass.biomassAvg - this.getBiomassAvg();
		
		// Default number: copied
		int newNumber = number; // to be reviewed (parUseEfficiency approach)

		// fc+mj+br-4.10.2018 If available, use photosynthesis to update number
		double yearlyGPP_kgC = 0;
		if (ip.castaneaPhotosynthesisActivated && ip.waterBalanceActivated && ip.meteorology != null) {

			double sla = sp.SLAtop + (sp.SLAbottom - sp.SLAtop) * (100 - transmittance) / 100d;
			
			HetSeedlingCastaneaPhotosynthesis scp = new HetSeedlingCastaneaPhotosynthesis(ip, refScene, refCell, this,
					sla, model, newYear);
			scp.run();
			yearlyGPP_kgC = scp.getYearlyGPP_kgC();

//			double classNPP = yearlyGPP_kgC * sp.nppToGppRatio; //fa-29.10.2018: commented, not applicable if nppToGppRatio = f(DdIndex)
			//fa-29.10.2018
			double c130Avg = sp.treeHeight.getDbh(heightAvg) * Math.PI;
			double crownToStemDiameterIndex = newCohortSizeClass.crownToStemDiameter / Math.min(sp.crownToStemDiameterEstimation.result(c130Avg), 160d);
			double nppToGppRatio = sp.nppToGppRatio_intercept + sp.nppToGppRatio_slope * crownToStemDiameterIndex;
			double classNPP = yearlyGPP_kgC * nppToGppRatio;

			newNumber = (int) (classNPP / nppAvg_kgC);
			newNumber = Math.min(newNumber, number);

		}
		newCohortSizeClass.number = newNumber;
		
		// Cover
		newCohortSizeClass.cover = (newCohortSizeClass.number * newCohortSizeClass.crownProjectionAvg) / refCell.getArea();
		newCohortSizeClass.cover = Math.min(newCohortSizeClass.cover, 1d);

		newCohortSizeClass.setYearlyNPPAvg_kgC(nppAvg_kgC);
		newCohortSizeClass.setYearlyGPP_kgC(yearlyGPP_kgC);

		return newCohortSizeClass;
	}

	/**
	 * The sizeClass is turned into adult trees
	 */
	public void recruit(HetCohort cohort, HetModel model, HetScene scene, HetCell cell) throws Exception {

		HetInitialParameters ip = model.getSettings();

		for (int j = 0; j < getNumber(); j++) {
			Random random = model.getRandom();
			int id = model.getTreeIdDispenser().getNext();

			double x = cell.getX() + random.nextDouble() * cell.getWidth();
			double y = cell.getY() + random.nextDouble() * cell.getWidth();
			double z = cell.getZ();

			HetSpecies sp = cohort.getSpecies();

			double height = this.getHeightAvg();
			
			double dbh = sp.treeHeight.getDbh(height);
					
			double hlce = height * sp.hlceHeightProportion;
			double hcb = height * sp.hcbHeightProportion;
			double c130_cm = dbh * Math.PI;

			double ctsd = sp.crownToStemDiameterEstimation.result(c130_cm);
			ctsd = Math.min(ctsd, 160);

			double rnorth = ctsd * dbh / 2d / 100d;

			double reast = rnorth;
			double rsouth = rnorth;
			double rwest = rnorth;

			HetTree newTree = new HetTree(id, scene, sp, dbh, height, hlce, hcb, rnorth, reast, rsouth, rwest, x, y, z,
					sp.crownForm, ip.treeChemistryDistribution, ip.foliarChemistryThresholds,
					ip.treeConcentrationLines);

			newTree.finishTreeInitialisation(ip);

			scene.addTree(newTree);
		}

	}

	public double getLeafAreaAvg() {
		return leafAreaAvg;
	}

	public void setLeafAreaAvg(double leafAreaAvg) {
		this.leafAreaAvg = leafAreaAvg;
	}

	public double getBiomassAvg() {
		return biomassAvg;
	}

	public void setBiomassAvg(double biomassAvg) {
		this.biomassAvg = biomassAvg;
	}

	public double getCrownProjectionAvg() {
		return crownProjectionAvg;
	}

	public void setCrownProjectionAvg(double crownProjectionAvg) {
		this.crownProjectionAvg = crownProjectionAvg;
	}

	public double getYearlyNPPAvg_kgC() {
		return yearlyNPPAvg_kgC;
	}

	public void setYearlyNPPAvg_kgC(double yearlyNPPAvg_kgC) {
		this.yearlyNPPAvg_kgC = yearlyNPPAvg_kgC;
	}

	public double getYearlyGPP_kgC() {
		return yearlyGPP_kgC;
	}

	public void setYearlyGPP_kgC(double yearlyGPP_kgC) {
		this.yearlyGPP_kgC = yearlyGPP_kgC;
	}

	public void setIncidentEnergy(double incidentEnergy) {
		this.incidentEnergy = incidentEnergy;
	}

	public double getIncidentEnergy() {
		return incidentEnergy;
	}

	public Map<String, HetWaterBalance> getWaterBalanceMap() {
		return waterBalanceMap;
	}

	public void setWaterBalanceMap(Map<String, HetWaterBalance> waterBalanceMap) {
		this.waterBalanceMap = waterBalanceMap;
	}

}
