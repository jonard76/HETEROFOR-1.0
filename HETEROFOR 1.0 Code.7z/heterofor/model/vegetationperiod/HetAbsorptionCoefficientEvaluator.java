/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.vegetationperiod;

import heterofor.model.HetScene;
import heterofor.model.HetTree;
import heterofor.model.fineresolutionradiativebalance.HetAverageRadiation;
import heterofor.model.fineresolutionradiativebalance.HetKeyDoy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jeeb.lib.util.ListMapThreadSafe;
import capsis.lib.samsaralight.tag.SLTag;
import capsis.lib.samsaralight.tag.SLTagTreeResult;
//fa 31.05.2017

/**
 * Absorption coefficients
 * 
 * @author F. André, F. de Coligny - May 2017
 */
public class HetAbsorptionCoefficientEvaluator {

	private static class RefDoy {

		private int doy; // [1, 365]
		private double[] crownDirectCoefValue; // index: 0-23
		private double[] crownDiffuseCoefValue; // index: 0-23
		// fa-22.12.2017
		private double[] crownPotentialCoefValue; // index: 0-23
		// fc+mj+fa-27.7.2017 added barkCoefValue
		private double[] barkCoefValue; // index: 0-23

		/**
		 * Constructor
		 */
		public RefDoy(int doy) {
			this.doy = doy;
		}

		public int getDoy() {
			return doy;
		}

		public void addCrownDirectCoefValue(int hour, double value) {
			if (crownDirectCoefValue == null)
				crownDirectCoefValue = new double[24];
			crownDirectCoefValue[hour] = value;
		}

		public double getCrownDirectCoefValue(int hour) {
			if (crownDirectCoefValue == null)
				return 0;
			return crownDirectCoefValue[hour];
		}

		public void addCrownDiffuseCoefValue(int hour, double value) {
			if (crownDiffuseCoefValue == null)
				crownDiffuseCoefValue = new double[24];
			crownDiffuseCoefValue[hour] = value;
		}

		public double getCrownDiffuseCoefValue(int hour) {
			if (crownDiffuseCoefValue == null)
				return 0;
			return crownDiffuseCoefValue[hour];
		}
		
		// fa-22.12.2017
		public void addCrownPotentialCoefValue(int hour, double value) {
			if (crownPotentialCoefValue == null)
				crownPotentialCoefValue = new double[24];
			crownPotentialCoefValue[hour] = value;
		}
		
		// fa-22.12.2017
		public double getCrownPotentialCoefValue(int hour) {
			if (crownPotentialCoefValue == null)
				return 0;
			return crownPotentialCoefValue[hour];
		}

		public void addBarkCoefValue(int hour, double value) {
			if (barkCoefValue == null)
				barkCoefValue = new double[24];
			barkCoefValue[hour] = value;
		}

		public double getBarkCoefValue(int hour) {
			if (barkCoefValue == null)
				return 0;
			return barkCoefValue[hour];
		}

	}

	private List<RefDoy> refDoys;

	// This map is updated when refDoys is complete, helps
	// getDirectCoefficient()...
	private Map<Integer, RefDoy> refDoyMap;

	private HetTree refTree;
	private HetScene refScene;
	private HetVegetationPeriod vegetationPeriod;
	private HetAverageRadiation averageRadiation;

	/**
	 * Constructor
	 */
	public HetAbsorptionCoefficientEvaluator(HetTree refTree, HetScene refScene, HetVegetationPeriod vegetationPeriod,
			HetAverageRadiation averageRadiation) throws RuntimeException {

		this.refTree = refTree;
		this.refScene = refScene;
		this.vegetationPeriod = vegetationPeriod;
		this.averageRadiation = averageRadiation;

		// Create all reference doys for all specific doys in the year,
		// including all phases in the vegetation period and all their keyDoys
		refDoys = new ArrayList<>();
		Set<Integer> done = new HashSet<>(); // doys already seen

		RefDoy rd = new RefDoy(1);
		refDoys.add(rd);
		done.add(rd.doy);
		// fa-31.05.2017: Set coef to zero, otherwise returns null
		for (int h = 0; h <= 23; h++) {
			rd.addCrownDirectCoefValue(h, 0d);
			rd.addCrownDiffuseCoefValue(h, 0d);
			rd.addCrownPotentialCoefValue(h, 0d); // fa-22.12.2017
			rd.addBarkCoefValue(h, 0d);
		}

		// This code is TO BE CHECKED fc+fa-19.5.2017
		// This code is TO BE CHECKED fc+fa-19.5.2017
		// This code is TO BE CHECKED fc+fa-19.5.2017
		// This code is TO BE CHECKED fc+fa-19.5.2017
		// This code is TO BE CHECKED fc+fa-19.5.2017
		// This code is TO BE CHECKED fc+fa-19.5.2017
		// This code is TO BE CHECKED fc+fa-19.5.2017

		// fa-31.05.2017: Process first completeDevelopmentPhase to set refDoys
		// for its start and endDoys before processing other phases,
		// otherwise will process twice startDoy
		for (HetPhase phase : vegetationPeriod.getPhases()) {
			// Complete development phase: take care of start and enfDoy
			if (phase.isCompleteDevelopmentPhase()) {
				rd = new RefDoy(phase.startDoy);
				refDoys.add(rd);
				done.add(rd.doy);
				// add coef values
				calculateCoefValues(rd, new HetKeyDoy(phase.startDoy, phase.name), phase);

				rd = new RefDoy(phase.endDoy);
				refDoys.add(rd);
				done.add(rd.doy);
				// add coef values
				calculateCoefValues(rd, new HetKeyDoy(phase.endDoy, phase.name), phase);
			}
		}
		// fa-31.05.2017

		for (HetPhase phase : vegetationPeriod.getPhases()) {

			// fa-31.05.2017: Removed this part (completeDevelopmentPhase
			// processed above)
			// Complete development phase: take care of start and enfDoy
			// if (phase.isCompleteDevelopmentPhase()) {
			// rd = new RefDoy(phase.startDoy);
			// refDoys.add(rd);
			// done.add(rd.doy);
			// // add coef values
			// calculateCoefValues(rd, new HetKeyDoy(phase.startDoy,
			// phase.name), phase);
			//
			// rd = new RefDoy(phase.endDoy);
			// refDoys.add(rd);
			// done.add(rd.doy);
			// // add coef values
			// calculateCoefValues(rd, new HetKeyDoy(phase.endDoy, phase.name),
			// phase);
			//
			// } else {

			// if (!done.contains(phase.startDoy)) {
			if (!done.contains(phase.startDoy) && !done.contains(phase.startDoy - 1)) { // fa-5.7.2017:
																						// redefinition
																						// of
																						// completeDevelopmentPhase
																						// startDate
																						// and
																						// endDate
																						// (see
																						// HetVegetationPeriod)
				// Start doy of each phase
				rd = new RefDoy(phase.startDoy);
				refDoys.add(rd);
				done.add(rd.doy);
				// fa-31.05.2017: Set coef to zero, otherwise returns null
				for (int h = 0; h <= 23; h++) {
					rd.addCrownDirectCoefValue(h, 0d);
					rd.addCrownDiffuseCoefValue(h, 0d);
					rd.addCrownPotentialCoefValue(h, 0d); // fa-22.12.2017
				}
			}

			// if (!done.contains(phase.endDoy)) {
			if (!done.contains(phase.endDoy) && !done.contains(phase.endDoy + 1)) { // fa-5.7.2017:
																					// redefinition
																					// of
																					// completeDevelopmentPhase
																					// startDate
																					// and
																					// endDate
																					// (see
																					// HetVegetationPeriod)
				// End doy of the last phase
				rd = new RefDoy(phase.endDoy);
				refDoys.add(rd);
				done.add(rd.doy);
				// fa-31.05.2017: Set coef to zero, otherwise returns null
				for (int h = 0; h <= 23; h++) {
					rd.addCrownDirectCoefValue(h, 0d);
					rd.addCrownDiffuseCoefValue(h, 0d);
					rd.addCrownPotentialCoefValue(h, 0d); // fa-22.12.2017
				}
			}

			// }

			// Key doys of each phase
			if (phase.getKeyDoys() != null) { // fa-31.05.2017: Only if phase
												// contains keyDoys (e.g., not
												// for completeDevelopmentPhase)
				for (HetKeyDoy kd : phase.getKeyDoys()) {

					rd = new RefDoy(kd.doy);
					refDoys.add(rd);
					done.add(rd.doy);
					// add coef values
					calculateCoefValues(rd, kd, phase);

				}
			}
		}

		rd = new RefDoy(366); // fc+fa-31.7.2017
		// refDoys.add(new RefDoy(366));
		refDoys.add(rd);
		done.add(rd.doy);
		// fa 31.05.2017: Set coef to zero, otherwise returns null
		for (int h = 0; h <= 23; h++) {
			rd.addCrownDirectCoefValue(h, 0d);
			rd.addCrownDiffuseCoefValue(h, 0d);
			rd.addCrownPotentialCoefValue(h, 0d); // fa-22.12.2017
		}

		// This map will help go faster
		refDoyMap = new HashMap<Integer, RefDoy>();
		for (RefDoy d : refDoys) {
			refDoyMap.put(rd.doy, d);
		}

		/*----
		// TRACE fa-31.05.2017
				String fileName = "heterofor_RefDoyMap_TagMode_ladPropGreenProp.txt";
				System.out.println("heterofor_RefDoyMap_TagMode_ladPropGreenProp.txt!!!!!!!!!!!!");
				try {
					BufferedWriter out = new BufferedWriter(new FileWriter(fileName));

					out.write("DOY" + "\t" + "hour" + "\t" + "directCoef" + "\t" + "diffuseCoef" + "\t" + "ladProp" + "\t" + "greenProp");
					out.newLine();

					for (RefDoy d : refDoys) {
						for (int h = 0; h <= 23; h++){
							out.write("" + d.getDoy() + "\t" + h + "\t" + d.directCoefValue[h] + "\t" + d.diffuseCoefValue[h] + "\t" + refScene.getLadProportion(refTree.getSpeciesCode(), d.getDoy()) + "\t" + refScene.getGreenProportion(refTree.getSpeciesCode(), d.getDoy()));
							out.newLine();
						}

					}

					out.close();
				} catch (Exception e) {
					Log.println(Log.ERROR, "HetAbsorptionCoefficientEvaluator", "Could not write in file: " + fileName, e);
			}
		// fa-31.05.2017
		----*/

	}

	private void calculateCoefValues(RefDoy refDoy, HetKeyDoy keyDoy, HetPhase phase) throws RuntimeException {

		// double standIncidentRadiation_H = 0;

		// fa-22.6.2017
		double standIncidentGlobalRadiation_H = 0;
		double standIncidentDirectRadiation_H = 0;
		double standIncidentDiffuseRadiation_H = 0;

		for (int h = 0; h < 24; h++) {

			if (phase.isCompleteDevelopmentPhase()) {

				// Incident radiation for this period during this hour
				standIncidentGlobalRadiation_H = averageRadiation.getIncidentGlobalRadiation(phase.startDoy,
						phase.endDoy, h);

				// fa-22.6.2016
				standIncidentDirectRadiation_H = averageRadiation.getIncidentDirectRadiation(phase.startDoy,
						phase.endDoy, h);
				standIncidentDiffuseRadiation_H = averageRadiation.getIncidentDiffuseRadiation(phase.startDoy,
						phase.endDoy, h);

				// fa-31.05.2017
				// System.out.println("Stand incident radiation LEAVED, h: " + h
				// + ", IncidentRadiation: " + standIncidentRadiation_H);

			} else {

				// Incident radiation for this doy during this hour
				standIncidentGlobalRadiation_H = averageRadiation.getIncidentGlobalRadiation(keyDoy.doy, h);

				// fa-22.6.2017
				standIncidentDirectRadiation_H = averageRadiation.getIncidentDirectRadiation(keyDoy.doy, h);
				standIncidentDiffuseRadiation_H = averageRadiation.getIncidentDiffuseRadiation(keyDoy.doy, h);

				// fa-31.05.2017
				// System.out.println("Stand incident radiation DOY" +
				// keyDoy.doy + ", h: " + h + ", IncidentRadiation: " +
				// standIncidentRadiation_H);
			}

			setRadiationValues(refDoy, keyDoy, h, standIncidentGlobalRadiation_H, standIncidentDirectRadiation_H,
					standIncidentDiffuseRadiation_H);

		}

	}

	private void setRadiationValues(RefDoy refDoy, HetKeyDoy keyDoy, int hour, double standIncidentGlobalRadiation_H,
			double standIncidentDirectRadiation_H, double standIncidentDiffuseRadiation_H) // fa-22.6.2017
			throws RuntimeException {

		int doy = keyDoy.doy;
		String keyDoyName = keyDoy.name;

		// Radiation intercepted by the tree during this hour
		double[] energies = evaluateEnergies_H(keyDoy, hour);

		double crownDirectEnergySum = energies[0];
		double crownDiffuseEnergySum = energies[1];
		double trunkDirectEnergySum = energies[2];
		double trunkDiffuseEnergySum = energies[3];
		double crownPotentialEnergySum = energies[4];

		// // Incident radiation during this hour MOVED
		// double standIncidentRadiation_H =
		// averageRadiation.getIncidentGlobalRadiation(doy, hour);

		// Calculation of yearly leaf PAR interception coefficient: DIRECT
		// *** We mimic the calc in HetWaterBalance for
		// trunkAbsorbedRadiation_direct and barkAbsorbedDirectRadiation but at
		// tree level instead of scene level, TO BE REVIEWED fc+fa-19.5.2017 ***
		// double trunkAbsorbedRadiation_direct = directTrunkEnergySum * (1 -
		// 0.11) / meanTreeArea_m2;
		// double barkAbsorbedDirectRadiation = trunkAbsorbedRadiation_direct
		// / (refTree.getStemBarkArea() / meanTreeArea_m2);

		double treeCrownAbsorbedDirectRadiation = crownDirectEnergySum * (1 - 0.11); // MJ/tree
		double treeLeafAbsorbedDirectRadiation = treeCrownAbsorbedDirectRadiation;
		// - treeBranchAbsorbedDirectRadiation; // MJ/tree

		// MJ/tree/year / MJ/tree/year
		// fa-31.05.2017
		double treeLeafAbsorbedDirectRadiationCoefficient = 0d;

		// fa-23.6.2017
		// if (standIncidentRadiation_H != 0d){
		// treeLeafAbsorbedDirectRadiationCoefficient =
		// treeLeafAbsorbedDirectRadiation / standIncidentRadiation_H;
		// }
		if (standIncidentDirectRadiation_H != 0d) {
			treeLeafAbsorbedDirectRadiationCoefficient = treeLeafAbsorbedDirectRadiation
					/ standIncidentDirectRadiation_H;
		}

		// fa-31.05.2017
		// System.out.println("Phase" + keyDoy.name + ", Doy: " + keyDoy.doy +
		// ", h: " + hour + ", LeafDirect: " + treeLeafAbsorbedDirectRadiation +
		// ", Incident: " + standIncidentRadiation_H + ", LeafDirectCoef: " +
		// treeLeafAbsorbedDirectRadiationCoefficient);

		refDoy.addCrownDirectCoefValue(hour, treeLeafAbsorbedDirectRadiationCoefficient);

		// Calculation of yearly leaf PAR interception coefficient: DIFFUSE

		// *** We mimic the calc in HetWaterBalance for
		// trunkAbsorbedRadiation_diffuse and barkAbsorbedDiffuseRadiation but
		// at
		// tree level instead of scene level, TO BE REVIEWED fc+fa-19.5.2017 ***
		// double trunkAbsorbedRadiation_diffuse = diffuseTrunkEnergySum * (1 -
		// 0.11) / meanTreeArea_m2;
		// double barkAbsorbedDiffuseRadiation = trunkAbsorbedRadiation_diffuse
		// / (refTree.getStemBarkArea() / meanTreeArea_m2);

		double treeCrownAbsorbedDiffuseRadiation = crownDiffuseEnergySum * (1 - 0.11); // MJ/tree
		double treeLeafAbsorbedDiffuseRadiation = treeCrownAbsorbedDiffuseRadiation; // MJ/tree

		// MJ/tree/year / MJ/tree/year
		// fa-31.05.2017
		double treeLeafAbsorbedDiffuseRadiationCoefficient = 0d;

		// fa-23.6.2017
		// if (standIncidentRadiation_H != 0d){
		// treeLeafAbsorbedDiffuseRadiationCoefficient =
		// treeLeafAbsorbedDiffuseRadiation / standIncidentRadiation_H;
		// }
		if (standIncidentDiffuseRadiation_H != 0d) {
			treeLeafAbsorbedDiffuseRadiationCoefficient = treeLeafAbsorbedDiffuseRadiation
					/ standIncidentDiffuseRadiation_H;
		}

		// fa-31.05.2017
		// System.out.println("Phase" + keyDoy.name + ", Doy: " + keyDoy.doy +
		// ", h: " + hour + ", LeafDiffuse: " + treeLeafAbsorbedDiffuseRadiation
		// + ", Incident: " + standIncidentDiffuseRadiation_H +
		// ", LeafDiffuseCoef: " + treeLeafAbsorbedDiffuseRadiationCoefficient);

		refDoy.addCrownDiffuseCoefValue(hour, treeLeafAbsorbedDiffuseRadiationCoefficient);

		// fa-7.7.2017: check
		// System.out.println("TreeLightBefore: CrownDirect = " +
		// refTree.getTreeLight().getCrownDirectEnergy() + ", CrownDiffuse = " +
		// refTree.getTreeLight().getCrownDiffuseEnergy() + ", Trunk = " +
		// refTree.getTreeLight().getTrunkEnergy());

		// fc+mj+fa-27.7.2017 GLOBAL
		
		// fa-22.12.2017: crown potential energy
		double treeCrownAbsorbedPotentialRadiation = crownPotentialEnergySum * (1 - 0.11); // MJ/tree
		double crownAbsorbedPotentialRadiationCoefficient = 0d;
		if (standIncidentGlobalRadiation_H != 0d) {
			crownAbsorbedPotentialRadiationCoefficient = treeCrownAbsorbedPotentialRadiation / standIncidentGlobalRadiation_H;
		}
		
		refDoy.addCrownPotentialCoefValue(hour, crownAbsorbedPotentialRadiationCoefficient);
		

		// fa-31.05.2017, MJ/m2bark for tree
		double barkAbsorbedRadiation_m2bark = (trunkDirectEnergySum + trunkDiffuseEnergySum) * (1 - 0.11)
				/ refTree.getStemBarkArea();

		double barkAbsorbedRadiationCoefficient = 0d;
		if (standIncidentGlobalRadiation_H != 0d) {
			barkAbsorbedRadiationCoefficient = barkAbsorbedRadiation_m2bark / standIncidentGlobalRadiation_H;
		}

		refDoy.addBarkCoefValue(hour, barkAbsorbedRadiationCoefficient);

	}

	private double[] evaluateEnergies_H(HetKeyDoy keyDoy, int hour) throws RuntimeException {

		//double[] energies = new double[4];
		double[] energies = new double[5]; // fa-22.12.2017

		double crownDirectEnergySum = 0;
		double crownDiffuseEnergySum = 0;
		double trunkDirectEnergySum = 0;
		double trunkDiffuseEnergySum = 0;
		double crownPotentialEnergySum = 0;

		String beamTagName = keyDoy.name + "_" + hour; // e.g. LD1_13

		ListMapThreadSafe<String, SLTagTreeResult> tagResultMap = refTree.getLightResult().getTagResultMap();
		List<SLTagTreeResult> results = tagResultMap.get(beamTagName);

		if (results != null) { // e.g. LD1_0 (night)

			for (SLTagTreeResult r : results) {

				// We ignore energyTags CROWN_POTENTIAL and
				// LOWER_CROWN_POTENTIAL

				if (r.interceptionTag.equals(SLTag.CROWN) && r.energyTag.equals(SLTag.DIRECT)) {
					crownDirectEnergySum += r.energy_MJ;

				} else if (r.interceptionTag.equals(SLTag.CROWN) && r.energyTag.equals(SLTag.DIFFUSE)) {
					crownDiffuseEnergySum += r.energy_MJ;

				} else if (r.interceptionTag.equals(SLTag.TRUNK) && r.energyTag.equals(SLTag.DIRECT)) {
					trunkDirectEnergySum += r.energy_MJ;

				} else if (r.interceptionTag.equals(SLTag.TRUNK) && r.energyTag.equals(SLTag.DIFFUSE)) {
					trunkDiffuseEnergySum += r.energy_MJ;
				
				// fa-22.12.2017
				} else if (r.interceptionTag.equals(SLTag.CROWN) && r.energyTag.equals(SLTag.CROWN_POTENTIAL)) {
					crownPotentialEnergySum += r.energy_MJ;

				}

			}

		}

		energies[0] = crownDirectEnergySum;
		energies[1] = crownDiffuseEnergySum;
		energies[2] = trunkDirectEnergySum;
		energies[3] = trunkDiffuseEnergySum;
		energies[4] = crownPotentialEnergySum;

		return energies;
	}

	/**
	 * Interpolating method for bark coefficient. Interpolation is performed on
	 * a time basis.
	 */
	public double getBarkCoefficient(int doy, int hour) throws Exception {

		RefDoy rdInf = null;
		RefDoy rdSup = null;

		// fa-31.05.2017
		int diffDoy = Integer.MAX_VALUE; // Difference between doy and rd.doy
		int diffDoyInf = Integer.MAX_VALUE;
		int diffDoySup = Integer.MAX_VALUE;
		boolean doyIsRefDoy = false;

		for (RefDoy rd : refDoys) {

			// fa-31.05.2017: removed this part -> does not work properly as
			// refDoys are not sorted
			// if (rd.doy <= doy)
			// rdInf = rd;
			//
			// if (rd.doy >= doy) {
			// rdSup = rd;
			// break;
			// }

			// fa-31.05.2017
			diffDoy = rd.doy - doy;
			if (diffDoy == 0) { // doy = rd.doy
				doyIsRefDoy = true;
				rdInf = rd;
				break;
			} else if (diffDoy < 0 && Math.abs(diffDoy) < diffDoyInf) { // if
																		// doy
																		// is
																		// after
																		// rd.doy
				rdInf = rd;
				diffDoyInf = Math.abs(diffDoy);
			} else if (diffDoy > 0 && Math.abs(diffDoy) < diffDoySup) { // if
																		// doy
																		// is
																		// before
																		// rd.doy
				rdSup = rd;
				diffDoySup = Math.abs(diffDoy);
			}
		}

		if (doyIsRefDoy) { // fa-31.05.2017
			
			return rdInf.getBarkCoefValue(hour);

		} else {

			double coefInf = rdInf.getBarkCoefValue(hour);
			double coefSup = rdSup.getBarkCoefValue(hour);

			return coefInf + (coefSup - coefInf) / (rdSup.doy - rdInf.doy) * (doy - rdInf.doy);

		}

	}

	/**
	 * Interpolating method for direct coefficient. Interpolation is performed
	 * on the basis of the foliage state, characterized by (ladProp X
	 * greenProp). In case of equal (ladProp x greenProp) values for both
	 * reference doys (rd), interpolation is carried out on a time basis.
	 */
	public double getCrownDirectCoefficient(int doy, int hour) throws RuntimeException {

		RefDoy rdInf = null;
		RefDoy rdSup = null;

		// fa-31.05.2017
		int diffDoy = Integer.MAX_VALUE; // Difference between doy and rd.doy
		int diffDoyInf = Integer.MAX_VALUE;
		int diffDoySup = Integer.MAX_VALUE;
		boolean doyIsRefDoy = false;

		for (RefDoy rd : refDoys) {

			// fa-31.05.2017: removed this part -> does not work properly as
			// refDoys are not sorted
			// if (rd.doy <= doy)
			// rdInf = rd;
			//
			// if (rd.doy >= doy) {
			// rdSup = rd;
			// break;
			// }

			// fa-31.05.2017
			diffDoy = rd.doy - doy;
			if (diffDoy == 0) { // doy = rd.doy
				doyIsRefDoy = true;
				rdInf = rd;
				break;
			} else if (diffDoy < 0 && Math.abs(diffDoy) < diffDoyInf) { // if
																		// doy
																		// is
																		// after
																		// rd.doy
				rdInf = rd;
				diffDoyInf = Math.abs(diffDoy);
			} else if (diffDoy > 0 && Math.abs(diffDoy) < diffDoySup) { // if
																		// doy
																		// is
																		// before
																		// rd.doy
				rdSup = rd;
				diffDoySup = Math.abs(diffDoy);
			}
		}

		if (doyIsRefDoy) { // fa-31.05.2017
			return rdInf.getCrownDirectCoefValue(hour);
		} else {
			double ladInf = refScene.getLadProportionOfNextYear(refTree.getSpeciesCode(), rdInf.doy);
			double ladSup = refScene.getLadProportionOfNextYear(refTree.getSpeciesCode(), rdSup.doy);
			double lad = refScene.getLadProportionOfNextYear(refTree.getSpeciesCode(), doy);

			// fa-19.06.2017
			double greenInf = refScene.getGreenProportionOfNextYear(refTree.getSpeciesCode(), rdInf.doy);
			double greenSup = refScene.getGreenProportionOfNextYear(refTree.getSpeciesCode(), rdSup.doy);
			double green = refScene.getGreenProportionOfNextYear(refTree.getSpeciesCode(), doy);

			// fa-19.06.2017: foliage states
			double foliageStateInf = ladInf * greenInf;
			double foliageStateSup = ladSup * greenSup;
			double foliageState = lad * green;

			double coefInf = rdInf.getCrownDirectCoefValue(hour);
			double coefSup = rdSup.getCrownDirectCoefValue(hour);

			if (foliageStateInf == foliageStateSup) { // fa-31.05.2017:
														// Interpolate on time
														// basis
				return coefInf + (coefSup - coefInf) / (rdSup.doy - rdInf.doy) * (doy - rdInf.doy);
			} else {
				// return coefInf + (coefSup - coefInf) / (ladSup - ladInf) *
				// (lad - ladInf);
				return coefInf + (coefSup - coefInf) / (foliageStateSup - foliageStateInf)
						* (foliageState - foliageStateInf); // fa-19.06.2017
			}
		}

	}

	/**
	 * Interpolating method for diffuse coefficient. Interpolation is performed
	 * on the basis of the foliage state, characterized by (ladProp X
	 * greenProp). In case of equal (ladProp x greenProp) values for both
	 * reference doys (rd), interpolation is carried out on a time basis.
	 */
	public double getCrownDiffuseCoefficient(int doy, int hour) throws RuntimeException {

		RefDoy rdInf = null;
		RefDoy rdSup = null;

		// fa-31.05.2017
		int diffDoy = Integer.MAX_VALUE; // Difference between doy and rd.doy
		int diffDoyInf = Integer.MAX_VALUE;
		int diffDoySup = Integer.MAX_VALUE;
		boolean doyIsRefDoy = false;

		for (RefDoy rd : refDoys) {

			// fa-31.05.2017: removed this part -> does not work properly as
			// refDoys are not sorted
			// if (rd.doy <= doy)
			// rdInf = rd;
			//
			// if (rd.doy >= doy) {
			// rdSup = rd;
			// break;
			// }

			// fa-31.05.2017
			diffDoy = rd.doy - doy;
			if (diffDoy == 0) { // doy = rd.doy
				doyIsRefDoy = true;
				rdInf = rd;
				break;
			} else if (diffDoy < 0 && Math.abs(diffDoy) < diffDoyInf) { // if
																		// doy
																		// is
																		// after
																		// rd.doy
				rdInf = rd;
				diffDoyInf = Math.abs(diffDoy);
			} else if (diffDoy > 0 && Math.abs(diffDoy) < diffDoySup) { // if
																		// doy
																		// is
																		// before
																		// rd.doy
				rdSup = rd;
				diffDoySup = Math.abs(diffDoy);
			}
		}

		if (doyIsRefDoy) { // fa-31.05.2017
			return rdInf.getCrownDiffuseCoefValue(hour);
		} else {
			double ladInf = refScene.getLadProportionOfNextYear(refTree.getSpeciesCode(), rdInf.doy);
			double ladSup = refScene.getLadProportionOfNextYear(refTree.getSpeciesCode(), rdSup.doy);
			double lad = refScene.getLadProportionOfNextYear(refTree.getSpeciesCode(), doy);

			// fa-19.06.2017
			double greenInf = refScene.getGreenProportionOfNextYear(refTree.getSpeciesCode(), rdInf.doy);
			double greenSup = refScene.getGreenProportionOfNextYear(refTree.getSpeciesCode(), rdSup.doy);
			double green = refScene.getGreenProportionOfNextYear(refTree.getSpeciesCode(), doy);

			// fa-19.06.2017: foliage states
			double foliageStateInf = ladInf * greenInf;
			double foliageStateSup = ladSup * greenSup;
			double foliageState = lad * green;

			double coefInf = rdInf.getCrownDiffuseCoefValue(hour);
			double coefSup = rdSup.getCrownDiffuseCoefValue(hour);

			if (foliageStateInf == foliageStateSup) { // fa-31.05.2017:
														// Interpolate on time
														// basis
				return coefInf + (coefSup - coefInf) / (rdSup.doy - rdInf.doy) * (doy - rdInf.doy);
			} else {
				// return coefInf + (coefSup - coefInf) / (ladSup - ladInf) *
				// (lad - ladInf);
				return coefInf + (coefSup - coefInf) / (foliageStateSup - foliageStateInf)
						* (foliageState - foliageStateInf); // fa-19.06.2017

			}
		}
	}
	
	
	// fa-22.12.2017
	/**
	 * Interpolating method for crown potential energy coefficient. Interpolation is performed
	 * on the basis of the foliage state, characterized by (ladProp X
	 * greenProp). In case of equal (ladProp x greenProp) values for both
	 * reference doys (rd), interpolation is carried out on a time basis.
	 */
	public double getCrownPotentialCoefficient(int doy, int hour) {

		RefDoy rdInf = null;
		RefDoy rdSup = null;

		int diffDoy = Integer.MAX_VALUE; // Difference between doy and rd.doy
		int diffDoyInf = Integer.MAX_VALUE;
		int diffDoySup = Integer.MAX_VALUE;
		boolean doyIsRefDoy = false;

		for (RefDoy rd : refDoys) {

			diffDoy = rd.doy - doy;
			if (diffDoy == 0) { // doy = rd.doy
				doyIsRefDoy = true;
				rdInf = rd;
				break;
			} else if (diffDoy < 0 && Math.abs(diffDoy) < diffDoyInf) { // if
																		// doy
																		// is
																		// after
																		// rd.doy
				rdInf = rd;
				diffDoyInf = Math.abs(diffDoy);
			} else if (diffDoy > 0 && Math.abs(diffDoy) < diffDoySup) { // if
																		// doy
																		// is
																		// before
																		// rd.doy
				rdSup = rd;
				diffDoySup = Math.abs(diffDoy);
			}
		}

		if (doyIsRefDoy) {
			return rdInf.getCrownPotentialCoefValue(hour);
		} else {
			double ladInf = refScene.getLadProportionOfNextYear(refTree.getSpeciesCode(), rdInf.doy);
			double ladSup = refScene.getLadProportionOfNextYear(refTree.getSpeciesCode(), rdSup.doy);
			double lad = refScene.getLadProportionOfNextYear(refTree.getSpeciesCode(), doy);

			double greenInf = refScene.getGreenProportionOfNextYear(refTree.getSpeciesCode(), rdInf.doy);
			double greenSup = refScene.getGreenProportionOfNextYear(refTree.getSpeciesCode(), rdSup.doy);
			double green = refScene.getGreenProportionOfNextYear(refTree.getSpeciesCode(), doy);

			double foliageStateInf = ladInf * greenInf;
			double foliageStateSup = ladSup * greenSup;
			double foliageState = lad * green;

			double coefInf = rdInf.getCrownPotentialCoefValue(hour);
			double coefSup = rdSup.getCrownPotentialCoefValue(hour);

			if (foliageStateInf == foliageStateSup) { // fa-31.05.2017:
														// Interpolate on time
														// basis
				return coefInf + (coefSup - coefInf) / (rdSup.doy - rdInf.doy) * (doy - rdInf.doy);
			} else {
				// return coefInf + (coefSup - coefInf) / (ladSup - ladInf) *
				// (lad - ladInf);
				return coefInf + (coefSup - coefInf) / (foliageStateSup - foliageStateInf)
						* (foliageState - foliageStateInf); // fa-19.06.2017

			}
		}
	}

}
