/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.soil;

import heterofor.model.HetElementState;
import heterofor.model.meteorology.HetMeteoLine;
import heterofor.model.meteorology.HetMeteorology;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 * The Soil object in the heterofor model.
 * 
 * @author M. Jonard - October 2015
 */
public class HetSoil implements Serializable {

	public static final double NOT_SET = -999.0; 

	private Map<Integer, HetHorizon> horizons;

	// Lowest horizon has the max id
	private int maxId;

	private HetElementState nutrientDeposition;	

	// Soil surface conductance of water (m/s)
	private double minSoilSurfaceConductance;
	private double maxSoilSurfaceConductance;

	private double compensatoryEffectConductance; // fc+mj-14.9.2017, m/s
	
	private double preferentialFlowProportion; // [0,1], dimensionless

	/**
	 * The thickness of the organic layer. Is equal to 0 if there is no organic horizon, > 0 otherwise.
	 */
	private double organicLayerThickness = NOT_SET;

	/**
	 * The bulk density of the organic layer. It is the average bulk density over the
	 * organic horizons. 
	 */
	private double organicLayerBulkDensity = NOT_SET;

	/**
	 * Key: year_month_day_hour string, value: heat flux of the organic layer (composed of one or several organic horizon(s))
	 */
	private Map<String, Double> organicLayerHeatFluxMap;

	/**
	 * Key: year_month_day_hour string, value: temperature at the organic layer/mineral layer interface.
	 */
//	private Map<String, Double> soilInterfaceTemperatureMap;
	private LinkedHashMap<String, Double> soilInterfaceTemperatureMap; // fa-25.07.2017

	/**
	 * Key: year_month_day_hour string, value: temperature at the bottom of the soil profile.
	 */
	private Map<String, Double> soilBottomTemperatureMap;
	
	// fa-25.07.2017
	/**
	 * Key: key is year_month_day_hour string, value: thermal diffusivity of soil profile (weighted average of horizon thermal diffusivities).
	 */
	public Map<String, Double> timeAverageThermalDiffusivityMap;

	/**
	 * Constructor
	 */
	public HetSoil() {
		horizons = new LinkedHashMap<>(); // keep insertion order
		nutrientDeposition = new HetElementState(); // Read in soil file
		organicLayerHeatFluxMap = new HashMap<String, Double>();
//		soilInterfaceTemperatureMap = new HashMap<String, Double>();
		soilInterfaceTemperatureMap = new LinkedHashMap<String, Double>(); // fa-25.07.2017
		soilBottomTemperatureMap = new HashMap<String, Double>();
	}

	/**
	 * Creates a copy of the given HetSoil, with copied horizons inside.
	 */
	public HetSoil(HetSoil o) {
		this();

		// Copy nutrient deposition // fc-7.9.2016
		this.nutrientDeposition = o.nutrientDeposition.getCopy();

		this.minSoilSurfaceConductance = o.minSoilSurfaceConductance;
		this.maxSoilSurfaceConductance = o.maxSoilSurfaceConductance;
		
		this.compensatoryEffectConductance = o.compensatoryEffectConductance; // fc+mj-14.9.2017
		
		this.preferentialFlowProportion = o.preferentialFlowProportion; // fa-29.9.2017	
		
		this.organicLayerThickness = o.organicLayerThickness;
		this.organicLayerBulkDensity = o.organicLayerBulkDensity;

		// Copy horizons
		for (HetHorizon h : o.horizons.values()) {
			addHorizon(new HetHorizon(h));
		}
	}

	/**
	 * Calculate the thickness of the organic layer
	 * @return The thickness of the organic layer
	 */
	public double calculateOrganicLayerThickness() {

		double thickness = 0.0;

		Set<Integer> horizonIdSet = horizons.keySet();		

		for (int horizonId : horizonIdSet) {		
			double upperLimit = horizons.get(horizonId).upperLimit;
			if ( upperLimit > thickness) {
				thickness = upperLimit; 
			} 
		}

		return thickness;
	}


	/**
	 * Calculates and returns the bulk density of the organic layer. It is equal to the 
	 * average bulk density over the organic horizons.
	 * @return The bulk density of the organic layer
	 */
	public double calculateOrganicLayerBulkDensity() {

		double averagedBulkDensity = 0.0;
		int numberOfOrganicHorizons = 0;

		for (HetHorizon horizon : this.getHorizons()) {
			if (horizon.isOrganic()) {
				++numberOfOrganicHorizons;
				averagedBulkDensity += horizon.bulkDensity;
			}
		}
		return averagedBulkDensity/numberOfOrganicHorizons;
	}


	/**
	 * Returns the soil's depth.
	 */
	public double calculateDepth() {

		double depth = Double.MAX_VALUE;

		for (int horizonId : horizons.keySet()) {		
			double lowerLimit = horizons.get(horizonId).lowerLimit;
			if ( lowerLimit < depth) {
				depth = lowerLimit; 
			} 
		}

		return depth;		
	}

	// fa-13.07.2014
	/**
	 * Calculates and returns soil temperature at interface between organic and mineral horizons.
	 * @param meteorology: Meteorological lines
	 * @param year: Year considered for computations
	 * @param dayWindowWidth: Number of meteorological lines (hours) to be considered in the moving average time window accounting for intra-day temperature variations
	 * @param organicLayerThickness: Thickness of the organic layers (m)
	 * @return An ordered map with key: year_month_day_hour string and value: the temperature at the interface between organic and mineral soil horizons
	 * @throws Exception 
	 */
	public void calculateSoilInterfaceTemperature(HetMeteorology meteorology, int year, int dayWindowWidth, double organicLayerThickness, LinkedHashMap<String, Double> dateAverageAirTemperatureOverPrecedingPeriodMap) throws Exception {
		
//		// fa-24.07.2017: Trace
//		String fileName = "heterofor_InterfaceTemperature.txt";
//		BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
////		out.write("loop" + "\t" + "year" + "\t" + "month" + "\t" + "day" + "\t" + "hour" + "\t" + "meanTemp" + "\t" + "maxTemp" + "\t" + "minTemp" + "\t" + "preciseTempHour_init" + "\t" + "preciseTempHour" + "\t" + "SoilInterfaceTemp");
//		out.write("loop" + "\t" + "year" + "\t" + "month" + "\t" + "day" + "\t" + "hour" + "\t" + "meanTempDayPrec" + "\t" + "meanTempYear" + "\t" + "maxTempYear" + "\t" + "minTempYear" + "\t" + "preciseTempHour_init" + "\t" + "preciseTempHour" + "\t" + "SoilInterfaceTemp");
//		out.newLine();


		// Map with key: a year_month_day_hour string, value: the organic-mineral soil interface temperature for the key date
		LinkedHashMap<String, Double> soilInterfaceTemperatureMap = this.getSoilInterfaceTemperatureMap();
		
		// YEAR level
		double sumTempYear = 0.0; // average air temperature over the year
		int cptDays = 0;
		double minTempYear = Double.MAX_VALUE; // minimum air temperature over the year
		double maxTempYear = Double.MIN_VALUE; // maximum air temperature over the year
		for (Double temp : dateAverageAirTemperatureOverPrecedingPeriodMap.values()) {
			sumTempYear += temp;
			cptDays++;
			if (temp < minTempYear)
				minTempYear = temp;
			if (temp > maxTempYear)
				maxTempYear = temp;
		}
		double meanTempYear = sumTempYear / cptDays;

		
		// DAY level
		// Set the time window half-width, on both side of the central value
		// If (windowWidth - 1) is even number then time window is symmetric
		int windowInf = (int) Math.round((dayWindowWidth - 1) / 2d);
		int windowSup = (dayWindowWidth - 1) - windowInf;

		// Select meteo lines from previous year to following year and construct final list
		ArrayList<HetMeteoLine> meteoLinesOfYearBefore = meteorology.getMeteoLines(year - 1);
		ArrayList<HetMeteoLine> meteoLinesOfYear = meteorology.getMeteoLines(year);
		ArrayList<HetMeteoLine> meteoLinesOfYearAfter = meteorology.getMeteoLines(year + 1);

		// Add last #windowInf elements of year before to current year
		ArrayList<HetMeteoLine>  lastMeteoLinesOfYearBefore = new ArrayList<>(meteoLinesOfYearBefore.subList(meteoLinesOfYearBefore.size() - windowInf, meteoLinesOfYearBefore.size())); // Select the last #windowInf meteo lines of the preceding year 
		meteoLinesOfYear.addAll(0, lastMeteoLinesOfYearBefore); // Add last meteo lines of the preceding year at the beginning (index = 0) of meteo lines of current year

		// Add first #windowSup elements of year after to current year
		ArrayList<HetMeteoLine>  firstMeteoLinesOfYearAfter = new ArrayList<>(meteoLinesOfYearAfter.subList(0 , windowSup)); // Select the first #windowSup meteo lines of the following year 
		meteoLinesOfYear.addAll(firstMeteoLinesOfYearAfter); // Add first meteo lines of the following year at the end of meteo lines of current year

		// Indexes for selected meteo lines
		ArrayList<Integer> meteoLinesOfYearGeneralIndex = new ArrayList<Integer>();
		for (int l = 0; l < meteoLinesOfYear.size(); l++){
			meteoLinesOfYearGeneralIndex.add(l);
		}

		// Initialization: set window on the first #windowWidth meteo lines and initial computations
		ArrayList<HetMeteoLine>  meteoLinesWindow = new ArrayList<>(meteoLinesOfYear.subList(0 , dayWindowWidth)); // Meteo line window
		ArrayList<Integer>  meteoLinesWindowGeneralIndex = new ArrayList<>(meteoLinesOfYearGeneralIndex.subList(0 , dayWindowWidth)); // Indexes
		
		// Find meteo line with minimum temperature and corresponding index
		HetMeteoLine minTempLineDay = Collections.min(meteoLinesWindow, new Comparator<HetMeteoLine>() {
			public int compare(HetMeteoLine l1, HetMeteoLine l2) {
				return Double.compare(l1.airTemperature, l2.airTemperature);
			}
		});
		double minTempDay = minTempLineDay.airTemperature;
		int minWindowIndex = meteoLinesWindow.indexOf(minTempLineDay); // If several identical minimum values, the lowest index of these values is returned
		
		// Find meteo line with maximum temperature and corresponding index
		HetMeteoLine maxTempLineDay = Collections.max(meteoLinesWindow, new Comparator<HetMeteoLine>() {
			public int compare(HetMeteoLine l1, HetMeteoLine l2) {
				return Double.compare(l1.airTemperature, l2.airTemperature);
			}
		});
		double maxTempDay = maxTempLineDay.airTemperature;
		int maxWindowIndex = meteoLinesWindow.indexOf(maxTempLineDay); // If several identical maximum values, the lowest index of these values is returned

		// Calculate mean
//		double sumTempDay = 0.0;
//		for (HetMeteoLine meteoLine : meteoLinesWindow){
//			sumTempDay += meteoLine.airTemperature;
//		}
//		double meanTempDay = sumTempDay / dayWindowWidth;
		
		double preciseMaxAirTemperatureIndex = calculatePreciseMaxAirTemperatureIndex(meteoLinesWindow, maxWindowIndex, meteoLinesWindowGeneralIndex, maxTempDay);
		double preciseMaxAirTemperatureHour_init = preciseMaxAirTemperatureIndex;

		// Check delay between min and max temperatures
		if (Math.abs(preciseMaxAirTemperatureIndex - meteoLinesWindowGeneralIndex.get(minWindowIndex)) != 12)
			preciseMaxAirTemperatureIndex = preciseMaxAirTemperatureIndex + Math.signum(preciseMaxAirTemperatureIndex - meteoLinesWindowGeneralIndex.get(minWindowIndex)) * (12 - Math.abs(preciseMaxAirTemperatureIndex - meteoLinesWindowGeneralIndex.get(minWindowIndex)))/2d;

		int centralHourIndex = meteoLinesWindowGeneralIndex.get(windowInf); // General hour index on which the time window is centered, TO BE CHECKED!!!!!!!!!!!!!!!!!!!!!!!!!!
		double meanTempDayPrec = dateAverageAirTemperatureOverPrecedingPeriodMap.get(meteoLinesWindow.get(windowInf).year + "_" + meteoLinesWindow.get(windowInf).month + "_" + meteoLinesWindow.get(windowInf).day); // average air temperature of the preceding days
		double soilInterfaceTemperature = meanTempYear + (meanTempDayPrec - meanTempYear) / ((maxTempYear - minTempYear) / 2) * 8.639
				+ (maxTempDay - minTempDay)/2d * Math.exp(-2.0606) 
					* Math.sin(2 * Math.PI * (centralHourIndex - preciseMaxAirTemperatureIndex)/24d + Math.PI/2d - organicLayerThickness / 0.0853 / 24d * 2 * Math.PI);

		soilInterfaceTemperatureMap.put(meteoLinesWindow.get(windowInf).year + "_" + meteoLinesWindow.get(windowInf).month + "_" + meteoLinesWindow.get(windowInf).day + "_" + meteoLinesWindow.get(windowInf).hour, soilInterfaceTemperature);
		
//		// fa-24.07.2017: Trace
////		out.write(0 + "\t" + meteoLinesWindow.get(windowInf).year + "\t" + meteoLinesWindow.get(windowInf).month + "\t" + meteoLinesWindow.get(windowInf).day + "\t" + meteoLinesWindow.get(windowInf).hour + "\t" + meanTempDay + "\t" + maxTempDay + "\t" + minTempDay + "\t" + preciseMaxAirTemperatureHour_init + "\t" + preciseMaxAirTemperatureIndex + "\t" + soilInterfaceTemperature);
//		out.write(0 + "\t" + meteoLinesWindow.get(windowInf).year + "\t" + meteoLinesWindow.get(windowInf).month + "\t" + meteoLinesWindow.get(windowInf).day + "\t" + meteoLinesWindow.get(windowInf).hour+ "\t" + meanTempDayPrec + "\t" + meanTempYear + "\t" + maxTempYear + "\t" + minTempYear + "\t" + preciseMaxAirTemperatureHour_init + "\t" + preciseMaxAirTemperatureIndex + "\t" + soilInterfaceTemperature);
//		out.newLine();

		
		// End of initialization
		
		// Moving window loop
		double tempRemovedLine;
		double tempLastLine;
		for (int i = windowInf + 1; i < meteoLinesOfYear.size() - (windowSup); i++){ // i is the general index of meteoLinesOfYear on which the window is centered
						
			// Move window
			tempRemovedLine = meteoLinesWindow.get(0).airTemperature; // Save temperature of the first line, which will be removed when moving window
			meteoLinesWindow.remove(0); // Remove first meteo line
			meteoLinesWindow.add(meteoLinesOfYear.get(i + windowSup)); // Add meteo line at last position
			tempLastLine = meteoLinesWindow.get(meteoLinesWindow.size() - 1).airTemperature; // Air temperature of the last meteo line
			meteoLinesWindowGeneralIndex.remove(0);
			meteoLinesWindowGeneralIndex.add(meteoLinesOfYearGeneralIndex.get(i + windowSup));

			// Find meteo line with minimum temperature and corresponding indexes
			if (tempLastLine < minTempDay){ // Last added line has minimum air temperature over the window
				minTempDay = tempLastLine;
				minWindowIndex = meteoLinesWindow.size() - 1;
			}
			else if (minWindowIndex != 0){ // Minimum temperature was not on he first line of the window
				minWindowIndex = minWindowIndex - 1; // Corresponding meteo line moves up for one position, minimum temperature is unchanged
			}
			else{ // New search of minimum
				minTempLineDay = Collections.min(meteoLinesWindow, new Comparator<HetMeteoLine>() {
					public int compare(HetMeteoLine l1, HetMeteoLine l2) {
						return Double.compare(l1.airTemperature, l2.airTemperature);
					}
				});
				minTempDay = minTempLineDay.airTemperature;
				minWindowIndex = meteoLinesWindow.indexOf(minTempLineDay); // If several identical minimum values, the lowest index of these values is returned
			}

			// Find meteo line with maximum temperature and corresponding indexes
			if (tempLastLine > maxTempDay){ // Last added line has maximum air temperature over the window
				maxTempDay = tempLastLine;
				maxWindowIndex = meteoLinesWindow.size() - 1;
			}
			else if (maxWindowIndex != 0){ // Maximum temperature was not on he first line of the window
				maxWindowIndex = maxWindowIndex - 1; // Corresponding meteo line moves up for one position, maximum temperature is unchanged
			}
			else{ // New search of maximum
				maxTempLineDay = Collections.max(meteoLinesWindow, new Comparator<HetMeteoLine>() {
					public int compare(HetMeteoLine l1, HetMeteoLine l2) {
						return Double.compare(l1.airTemperature, l2.airTemperature);
					}
				});
				maxTempDay = maxTempLineDay.airTemperature;
				maxWindowIndex = meteoLinesWindow.indexOf(maxTempLineDay); // If several identical maximum values, the lowest index of these values is returned
			}

			// Update mean temperature
//			sumTempDay = sumTempDay - tempRemovedLine + tempLastLine;
//			meanTempDay = sumTempDay / dayWindowWidth;

			preciseMaxAirTemperatureIndex = calculatePreciseMaxAirTemperatureIndex(meteoLinesWindow, maxWindowIndex, meteoLinesWindowGeneralIndex, maxTempDay);
			preciseMaxAirTemperatureHour_init = preciseMaxAirTemperatureIndex;
			
			// Check delay between min and max temperatures
			if (Math.abs(preciseMaxAirTemperatureIndex - meteoLinesWindowGeneralIndex.get(minWindowIndex)) != 12)
				preciseMaxAirTemperatureIndex = preciseMaxAirTemperatureIndex + Math.signum(preciseMaxAirTemperatureIndex - meteoLinesWindowGeneralIndex.get(minWindowIndex)) * (12 - Math.abs(preciseMaxAirTemperatureIndex - meteoLinesWindowGeneralIndex.get(minWindowIndex)))/2d;

			centralHourIndex = meteoLinesOfYearGeneralIndex.get(i);
			meanTempDayPrec = dateAverageAirTemperatureOverPrecedingPeriodMap.get(meteoLinesOfYear.get(i).year + "_" + meteoLinesOfYear.get(i).month + "_" + meteoLinesOfYear.get(i).day); // average air temperature of the preceding days
			soilInterfaceTemperature = meanTempYear + (meanTempDayPrec - meanTempYear) / ((maxTempYear - minTempYear) / 2d) * 8.639
					+ (maxTempDay - minTempDay)/2d * Math.exp(-2.0606) 
						* Math.sin(2 * Math.PI * (centralHourIndex - preciseMaxAirTemperatureIndex)/24d + Math.PI/2d - organicLayerThickness / 0.0853 / 24d * 2 * Math.PI);

			soilInterfaceTemperatureMap.put(meteoLinesOfYear.get(i).year + "_" + meteoLinesOfYear.get(i).month + "_" + meteoLinesOfYear.get(i).day + "_" + meteoLinesOfYear.get(i).hour, soilInterfaceTemperature);
			
//			// fa-24.07.2017: Trace
////			out.write(i + "\t" + meteoLinesOfYear.get(i).year + "\t" + meteoLinesOfYear.get(i).month + "\t" + meteoLinesOfYear.get(i).day + "\t" + meteoLinesOfYear.get(i).hour + "\t" + meanTempDay + "\t" + maxTempDay + "\t" + minTempDay + "\t" + preciseMaxAirTemperatureHour_init + "\t" + preciseMaxAirTemperatureIndex + "\t" + soilInterfaceTemperature);
//			out.write(i + "\t" + meteoLinesOfYear.get(i).year + "\t" + meteoLinesOfYear.get(i).month + "\t" + meteoLinesOfYear.get(i).day + "\t" + meteoLinesOfYear.get(i).hour + "\t" + meanTempDayPrec + "\t" + meanTempYear + "\t" + maxTempYear + "\t" + minTempYear + "\t" + preciseMaxAirTemperatureHour_init + "\t" + preciseMaxAirTemperatureIndex + "\t" + soilInterfaceTemperature);
//			out.newLine();			
		}
		// End of moving window loop
		
//		// fa-24.07.2017: Trace
//		out.close();

	}

	// fa-13.07.2017
	/**
	 * Returns hour corresponding to maximum air temperature, determined from air temperature measurements around the temperature peak detected within a time window
	 */
	static public double calculatePreciseMaxAirTemperatureIndex(ArrayList<HetMeteoLine>  meteoLinesWindow, int maxWindowIndex, ArrayList<Integer> meteoLinesWindowGeneralIndex, double maxTemp) {
		
		double preciseMaxAirTemperatureIndex = 0;
		if ((maxWindowIndex != 0 && maxWindowIndex != meteoLinesWindow.size() - 1)){
			double tempBeforePeak = meteoLinesWindow.get(maxWindowIndex - 1).airTemperature;
			double tempAfterPeak = meteoLinesWindow.get(maxWindowIndex + 1).airTemperature;
			int generalIndexAtPeak = meteoLinesWindowGeneralIndex.get(maxWindowIndex);
			double diffToPeakBefore = maxTemp - tempBeforePeak;
			double diffToPeakAfter = maxTemp - tempAfterPeak;
			double peakCorrection = 0.0;
			if (diffToPeakBefore >= diffToPeakAfter)
				peakCorrection = - (1.0 - diffToPeakAfter/diffToPeakBefore) * 0.5;
			else
				peakCorrection = (1.0 - diffToPeakBefore/diffToPeakAfter) * 0.5;
			preciseMaxAirTemperatureIndex = generalIndexAtPeak + peakCorrection;
		}
		else{
			preciseMaxAirTemperatureIndex = meteoLinesWindowGeneralIndex.get(maxWindowIndex);
		}
		return preciseMaxAirTemperatureIndex;
	}

	public Map<Integer, Double> getLastWaterContent() {
		Map<Integer, Double> lwc = new HashMap<>();

		for (int hId : horizons.keySet()) {
			HetHorizon h = horizons.get(hId);
			lwc.put(hId, h.lastWaterContent);
		}
		return lwc;
	}


	public void addHorizon(HetHorizon h) {
		horizons.put(h.id, h);
		maxId = Math.max(h.id, maxId);
	}

	public boolean isLowestHorizon (int hId) {
		return hId == maxId;
	}

	public List<HetHorizon> getHorizons() {
		return new ArrayList<HetHorizon>(horizons.values());
	}

	public Map<Integer, HetHorizon> getHorizonMap () {
		return new HashMap<> (horizons);
	}

	public HetHorizon getHorizon(int id) {
		return horizons.get(id);
	}

	public HetElementState getNutrientDeposition() {
		return nutrientDeposition;
	}

	public double getMinSoilSurfaceConductance() {
		return minSoilSurfaceConductance;
	}

	public void setMinSoilSurfaceConductance(double minSoilSurfaceConductance) {
		this.minSoilSurfaceConductance = minSoilSurfaceConductance;
	}

	public double getMaxSoilSurfaceConductance() {
		return maxSoilSurfaceConductance;
	}

	public void setMaxSoilSurfaceConductance(double maxSoilSurfaceConductance) {
		this.maxSoilSurfaceConductance = maxSoilSurfaceConductance;
	}

	public double getCompensatoryEffectConductance() {
		return compensatoryEffectConductance;
	}

	public void setCompensatoryEffectConductance(double compensatoryEffectConductance) {
		this.compensatoryEffectConductance = compensatoryEffectConductance;
	}

	public double getPreferentialFlowProportion() {
		return preferentialFlowProportion;
	}

	public void setPreferentialFlowProportion(double preferentialFlowProportion) {
		this.preferentialFlowProportion = preferentialFlowProportion;
	}

	public void setOrganicLayerThickness(double organicLayerThickness) {
		this.organicLayerThickness = organicLayerThickness;
	}

	public double getOrganicLayerThickness() {
		return organicLayerThickness;
	}

	public void setOrganicLayerBulkDensity(double organicLayerBulkDensity) {
		this.organicLayerBulkDensity = organicLayerBulkDensity;
	}

	public double getOrganicLayerBulkDensity() {
		return organicLayerBulkDensity;
	}

	public Map<String, Double> getOrganicLayerHeatFluxMap() {
		return organicLayerHeatFluxMap;
	}

//	public Map<String, Double> getSoilInterfaceTemperatureMap() {
	public LinkedHashMap<String, Double> getSoilInterfaceTemperatureMap() { // fa-25.07.2017
		return soilInterfaceTemperatureMap;
	}

	public Map<String, Double> getSoilBottomTemperatureMap() {
		return soilBottomTemperatureMap;
	}
}
