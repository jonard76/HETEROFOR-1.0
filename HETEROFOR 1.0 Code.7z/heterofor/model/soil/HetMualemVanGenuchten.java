/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.soil;

import heterofor.model.HetReporter;

/**
 * The Mualem-van Genuchten function computes hydraulic conductivity based on
 * soil water content.
 * 
 * @author M. Jonard, Louis de Wergifoose, F. de Coligny - October 2016
 */
public class HetMualemVanGenuchten {

	private HetHorizon horizon;
	private HetHydraulicPedotransferParameters params;
	private double prevWaterContent;

	/**
	 * Constructor
	 */
	public HetMualemVanGenuchten(HetHorizon horizon, HetHydraulicPedotransferParameters params, double prevWaterContent) {
		this.horizon = horizon;
		this.params = params;
		this.prevWaterContent = prevWaterContent;
	}

	public double execute() {

		double relativeSaturation = (prevWaterContent - params.residualWaterContent)
				/ (params.saturatedWaterContent - params.residualWaterContent);
		
		//mj+fa-02.10.2017
		relativeSaturation = Math.min(1d, relativeSaturation);
//		relativeSaturation = Math.max(0d, relativeSaturation);
		relativeSaturation = Math.max(0.00000000001, relativeSaturation); // 0.00000000001 to be just above 0, otherwise below 'K' will be Infinity with lambda negative 

		double m = 1d - 1d / params.n;
			
		double a = 1d - Math.pow(relativeSaturation, params.n / (params.n - 1));
		double b = 1d - Math.pow (a, m);
		double K = params.K0 * Math.pow(relativeSaturation, params.lambda) * b * b;
		
		if (Double.isNaN(K)) 
			HetReporter.printInStandardOutput("HetMualemVanGenuchten, relativeSaturation= " + relativeSaturation + ", K= " + K + ", a= " + a + ", b=" + b + ", lambda= " + params.lambda);
				
		return K;
		
	}

}
