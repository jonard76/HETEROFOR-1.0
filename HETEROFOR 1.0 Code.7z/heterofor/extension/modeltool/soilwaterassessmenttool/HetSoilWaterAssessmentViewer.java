package heterofor.extension.modeltool.soilwaterassessmenttool;

import java.awt.Color;
import java.awt.Window;
import java.util.ArrayList;

import javax.swing.JPanel;

import jeeb.lib.util.Log;
import jeeb.lib.util.MessageDialog;
import jeeb.lib.util.StatusDispatcher;
import jeeb.lib.util.Translator;
import jeeb.lib.util.csvfileviewer.CsvFileViewer;
import jeeb.lib.util.task.Task;
import jeeb.lib.util.task.TaskManager;

import org.jfree.data.xy.XYSeriesCollection;

import capsis.gui.MainFrame;

public class HetSoilWaterAssessmentViewer extends JPanel {

	static {
		Translator.addBundle("heterofor.extension.modeltool.soilwaterassessmenttool.HetSoilWaterAssessmentTool");
	}

	// The set containing series of observed and simulated values
	protected XYSeriesCollection dataSet;

	/**
	 * Opens the chart's data in a floating table.
	 * 
	 * @param xName The name of the x-values (x-values are common to all the series)
	 * @param xUnit The unit of the x-values (x-values are common to all the series)
	 * @param yUnit The unit of the y-values
	 */
	protected void openFloatingTableAction(String tableTitle, String xName, String xUnit, String yUnit) {

		// Creates a task
		Task<Object, Void> task = new Task<Object, Void>(Translator.swap("HetSoilWaterAssessmentViewer.openingResultsInFloatingTable")) {

			@Override
			protected void doFirstInEDT() {

				// Deletes existing message in the left part of the status panel
				StatusDispatcher.print("");
			}

			@Override
			protected Object doInWorker() throws InterruptedException {

				// Writes in the right part of the status panel
				StatusDispatcher.print(Translator.swap("HetSoilWaterAssessmentViewer.floatingTableCreationInProgress"));

				HetSoilWaterAssessmentTableBuilder tableBuilder = new HetSoilWaterAssessmentTableBuilder(dataSet, xName, xUnit, yUnit);

				String tableContentStr = tableBuilder.getTableInAString();
				String separator = tableBuilder.getSeparator();

				ArrayList<String> result = new ArrayList<String>();
				result.add(tableContentStr);				
				result.add(separator);

				return result;
			}

			@Override
			protected void doInEDTafterWorker() {

				try {
					ArrayList<String> workerResult = (ArrayList<String>) get();

					String tableContentStr = workerResult.get(0);
					String separator = workerResult.get(1);

					Window window = MainFrame.getInstance();
					new CsvFileViewer(window, tableTitle, tableContentStr, separator, Color.BLUE);

					// Writes in the left part of the status panel
					// TODO: to be improved. Indeed this message sometimes appears before the viewer is displayed.
					StatusDispatcher.print(Translator.swap("HetSoilWaterAssessmentViewer.floatingTableCreationTerminated"));

				} catch (Exception e) {
					
					Log.println(Log.ERROR, "HetSoilWaterAssessmentViewer.openFloatingTableAction()", "Can not open CsvFileViewer", e);
					MessageDialog.print(this, e.getMessage());
				}

			}
		};
		
		// Allows to see a moving bar in the progress bar instead of a percentage that would 
		// stay to the 0 value until task terminated
		task.setIndeterminate();

		// Executes the created task
		TaskManager.getInstance().add(task);
	}

}
