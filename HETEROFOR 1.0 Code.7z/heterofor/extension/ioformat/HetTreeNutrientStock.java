/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.extension.ioformat;

import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetTree;
import heterofor.model.treechemistry.HetTreeCompartment;
import heterofor.model.treechemistry.HetTreeElement;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TreeSet;

import jeeb.lib.util.Import;
import jeeb.lib.util.Log;
import jeeb.lib.util.Record;
import jeeb.lib.util.Translator;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.util.StandRecordSet;

/**
 * HetTreeNutrientStock exports the nutrients in the tree compartments to a
 * file.
 * 
 * @author F. de Coligny - March 2016
 */
public class HetTreeNutrientStock extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// Extension properties
	// nb-13.08.2018
	//static public String NAME = Translator.swap("HetTreeNutrientStock");
	//static public String AUTHOR = "F. de Coligny, M. Jonard";
	//static public String VERSION = "1.0";
	//static public String DESCRIPTION = Translator.swap("HetTreeNutrientStock.description");

	// A tree line in the file
	@Import
	static public class TreeLine extends Record {

		public TreeLine() {
			super();
		}

		public TreeLine(String line) throws Exception {
			super(line);
		}

		public String speciesName;
		public int date; // unique in the scene
		public String elementName;
		public String compartmentName;
		public double value;

	}

	/**
	 * Constructor
	 */
	public HetTreeNutrientStock() {
		super();
		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		try {
			if (!(referent instanceof HetModel)) {
				return false;
			}

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetTreeNutrientStock.matchWith ()", "Error in matchWith () (returned false)", e);
			return false;
		}

		return true;
	}

	@Override
	public String getName() {
		return Translator.swap("HetTreeNutrientStock.name");
	}

	@Override
	public String getAuthor() {
		return "F. de Coligny, M. Jonard";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetTreeNutrientStock.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Export: turns the given Scene into a collection of records In script
	 * mode, save (fileName) must be called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {
		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		// 1. Custom headers
		add(new CommentRecord("Heterofor scene export (HetTreeNutrientStock) at " + new Date()));
		add(new EmptyRecord());

		// Tree line header
		add(new CommentRecord("Trees"));
		add(new CommentRecord("speciesName\tdate\telementName\tcompartmentName\tnutrientStock(kg/ha)"));

		// For each step in the scenario from the root, write all trees
		Step step = scene.getStep();
		Project project = step.getProject();
		
		for (Step st : project.getStepsFromRoot(step)) {

//			add(new EmptyRecord());
			writeLines((HetScene) st.getScene());

		}

	}

	private void writeLines(HetScene scene) {

		// Key is speciesName.elementName.compartmentName
		Map<String, Double> map = new HashMap<>();

		double area_ha = scene.getArea() / 10000d;

		// // Sort the trees on their ids
		// Set sortedTrees = new TreeSet (new GTreeIdComparator ());
		// sortedTrees.addAll (scene.getTrees ());

		for (Iterator i = scene.getTrees().iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();

			String speciesName = t.getSpecies().getName();

			for (HetTreeCompartment comp : t.getTreeCompartments()) {
				String compartmentName = comp.name;

				for (String elementName : HetTreeElement.elementNames) {

					String key = speciesName + "." + elementName + "." + compartmentName;
					double value = comp.getNutrientContent(elementName) / area_ha;
					
					Double prevValue = map.get(key);
					// First time for this key, map.get(key) returns null
					if (prevValue == null) 
						prevValue = 0d;
					
					map.put(key, prevValue + value);

				}

			}

		}

		int date = scene.getDate ();
		
		// Loop on the sorted keys: "speciesName.elementName.compartmentName"
		for (String key : new TreeSet<>(map.keySet ())) {
			
			TreeLine r = new TreeLine();

			StringTokenizer st = new StringTokenizer (key, ".");
			
			String speciesName = st.nextToken ();
			String elementName = st.nextToken ();
			String compartmentName = st.nextToken ();
			
			double value = map.get(key);
			
			r.speciesName = speciesName;
			r.date = date;
			r.elementName = elementName;
			r.compartmentName = compartmentName;
			r.value = value;

			add(r);
		}

	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel m) throws Exception {
		return null;
	}

}