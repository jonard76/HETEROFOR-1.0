/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.extension.dataextractor;

import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetTree;
import jeeb.lib.util.Translator;
import capsis.extension.dataextractor.superclass.DETimeYsTrees;
import capsis.kernel.GModel;
import capsis.kernel.GScene;

/**
 * A graph 'biomass for 5 compartments' over time for a given list of trees.
 * 
 * @author F. de Coligny, M. Jonard - November 2013
 */

public class DETimeBiomass extends DETimeYsTrees {

	static {
		Translator.addBundle ("heterofor.extension.dataextractor.DELabels");
	}

	// nb-13.08.2018
	//public static final String NAME = "DETimeBiomass";
	//public static final String DESCRIPTION = "DETimeBiomass.description";
	//public static final String AUTHOR = "F. de Coligny, M. Jonard";
	//public static final String VERSION = "1.0";


	/**
	 * Extension dynamic compatibility mechanism. This matchwith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith (Object referent) {
		// compatible with HetModel only
		return referent instanceof HetModel;
	}

	@Override
	public String getName() {
		return Translator.swap("DETimeBiomass.name");
	}

	@Override
	public String getAuthor() {
		return "F. de Coligny, M. Jonard";
	}

	@Override
	public String getDescription() {
		return Translator.swap("DETimeBiomass.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	@Override
	public String[] getYAxisVariableNames () {
		// the names of the variables
		return new String[] {Translator.swap ("leafBiomass"), Translator.swap ("branchBiomass"),
				Translator.swap ("stemBiomass"), Translator.swap ("rootBiomass"), Translator.swap ("fineRootBiomass")}; 
	}

	/**
	 * Returns the value for the 'i'th variable of the tree 'treeId'.
	 */
	@Override
	protected Number getValue (GModel m, GScene scene, int treeId, int date, int i) {
		HetScene sc = (HetScene) scene;

		HetTree t = (HetTree) sc.getTree (treeId);

		if (i <= 0) {
			return t.getLeafBiomass_kgC ();
		} else if (i == 1) {
			return t.getBranchBiomass_kgC ();
		} else if (i == 2) {
			return t.getStemBiomass_kgC ();
		} else if (i == 3) {
			return t.getRootBiomass_kgC ();
		} else if (i == 4) {
			return t.getFineRootBiomass_kgC ();
		} else {
			return 0;
		}

	}

}