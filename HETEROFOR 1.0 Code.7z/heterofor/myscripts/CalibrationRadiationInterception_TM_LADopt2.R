# A script to perform optimization of HETEROFOR radiative balance parameters (crown form, ladOption, lad parametrization, turbid medium or porous envelop)

#library(rstudioapi)    
#rstudioapi::getActiveDocumentContext()$path

#install.packages("nlme ")
#library(nlme)

## Functions launching Capsis simulations
# Function for observation and prediction result export
Heterofor.RadiativeBalance_output <- function (CapsisDir, exportFileName, turbidMediumActivated, crownForm, ladOption, extCoef_oak_arg, extCoef_beech_arg, extCoef_carpinus_arg, SLAintercept_oak_arg, SLAintercept_beech_arg, SLAintercept_carpinus_arg, SLAdown_oak_arg, SLAdown_beech_arg, SLAdown_carpinus_arg) {
  
      # Negative arguments are not accepted for Capsis cmd line
#      argsList <- as.list(sys.call()[-1])
#      argsList<-lapply(argsList, function(x) {if (is.character(x)) eval(parse(text=x)) else x})
#      argsList<-lapply(argsList, function(x) {x})
#      if(SLAintercept_oak_arg < 0){
#        SLAintercept_oak_arg <- paste("_",abs(SLAintercept_oak_arg), sep = "")
#        print("SLAintercept_oak_arg:")
#        print(SLAintercept_oak_arg)
#      }
  
      if (.Platform$OS.type == "windows") {
          cmd = paste("capsis -p script heterofor.myscripts.CalibrationRadiationInterception_TM_LADopt2", CapsisDir, exportFileName,
                turbidMediumActivated, crownForm, ladOption,
                extCoef_oak_arg, extCoef_beech_arg, extCoef_carpinus_arg,
                SLAintercept_oak_arg, SLAintercept_beech_arg, SLAintercept_carpinus_arg,
                SLAdown_oak_arg, SLAdown_beech_arg, SLAdown_carpinus_arg,
                sep = " ");
      } else {
          cmd = paste("sh capsis.sh -p script heterofor.myscripts.CalibrationRadiationInterception_TM_LADopt2", CapsisDir, exportFileName,
                turbidMediumActivated, crownForm, ladOption,
                extCoef_oak_arg, extCoef_beech_arg, extCoef_carpinus_arg,
                SLAintercept_oak_arg, SLAintercept_beech_arg, SLAintercept_carpinus_arg,
                SLAdown_oak_arg, SLAdown_beech_arg, SLAdown_carpinus_arg,
                sep = " ");
      }
  
      print(cmd)
  
      if (.Platform$OS.type == "windows") {
        shell(cmd);
      } else{
        system(cmd);
      }
  
      ObsPred.Heterofor <- read.table(exportFileName, header = TRUE)
  
      # Remove observations with radiation = 0 (-> outliers)
      ObsPred.Heterofor <- subset(ObsPred.Heterofor, ObsPred.Heterofor$totalObs != 0 | ObsPred.Heterofor$directObs != 0 |  ObsPred.Heterofor$diffuseObs != 0)
  
      ObsPred.Total <- cbind(ObsPred.Heterofor$plotId, ObsPred.Heterofor$year, ObsPred.Heterofor$sensorId, ObsPred.Heterofor$totalObs, ObsPred.Heterofor$totalPred)
      ObsPred.Direct <- cbind(ObsPred.Heterofor$plotId, ObsPred.Heterofor$year, ObsPred.Heterofor$sensorId, ObsPred.Heterofor$directObs, ObsPred.Heterofor$directPred)
      ObsPred.Diffuse <- cbind(ObsPred.Heterofor$plotId, ObsPred.Heterofor$year, ObsPred.Heterofor$sensorId, ObsPred.Heterofor$diffuseObs, ObsPred.Heterofor$diffusePred)
  
      ObsPred.All <- rbind(ObsPred.Total, ObsPred.Direct, ObsPred.Diffuse)
  
      return(ObsPred.Heterofor)
}

# Function for optimization
Heterofor.RadiativeBalance_func <- function (CapsisDir, exportFileName, turbidMediumActivated, crownForm, ladOption, extCoef_oak_arg, extCoef_beech_arg, extCoef_carpinus_arg, SLAintercept_oak_arg, SLAintercept_beech_arg, SLAintercept_carpinus_arg, SLAdown_oak_arg, SLAdown_beech_arg, SLAdown_carpinus_arg) {
  
  # Negative arguments are not accepted for Capsis cmd line
  #      argsList <- as.list(sys.call()[-1])
  #      argsList<-lapply(argsList, function(x) {if (is.character(x)) eval(parse(text=x)) else x})
  #      argsList<-lapply(argsList, function(x) {x})
  # if(SLAintercept_oak_arg < 0){
  #   SLAintercept_oak_arg <- paste("_",abs(SLAintercept_oak_arg), sep = "")
  #   print("SLAintercept_oak_arg:")
  #   print(SLAintercept_oak_arg)
  # }
  
      if (.Platform$OS.type == "windows") {
          cmd = paste("capsis -p script heterofor.myscripts.CalibrationRadiationInterception_TM_LADopt2", CapsisDir, exportFileName,
                turbidMediumActivated, crownForm, ladOption,
                extCoef_oak_arg, extCoef_beech_arg, extCoef_carpinus_arg,
                SLAintercept_oak_arg, SLAintercept_beech_arg, SLAintercept_carpinus_arg,
                SLAdown_oak_arg, SLAdown_beech_arg, SLAdown_carpinus_arg,
                sep = " ");
      } else {
          cmd = paste("sh capsis.sh -p script heterofor.myscripts.CalibrationRadiationInterception_TM_LADopt2", CapsisDir, exportFileName,
                turbidMediumActivated, crownForm, ladOption,
                extCoef_oak_arg, extCoef_beech_arg, extCoef_carpinus_arg,
                SLAintercept_oak_arg, SLAintercept_beech_arg, SLAintercept_carpinus_arg,
                SLAdown_oak_arg, SLAdown_beech_arg, SLAdown_carpinus_arg,
                sep = " ");
      }
      
      print(cmd)
  
      if (.Platform$OS.type == "windows") {
        shell(cmd);
      } else{
        system(cmd);
      }
  
      ObsPred.Heterofor <- read.table(exportFileName, header = TRUE)
      
      # Remove observations with radiation = 0 (-> outliers)
      ObsPred.Heterofor <- subset(ObsPred.Heterofor, ObsPred.Heterofor$totalObs != 0 | ObsPred.Heterofor$directObs != 0 |  ObsPred.Heterofor$diffuseObs != 0)
  
      ObsPred.Total <- cbind(ObsPred.Heterofor$plotId, ObsPred.Heterofor$year, ObsPred.Heterofor$sensorId, ObsPred.Heterofor$totalObs, ObsPred.Heterofor$totalPred)
      ObsPred.Direct <- cbind(ObsPred.Heterofor$plotId, ObsPred.Heterofor$year, ObsPred.Heterofor$sensorId, ObsPred.Heterofor$directObs, ObsPred.Heterofor$directPred)
      ObsPred.Diffuse <- cbind(ObsPred.Heterofor$plotId, ObsPred.Heterofor$year, ObsPred.Heterofor$sensorId, ObsPred.Heterofor$diffuseObs, ObsPred.Heterofor$diffusePred)
      
      ObsPred.All <- rbind(ObsPred.Total, ObsPred.Direct, ObsPred.Diffuse)
  
      return(ObsPred.All)
}

SSQ <- function(p) {
  
      # Check for bounds
      for (i in 1:length(p)){
            if (p[i] <= LB[i] || p[i] >= UB[i]){
                  return(.Machine$double.xmax)
            }
      }
  
  
      extCoef_oak = p[1]
      extCoef_beech = p[2]
      extCoef_carpinus = p[3]
      SLAintercept_oak = p[4]
      SLAintercept_beech = p[5]
      SLAintercept_carpinus = p[6]
      SLAdown_oak = p[7]
      SLAdown_beech = p[8]
      SLAdown_carpinus = p[9]
  
      ObsPred <- Heterofor.RadiativeBalance_func(CapsisDir, exportFileName, turbidMediumActivated, crownForm, ladOption, extCoef_oak, extCoef_beech, extCoef_carpinus, SLAintercept_oak, SLAintercept_beech, SLAintercept_carpinus, SLAdown_oak, SLAdown_beech, SLAdown_carpinus)
      Obs <- ObsPred[,4]
      Pred <- ObsPred[,5]
  
      residuals <- Pred - Obs
      weight <- Obs / 100
  
      return(t(residuals)%*%residuals)
#      return((weight*t(residuals))%*%residuals)
}

# likelihood <- function(p) {
#       
# #      # Check for bounds
# #      for (i in 1:length(p)){
# #            if (p[i] <= LB[i] || p[i] >= UB[i]){
# #                  return(.Machine$double.xmax)
# #            }
# #      }
#   
#   
#       extCoef_oak = p[1]
#       extCoef_beech = p[2]
#       extCoef_carpinus = p[3]
#       LAD_oak = p[4]
#       LAD_beech = p[5]
#       LAD_carpinus = p[6]
# 
#       ObsPred <- Heterofor.RadiativeBalance_func(CapsisDir, exportFileName, turbidMediumActivated, crownForm, ladOption, extCoef_oak, extCoef_beech, extCoef_carpinus, LAD_oak, LAD_beech, LAD_carpinus)
#       Obs <- ObsPred[,4]
#       Pred <- ObsPred[,5]
#   
#       residuals <- Pred - Obs
#       l <- length(residuals)
#       density <- c()
#       sig2 <- (t(residuals)%*%residuals)/(l-1)
#       m <- 0
#       L <- 1
#       for(i in 1:l) {
#             density[i] <- 1/sqrt(sig2 * 2 * pi) * exp(-0.5 * ((residuals[i] - m)/sqrt(sig2))^2)
#             logL <- log(L)+ log(density[i])
#       }
#   
#       return(-logL)
# }



## Main program

## A. Set working environment
# Capsis install directory
if (.Platform$OS.type == "windows"){
  CapsisDir = "C:/Capsis4"
} else {
  CapsisDir = "/CECI/home/users/a/n/andref/Capsis4/"
}
setwd(CapsisDir) # Set working directory
#cmd.args <- commandArgs()
#m <- regexpr("(?<=^--file=).+", cmd.args, perl=TRUE)
#script.dir <- dirname(regmatches(cmd.args, m))
#setwd(script.dir); setwd("../../..")

# Export filename for Capsis output
script.name <- basename(strsplit(commandArgs(trailingOnly = FALSE)[4],"=")[[1]][2])
script.name <- substr(script.name,1,nchar(script.name)-2)
exportFileName = paste("ObsPred_", script.name, ".out", sep = "")

## B. Optimization configuration
# Settings (considered as common to all species)
turbidMediumActivated <- "true"
crownForm <- "M"
ladOption <- 2 #0: mean LAD, 1: mean SLA, 2: SLA model, 3: Quergus LAD

# Set optimization results directory
if (.Platform$OS.type == "windows"){
  OptimResultsDir = paste(CapsisDir, "/src/heterofor/myscripts/CalibRadiationInterception", paste("/",crownForm,"_TM",turbidMediumActivated,"_LADopt",as.character(ladOption), sep = ""), sep = "")
} else {
  OptimResultsDir = paste(CapsisDir, "/src/heterofor/myscripts/CalibRadiationInterception/Clusters", paste("/",crownForm,"_TM",turbidMediumActivated,"_LADopt",as.character(ladOption), sep = ""), sep = "");
}
dir.create(OptimResultsDir)

# Set initial guesses to parameter values from speciesFile
# 1-Read speciesFile
speciesFile <- paste("/data/heterofor/inventories/Ligot_Calib112017/heterofor_species_", crownForm, ".txt", sep = "")
speciesParameters <- data.frame()
con <- file(paste(CapsisDir, speciesFile, sep = ""), open = "r")
conLine <- scan(con, character(0), nlines = 1, sep = "\t", quiet = TRUE)
while (conLine[1] != "# speciesId"){
  conLine <- scan(con, character(0), nlines = 1, sep = "\t", quiet = TRUE)
}
parameterNames <- conLine
for (l in 1:6){ # Read species parameters
  conLine <- scan(con, character(0), nlines = 1, sep = "\t", quiet = TRUE)
  speciesParameters <- rbind(speciesParameters, conLine, stringsAsFactors = FALSE)
}
names(speciesParameters) <- parameterNames
close(con)
# 2-Set initial guesses
extCoef_oak <- as.double(speciesParameters$extinctionCoefficient[1])
extCoef_beech <- as.double(speciesParameters$extinctionCoefficient[2])
extCoef_carpinus <- as.double(speciesParameters$extinctionCoefficient[3])

SLAintercept_oak <- as.double(speciesParameters$SLAintercept[1])
SLAintercept_beech <- as.double(speciesParameters$SLAintercept[2])
SLAintercept_carpinus <- as.double(speciesParameters$SLAintercept[3])

SLAdown_oak <- as.double(speciesParameters$SLAdown[1])
SLAdown_beech <- as.double(speciesParameters$SLAdown[2])
SLAdown_carpinus <- as.double(speciesParameters$SLAdown[3])

initGuess <- c(extCoef_oak, extCoef_beech, extCoef_carpinus, SLAintercept_oak, SLAintercept_beech, SLAintercept_carpinus, SLAdown_oak, SLAdown_beech, SLAdown_carpinus)

# 3-Optimization bounds
LB <- c(0.01, 0.01, 0.01, -30, -30, -30, 5, 5, 5)
UB <- c(1.00, 1.00, 1.00, 40, 40, 40, 50, 50, 50)


# 4-Optimization
p <- initGuess
#L <- likelihood(p)
fit <- nlm(SSQ, p, iterlim = 10000, print.level = 2)

# 5-Printing and saving optimization results
fit$estimate
fit$minimum
fit$code

ObsPred.fit <- Heterofor.RadiativeBalance_output(CapsisDir, exportFileName, turbidMediumActivated, crownForm, ladOption, fit$estimate[1], fit$estimate[2], fit$estimate[3], fit$estimate[4], fit$estimate[5], fit$estimate[6], fit$estimate[7], fit$estimate[8], fit$estimate[9])
ObsPred.fit


##Printing simulation results
ObsPred.initGuess <- Heterofor.RadiativeBalance_output(CapsisDir, exportFileName, turbidMediumActivated, crownForm, ladOption, initGuess[1], initGuess[2], initGuess[3], initGuess[4], initGuess[5], initGuess[6], initGuess[7], initGuess[8], initGuess[9])
ObsPred.initGuess

OutputFileName = paste(OptimResultsDir,"/CalibrationResults.RData", sep = "")
save(fit, ObsPred.fit, ObsPred.initGuess, file = OutputFileName)



###################### PLOTS ########################################
 # setwd(OptimResultsDir)
 # load("CalibrationResults.RData")
 # 
 # # 1-Direct radiation
 # plot(ObsPred.fit$directPred, ObsPred.fit$directObs, pch=1, col="red", main="Relative direct radiation", xlab="Predicted (%)", ylab="Observed (%)")
 # points(ObsPred.initGuess$directPred, ObsPred.initGuess$directObs, pch=8, col='blue')
 # legend(max(ObsPred.fit$directPred)-10, min(ObsPred.fit$directObs)+10, legend=c("Fit", "InitGuess"), pch=c(1,8), col=c("red", "blue"))
 # abline(0, 1, lty=2, lwd=3)
 # fit.reg = lm(directObs ~ directPred, data = ObsPred.fit); abline(fit.reg$coefficients[1], fit.reg$coefficients[2], lty=2, lwd=2, col="red")
 # init.reg = lm(directObs ~ directPred, data = ObsPred.initGuess); abline(init.reg$coefficients[1], init.reg$coefficients[2], lty=2, lwd=2, col="blue")
 # 
 # 
 # # 2-Diffuse radiation
 # plot(ObsPred.fit$diffusePred, ObsPred.fit$diffuseObs, pch=1, col="red", main="Relative diffuse radiation", xlab="Predicted (%)", ylab="Observed (%)")
 # points(ObsPred.initGuess$diffusePred, ObsPred.initGuess$diffuseObs, pch=8, col='blue')
 # legend(max(ObsPred.fit$diffusePred)-10, min(ObsPred.fit$diffuseObs)+10, legend=c("Fit", "InitGuess"), pch=c(1,8), col=c("red", "blue"))
 # abline(0, 1, lty=2, lwd=3)
 # fit.reg = lm(diffuseObs ~ diffusePred, data = ObsPred.fit); abline(fit.reg$coefficients[1], fit.reg$coefficients[2], lty=2, lwd=2, col="red")
 # init.reg = lm(diffuseObs ~ diffusePred, data = ObsPred.initGuess); abline(init.reg$coefficients[1], init.reg$coefficients[2], lty=2, lwd=2, col="blue")
 # 
 # 
 # # 3-Total radiation
 # plot(ObsPred.fit$totalPred, ObsPred.fit$totalObs, pch=1, col="red", main="Relative total radiation", xlab="Predicted (%)", ylab="Observed (%)")
 # points(ObsPred.initGuess$totalPred, ObsPred.initGuess$totalObs, pch=8, col='blue')
 # legend(max(ObsPred.fit$totalPred)-10, min(ObsPred.fit$totalObs)+10, legend=c("Fit", "InitGuess"), pch=c(1,8), col=c("red", "blue"))
 # abline(0, 1, lty=2, lwd=3)
 # fit.reg = lm(totalObs ~ totalPred, data = ObsPred.fit); abline(fit.reg$coefficients[1], fit.reg$coefficients[2], lty=2, lwd=2, col="red")
 # init.reg = lm(totalObs ~ totalPred, data = ObsPred.initGuess); abline(init.reg$coefficients[1], init.reg$coefficients[2], lty=2, lwd=2, col="blue")






