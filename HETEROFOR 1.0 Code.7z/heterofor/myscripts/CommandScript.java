/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.myscripts;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
// import heterofor.model.HetSensor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import jeeb.lib.util.Check;
import jeeb.lib.util.Log;
import capsis.app.C4Script;
import jeeb.lib.util.PathManager;

/**
 * A script for Heterofor. The script needs one parameter: a command file name (See
 * CommandFileReader). To run the script from a windows terminal:
 * 
 * <pre>
 * capsis -p script heterofor.myscripts.CommandScript <commandFileName>
 * </pre>
 * 
 * @author M. Jonard, F. de Coligny, November 2012
 */
public class CommandScript {

	public static void main (String[] args) throws Exception {

		// Check the parameters
		// args[0] is the name of this script: heterofor.myscripts.CommandScript (useless)
		// args[1] is the name of command file to be processed
		if (args == null || args.length != 2) { throw new Exception ("One parameter needed: missing command file name"); }

		// Check the command file
		String commandFileName = args[1];
		if (!Check.isFile (commandFileName)) { throw new Exception ("Wrong command file name: " + commandFileName); }
		System.out.println ("commandFileName: " + commandFileName);

		// Read and interpret the command file
		CommandFileReader commandFileReader = null;
		try {
			commandFileReader = new CommandFileReader (commandFileName);

		} catch (Exception e) {
			Log.println (Log.ERROR, "CommandScript.main ()", "CommandFileReader threw an exception", e);
			throw new Exception ("Error, CommandFileReader threw an exception: " + e.getMessage ()
					+ ", see Log for details");
		}

		// Set the export fileNames and the workingDir
		String fileName = commandFileReader.getExportFileName ();
		String fileName2 = fileName + "2"; // a quickly way to get a second fileName
		String workingDir = null;
		try {
			File in = new File (commandFileName);
			File commandFileDir = in.getParentFile ();
			workingDir = commandFileDir.getAbsolutePath ();

		} catch (Exception e) {
			Log.println (Log.ERROR, "CommandScript.main ()", "Could not set the export dir: commandFileName: "
					+ commandFileName + " workingDir: " + workingDir, e);
		}

		// Create the export file writers
		String exportFileName = workingDir + "/" + fileName;
		SensorEnergyWriter writer = new SensorEnergyWriter (exportFileName);
		System.out.println ("exportFileName: " + exportFileName);

		String exportFileName2 = workingDir + "/" + fileName2;
		TreeEnergyWriter writer2 = new TreeEnergyWriter (exportFileName2);
		System.out.println ("exportFileName2: " + exportFileName2);

		String speciesFileName = commandFileReader.getSpeciesFileName ();
		
		// Run a simulation for each line in commandFileReader
		int count = 0;
		for (CommandFileReader.CommandLine line : commandFileReader.getCommandLines ()) {

			count++; // a simulation counter
			runOneSimulation (line, writer, writer2, workingDir, speciesFileName, count);

		}

		// Close the export file writers and write an ending message
		writer.close ();
		writer2.close ();
		System.out.println ("wrote sensors energy in: " + exportFileName);
		System.out.println ("wrote trees energy in: " + exportFileName2);
		System.out.println ("heterofor.myscripts.CommandScript is over.");

	}

	/**
	 * Called for each line in the command line. Runs one simulation, write the sensors and/or trees
	 * energy in the shared export files.
	 */
	static private void runOneSimulation (CommandFileReader.CommandLine line, SensorEnergyWriter writer,
			TreeEnergyWriter writer2, String workingDir, String speciesFileName, int count) throws Exception {

		System.out.println ("Heterofor CommandScript, running simulation " + count
				+ " for the following command line:\n " + line);

		C4Script s = new C4Script ("heterofor");

		HetInitialParameters i = new HetInitialParameters (workingDir + "/" + speciesFileName, workingDir + "/" + line.inventoryFileName, workingDir + "/"
				+ line.samsaraLightFileName);

//		// Change the String LADoption from the command file into the correct int
//		// HetInitialParameters option
//		int LADoption = line.LADoption.equals ("MEAN_LAD") ? HetInitialParameters.MEAN_LAD : line.LADoption
//				.equals ("MEAN_SLA") ? HetInitialParameters.MEAN_SLA
//				: line.LADoption.equals ("QUERGUS_LAD") ? HetInitialParameters.QUERGUS_LAD
//						: HetInitialParameters.SLA_MODEL;
//		i.LADoption = LADoption;
//
//		// Toption, GL, 21/05/2013
//		int Toption = line.Toption.equals ("MEAN_T") ? HetInitialParameters.MEAN_T
//				: line.Toption.equals ("QUERGUS_T") ? HetInitialParameters.QUERGUS_T : HetInitialParameters.MEAN_T;
//		i.Toption = Toption;

		// i.sensorHeight = line.sensorHeight; //commented by GL on 19/04/2013
		i.LADNeighbourhoodDistance = line.LADNeighbourhoodDistance;
		i.fillGaps = line.fillGaps;

		s.init (i);

		HetScene initScene = (HetScene) s.getRoot ().getScene ();
		HetModel model = (HetModel) s.getModel ();

		System.out.println ("Heterofor CommandScript, loaded " + initScene.getTrees ().size () + " trees");

		// fc-26.6.2014 One of the 2 lines below may be commented to get only one file
		writer.exportSensorsEnergy (model, initScene, i.inventoryFileName, i.samsaraLightFileName, i.speciesFileName, i.sensorHeight);
		writer2.exportTreesEnergy (model, initScene, i.inventoryFileName, i.samsaraLightFileName, i.speciesFileName);

		// Close the project
		s.closeProject ();
	}

}