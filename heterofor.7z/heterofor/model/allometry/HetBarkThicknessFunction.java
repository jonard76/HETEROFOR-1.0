/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing bark thickness.
 * 
 * @author M. Jonard, L. de Wergifosse, F. de Coligny - October 2016
 */
public class HetBarkThicknessFunction extends HetSimpleFunction {

	private double a;
	private double b;
	private double c;
	private double d;

	/**
	 * Constructor.
	 */
	public HetBarkThicknessFunction(String str) throws Exception { // e.g.
																	// barkThicknessFunction(0.08;-0.26;0.32478;0.32478)
		if (!str.startsWith("barkThicknessFunction(")) {
			throw new Exception("HetBarkThicknessFunction error, string should start with \"barkThicknessFunction(\": "
					+ str);
		}
		String s = str.replace("barkThicknessFunction(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());
		d = Check.doubleValue(st.nextToken());

	}

	/**
	 * The diameter: of the stem or of branch compartments.
	 */
	@Override
	public double result(double diameter) { // cm

		double girth = diameter * Math.PI;

		double thickness = a + b * girth + c * girth * girth + d * girth * girth * girth;

		thickness = Math.max(0.1, thickness); // at least 0.1 mm, to be reviewed
		
		return thickness;

	}

	public String toString() {
		return "barkThicknessFunction(" + a + ";" + b + ";" + c + ";" + d + ")";
	}

}
