/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing the fraction of small branch biomass based on total
 * branch biomass.
 *
 * @author F. de Coligny - March 2016
 */
public class HetSmallBranchFracFunction extends HetSimpleFunction {

	private double a;
	private double b;
	private double c;

	/**
	 * Constructor.
	 */
	public HetSmallBranchFracFunction(String str) throws Exception { // e.g.
																	// smallBranchFracFunction(0.08;-0.26;0.32478)
		if (!str.startsWith("smallBranchFracFunction(")) {
			throw new Exception(
					"HetSmallBranchFracFunction error, string should start with \"smallBranchFracFunction(\": " + str);
		}
		String s = str.replace("smallBranchFracFunction(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());

	}


	@Override
	public double result(double branchBiomass) {

		return Math.min (a + Math.exp (b * Math.pow (branchBiomass, c)), 1);//Added by MJ 26/04/2016

	}

	public String toString() {
		return "smallBranchFracFunction(" + a + ";" + b + ";" + c + ")";
	}



}
