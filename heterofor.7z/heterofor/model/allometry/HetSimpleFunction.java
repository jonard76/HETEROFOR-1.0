/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.allometry;

import java.io.Serializable;

/**
 * A superclass for simple f(x) functions.
 * 
 * @author F. de Coligny - March 2016
 */
public abstract class HetSimpleFunction implements Serializable {

	/**
	 * A convenient method to decode a HetSimpleFunction
	 */
	static public HetSimpleFunction getFunction(String encodedFunction) throws Exception {
		if (encodedFunction.startsWith("smallBranchFracFunction")) {
			return new HetSmallBranchFracFunction(encodedFunction);
			
		} else if (encodedFunction.startsWith("coarseBranchFracFunction")) {
			return new HetCoarseBranchFracFunction(encodedFunction);
			
		} else if (encodedFunction.startsWith("smallRootFracFunction")) {
			return new HetSmallRootFracFunction(encodedFunction);
			
		} else if (encodedFunction.startsWith("coarseRootFracFunction")) {
			return new HetCoarseRootFracFunction(encodedFunction);

		} else if (encodedFunction.startsWith("crownToStemDiameterEstimation")) {
			return new CrownToStemDiameterEstimation(encodedFunction);

		} else if (encodedFunction.startsWith("barkProportionFunction")) {
			return new HetBarkProportionFunction(encodedFunction);

		} else if (encodedFunction.startsWith("barkThicknessFunction")) {
			return new HetBarkThicknessFunction(encodedFunction);

		} else if (encodedFunction.startsWith("sapwoodArea")) {
			return new HetSapwoodArea(encodedFunction);

		} else if (encodedFunction.startsWith("treeHeight")) {
			return new HetTreeHeight(encodedFunction);
			
		} else if (encodedFunction.startsWith("treeHeightLigot")) {
			return new HetTreeHeightLigot(encodedFunction);
			
		} else if (encodedFunction.startsWith("seedlingD5ToD130")) {
			return new HetSeedlingD5ToD130(encodedFunction);
			
		} else if (encodedFunction.startsWith("seedlingTransmittanceToSLA")) {
			return new HetSeedlingTransmittanceToSLA(encodedFunction);
			
		} else if (encodedFunction.startsWith("seedlingHeightToLAI")) {
			return new HetSeedlingHeightToLAI(encodedFunction);

		} else if (encodedFunction.startsWith("rootToShootRatioFunction")) {
			return new HetRootToShootRatioFunction(encodedFunction);

		} else if (encodedFunction.startsWith("seedlingHeightToCrownRadius")){
			return new HetSeedlingHeightToCrownRadius(encodedFunction);
			
		} else {
			throw new Exception("HetSimpleFunction, unknown function: " + encodedFunction);
		}

	}

	/**
	 * A simple f(x) method, returns y.
	 */
	public abstract double result(double x);

}
