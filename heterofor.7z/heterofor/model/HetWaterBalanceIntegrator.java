/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Integrates the given Map of water balance with key year_month_day_hour to
 * obtain another one at year, month or day level depending on the user request.
 * Some values are summed, some others are averaged.
 * 
 * <pre>
 * // Example of use
 * // Given a wbMap containing waterBalance objects for several years 
 * // (i.e. thousands of hourly objects)
 * // How to get a map with only one integrated object per year
 * HetWaterBalanceIntegrator wbi = HetWaterBalanceIntegrator(wbMap, HetWaterBalanceIntegrator.YEAR_LEVEL)
 * LinkedHashMap<String, HetWaterBalance> yearlyWBMap = wbi.integrate ();
 * </pre>
 * 
 * @author F. de Coligny, N. Beudez - March 2017
 */
public class HetWaterBalanceIntegrator {

	/**
	 * The year integration level
	 */
	public static final int YEAR_LEVEL = 1;
	
	/**
	 * The month integration level
	 */
	public static final int MONTH_LEVEL = 2;
	
	/**
	 * The day integration level
	 */
	public static final int DAY_LEVEL = 3;

	// Key is year_month_day_hour, data for one or several years
	// WaterBalance maps are always sorted on ascending keys (i.e. time) in
	// LinkedHashMaps
	private LinkedHashMap<String, HetWaterBalance> originalWBMap;
	private int integrationLevel; // e.g. YEAR_LEVEL

	/**
	 * <pre>
	 * The time string depending on the integration level
	 * e.g.: 2002_		if integration level is equal to YEAR_LEVEL
	 *       2002_5_  	if integration level is equal to MONTH_LEVEL
	 *       2002_5_14	if integration level is equal to DAY_LEVEL
	 * </pre>
	 */
	private String currentTime;

	/**
	 * Constructor
	 * @throws Exception 
	 */
	public HetWaterBalanceIntegrator(LinkedHashMap<String, HetWaterBalance> originalWBMap, int integrationLevel) throws Exception {

		if (integrationLevel<1 || integrationLevel>3) {
			throw new Exception("Could not create HetWaterBalanceIntegrator. Bad integration level: " 
					+ integrationLevel + " Should be in [" + YEAR_LEVEL + "," + DAY_LEVEL + "]");
		}
		
		this.originalWBMap = originalWBMap;
		this.integrationLevel = integrationLevel;
	}

	/**
	 * Sets the values of year, month and day instance variables of HetWaterBalance object
	 * according to the ymdh current date and the integration level (YEAR_LEVEL, MONTH_LEVEL, DAY_LEVEL).
	 * @param wb The HetWaterBalance object
	 * @param ymdh The current date with format year_month_day_hour
	 * @throws Exception
	 */
	private void setWBYearMonthDay(HetWaterBalance wb, String ymdh) throws Exception {
		
		wb.year = -1;
		wb.month = -1;
		wb.day = -1;
		
		int[] ymdhTab = HetWaterBalance.decomposeKey(ymdh);
		if (integrationLevel >= YEAR_LEVEL)
			wb.year = ymdhTab[0];
		if (integrationLevel >= MONTH_LEVEL)
			wb.month = ymdhTab[1];
		if (integrationLevel >= DAY_LEVEL)
			wb.day = ymdhTab[2];
	}
	
	/**
	 * Runs the integration, returns a map with less entries (one per year, per
	 * month or per day, depending on the integration level).
	 */
	public LinkedHashMap<String, HetWaterBalance> integrate() throws Exception {

		// The map with less entries
		LinkedHashMap<String, HetWaterBalance> outMap = new LinkedHashMap<>();
		
		// The wb object containing summed and averaged values for a year, month or day  
		// depending on the integration level (year, month or day)
		HetWaterBalance wb = new HetWaterBalance();
		
		boolean wbYearMonthDayAreCalculated = false;
		
		// Loop over all entries (hours) of originalWBMap
		// ymdh: the year_month_day_hour string
		for (String ymdh : originalWBMap.keySet()) {

			if (!wbYearMonthDayAreCalculated) {				
				setWBYearMonthDay(wb, ymdh);				
				wbYearMonthDayAreCalculated = true;
			}
			
			// First time init
			if (currentTime == null) {
				// Calculate initial currentTime value
				timeInit(ymdh);
			}

			// Read next waterbalance object
			HetWaterBalance wbSource = originalWBMap.get(ymdh);
			
			// If time changes according to integration level (change of year,
			// of month...), integrate (calculate the average values), write the integrated wb and
			// reinitialize for new time (year, month...)
			if ( timeBreak(ymdh) ) {
				// Finish integration (average values)
				wb.integrate();

				// One integrated wb with sums and average values
				outMap.put(currentTime, wb);

				// Reinit time for next break
				wb = new HetWaterBalance();
				timeInit(ymdh);
				setWBYearMonthDay(wb, ymdh);								
				wbYearMonthDayAreCalculated = true;				
			}

			// Add in wb
			wb.add(wbSource);
		}

		// Last integrated wb with sums and average values
		// Finish integration (average values)
		wb.integrate();
		outMap.put(currentTime, wb);

		return outMap;
	}

	/**
	 * Calculates the current time of the given ymdh depending on the integration level (year, month or day).  
	 * @param ymdh The time with format year_month_day_hour
	 */
	private void timeInit(String ymdh) throws Exception {

		int[] ymdhTab = HetWaterBalance.decomposeKey(ymdh);

		StringBuffer b = new StringBuffer();

		if (integrationLevel >= YEAR_LEVEL)
			b.append(ymdhTab[0] + "_");
		if (integrationLevel >= MONTH_LEVEL)
			b.append(ymdhTab[1] + "_");
		if (integrationLevel >= DAY_LEVEL)
			b.append(ymdhTab[2] + "_");

		// e.g. MONTH-LEVEL: 2002_1_
		currentTime = b.toString();		
	}

	/**
	 * Returns true if the given time starts with currentTime. Format of ymdh is year_month_day_hour.
	 * Format of currentTime is year_ or year_month_ or year_month_day_ depending on integration level. 
	 * @param ymdh The time with format year_month_day_hour to be compared t currentTime
	 * @return true if ymdh starts with currentTime, false otherwise
	 * @throws Exception
	 */
	private boolean timeBreak(String ymdh) throws Exception {		
		
		boolean sameTime = ymdh.startsWith(currentTime);
		return !sameTime;
	}

}
