package heterofor.model;

import java.io.Serializable;
import java.util.Map;
import java.util.Random;

import capsis.lib.regeneration.RGCell;
import capsis.lib.regeneration.RGCohort;
import capsis.lib.regeneration.RGCohortSizeClass;
import heterofor.model.allometry.HetSeedlingD5ToD130;

/**
 * A size class in a HetCohort.
 *
 * @author M. Jonard, B. Ryelandt, N. Donès, F. de Coligny - October 2018
 */
public class HetCohortSizeClass extends RGCohortSizeClass implements Serializable {

	// fc+mj+fa+br-22.5.2019
	private boolean wasInitialized;

	// fc+mj+br-4.10.2018 Keep a ref at last processLighting () call time,
	// available for understoreyGrowth () call time
	protected double incidentEnergy; // MJ/year

	// fc+mj+br-4.10.2018 this reference must be set every year before calling
	// understoreyGrowth()
	protected Map<String, HetWaterBalance> waterBalanceMap;

	// fc+mj+fa-28.5.2019
	protected double leafBiomassAvg_kgC; // kgC

	protected double leafAreaAvg; // m2
	protected double biomassAvg_kgC; // kgC
	protected double maxCrownProjectionAvg; // m2
	protected double meanCrownProjectionAvg = 0d; // m2
	protected double dbh = 0d; // cm
	protected double sla = 0d; // m2/kgOM

	protected double yearlyNPPAvg_kgC;
	protected double yearlyGPP_kgC;
	protected double yearlyNPP_kgC;

	protected double heightThreshold = 6d; // threshold for seedlings to
											// saplings

	/**
	 * Default constructor.
	 */
	public HetCohortSizeClass() {
	}

	/**
	 * Constructor.
	 */
	public HetCohortSizeClass(int id, HetCohort cohort, double heightAvg, double diameterAvg, int number) {
		// fc-3.10.2018 Added cohort
		super(id, cohort, heightAvg, diameterAvg, number);
	}

	/**
	 * Calculates the energy intercepted by this object and returns the
	 * remaining energy.
	 *
	 * @param energy
	 *            : available above the object
	 * @param incidentEnergy
	 *            : total energy above canopy
	 * @return energy available below the object
	 */
	@Override
	public double processLighting(RGCell cell, double incidentEnergy, double aboveEnergy) {

		this.incidentEnergy = incidentEnergy;

		HetSpecies sp = (HetSpecies) cohort.getSpecies();

		double cellArea = cell.getArea(); // m2
		double plotArea = cell.getPlot().getArea(); // m2

		// fc+mj+fa+br-22.5.2019
		if (!wasInitialized) {
			init(cell);
			wasInitialized = true;
		}
		// if (leafAreaAvg == 0)
		// init(cell);

		double classLai = 0d;

		// if (heightAvg < heightThreshold)

		// fc+mj+fa-28.5.2019 removed the if()
		classLai = sp.seedlingHeightToLAI.result(heightAvg);

		// else
		// classLai = (number * leafAreaAvg) / (cellArea * cover);

		double aboveEnergy_MJm2 = aboveEnergy / cellArea;

		double belowEnergy_MJm2 = (1 - cover) * aboveEnergy_MJm2
				+ cover * aboveEnergy_MJm2 * Math.exp(-sp.extinctionCoefficient * classLai);

		// Transmittance above size class
		transmittance = ((aboveEnergy_MJm2) / (incidentEnergy / cellArea)) * 100d;

		// Set absorbed energy in MJ
		setEnergy_MJ((aboveEnergy_MJm2 - belowEnergy_MJm2) * cellArea);

		// Set energy available above Cohort Size Clase
		setEnergy_Above_MJ(aboveEnergy_MJm2 * cellArea);

		// Set energy available below Cohort Size Clase
		setEnergy_Below_MJ(belowEnergy_MJm2 * cellArea);

		if (getEnergy_MJ() == 0)
			System.out.println("Breakpoint in HetCohortSizeClass");

		// Returns energy (remaining) below the saplings in MJ
		return belowEnergy_MJm2 * cellArea;

	}

	/**
	 * Called at first processLightingTime to init the size class.
	 */
	private void init(RGCell cell) {

		HetCell refCell = (HetCell) cell;

		// heightAvg comes from the inventory file

		// Initialise transmittance for init time
		transmittance = 15d;

		// fc+mj+fa+br-22.5.2019
		boolean initStage = true;
		updateSeedlingCharacteristics(initStage, refCell, (HetSpecies) this.cohort.getSpecies(), this.cohort.getYear(),
				this);

		// number comes from the inventory file

		// Cover
		// if (heightAvg < heightThreshold)
		// cover = (number * maxCrownProjectionAvg) / refCell.getArea();
		// else
		// cover = (number * meanCrownProjectionAvg) / refCell.getArea();
		// cover = Math.min(cover, 1d);

	}

	/**
	 * Updates the other characteristics of the seedling from heightAvg and
	 * transmittance.
	 */
	static private void updateSeedlingCharacteristics(boolean initStage, HetCell cell, HetSpecies species,
			int cohortAge, HetCohortSizeClass klass) {

		// HetScene refScene = (HetScene) refCell.getPlot().getScene();
		// HetModel model = (HetModel)
		// refScene.getStep().getProject().getModel();
		// HetInitialParameters ip = (HetInitialParameters) model.getSettings();

		HetSpecies sp = species;

		double crownToStemDiameter = 0d;

		// fc+mj+fa-28.5.2019 klass doesn't have its cohort ref set yet
		// klass.getCohort () == null
		// int cohortAge = klass.getCohort().getYear() + 1;

		if (klass.heightAvg < klass.heightThreshold) { // below 6 m height

			if (klass.heightAvg == -1)
				klass.heightAvg = sp.seedlingDiameterToHeight.result(klass.transmittance, klass.diameterAvg); // height
			// from
			// diameter

			if (klass.wasInitialized || (!klass.wasInitialized && klass.diameterAvg == -1))
				klass.diameterAvg = sp.seedlingHeightToDiameter.result(klass.transmittance, klass.heightAvg); // diameter
																												// from
																												// height

			if (klass.heightAvg > 1.30)
				klass.dbh = sp.seedlingD5ToD130.result(klass.diameterAvg);
			else
				klass.dbh = 0;

			double aerialBiomassAvg = sp.seedlingGetBiomass.result(klass.heightAvg, klass.diameterAvg) / 2d; // kgC


			// TO DO: create a HetFunction2Variables for
			// seedlingGetCrownToStemDiameter
			crownToStemDiameter = 130d; // d/d to be measured

			klass.sla = sp.seedlingTransmittanceToSLA.result(klass.transmittance);

//			double maxCrownRadius_m = crownToStemDiameter * klass.dbh / 200d;
			double maxCrownRadius_m = sp.seedlingHeightToCrownRadius.result(klass.heightAvg); // br 5-05-2019
			klass.maxCrownProjectionAvg = Math.PI * maxCrownRadius_m * maxCrownRadius_m;


			if (initStage) { // we come from init()
				klass.cover = (klass.number * klass.maxCrownProjectionAvg) / cell.getArea();
				klass.cover = Math.min(klass.cover, 1d);
			} else {
				// Calculated at the end of understoreyGrowth ()
				klass.cover = 0;
			}

			// fc+mj+fa-28.5.2019 possible alternative version
			double d = klass.dbh;
			if (klass.dbh == 0d) // mj+fa-06.06.2019
				d = 0.09 * cohortAge;
			klass.leafBiomassAvg_kgC = sp.leafBiomassAllometry.result(d, d + sp.defaultDeltaDbh,
					maxCrownRadius_m, sp.leafRetranslocationRate);

			// fc+mj+fa-28.5.2019 possible alternative version
			klass.leafAreaAvg = klass.leafBiomassAvg_kgC * 2d * klass.sla;

			klass.biomassAvg_kgC = aerialBiomassAvg * (1 + sp.rootToShootRatioFunction.result(cohortAge)) + (1d + sp.minFineRootToFoliageRatio)* klass.leafBiomassAvg_kgC;;


			// Alternative possible code

//			if (initStage) { // we come from init()
//				klass.cover = (klass.number * klass.maxCrownProjectionAvg) / cell.getArea();
//				klass.cover = Math.min(klass.cover, 1d);
//
//				// klass.leafBiomassAvg
//
//				double classLai = sp.seedlingHeightToLAI.result(klass.heightAvg);
//
//				 klass.leafBiomassAvg_kgC = classLai * cell.getArea() *
//				 klass.cover / klass.number / klass.sla * 0.5;
//
//				 klass.leafAreaAvg = classLai * cell.getArea() * klass.cover /
//				 klass.number;
//
//			} else { // we come from understoreyGrowth ()
//
//				// Calculated at the end of understoreyGrowth ()
//				klass.cover = 0;
//				klass.leafBiomassAvg_kgC = 0;
//				klass.leafAreaAvg = 0;
//			}

		} else { // above 6 m height

			if (!klass.wasInitialized && klass.diameterAvg != -1) {
				klass.dbh = sp.seedlingD5ToD130.result(klass.diameterAvg);
			} else {
				klass.dbh = sp.treeHeight.getDbh(klass.heightAvg);
				klass.diameterAvg = ((HetSeedlingD5ToD130) sp.seedlingD5ToD130).reverse(klass.dbh);
			}

			if (klass.heightAvg == -1)
				klass.heightAvg = sp.treeHeight.result(klass.dbh);

			// double diameterAvg_m = klass.diameterAvg / 100d;
			double dbh_m = klass.dbh / 100d;

			double aboveBiomassAvg_kgOM = sp.aboveBiomassAlpha
					+ sp.aboveBiomassBeta * Math.pow(dbh_m * dbh_m * klass.heightAvg, sp.aboveBiomassGamma);

			double mean2CrownRadius_m = sp.crownToStemDiameterEstimation.result(klass.dbh * Math.PI)
					* (klass.dbh / 200d);

			// System.out.println("Crown radius :," + mean2CrownRadius_m );

			klass.meanCrownProjectionAvg = mean2CrownRadius_m * mean2CrownRadius_m * Math.PI;

			if (initStage) { // we come from init()
				klass.cover = (klass.number * klass.meanCrownProjectionAvg) / cell.getArea();
				klass.cover = Math.min(klass.cover, 1d);

			} else { // we come from understoreyGrowth ()
				klass.cover = 0;
			}

			// fc+mj+fa-28.5.2019
			double d = klass.dbh;
			if (klass.dbh == 0d) // mj+fa-06.06.2019
				d = 0.09 * cohortAge;
			klass.leafBiomassAvg_kgC = sp.leafBiomassAllometry.result(d, d + sp.defaultDeltaDbh,
					mean2CrownRadius_m, sp.leafRetranslocationRate);
			// double newLeafBiomassAvg_kgC =
			// sp.leafBiomassAllometry.result(klass.diameterAvg,
			// klass.diameterAvg + sp.defaultDeltaDbh, mean2CrownRadius_m,
			// sp.leafRetranslocationRate);

			klass.biomassAvg_kgC = aboveBiomassAvg_kgOM / 2d * (1 + sp.rootToShootRatioFunction.result(cohortAge))
					+ (1d + sp.minFineRootToFoliageRatio)* klass.leafBiomassAvg_kgC;

			klass.sla = sp.SLAtop + (sp.SLAbottom - sp.SLAtop) * (100d - klass.transmittance) / 100d;
			klass.leafAreaAvg = klass.leafBiomassAvg_kgC * 2d * klass.sla;

		}

	}

	@Override
	public HetCohortSizeClass understoreyGrowth(RGCohort cohort, RGCell cell) throws Exception {

		HetCohortSizeClass newKlass = (HetCohortSizeClass) this.clone();

		HetCell refCell = (HetCell) cell;
		HetScene refScene = (HetScene) refCell.getPlot().getScene();
		HetModel model = (HetModel) refScene.getStep().getProject().getModel();
		HetInitialParameters ip = (HetInitialParameters) model.getSettings();

		int newYear = refScene.getDate() + 1;

		int newAge = this.getCohort().getYear() + 1;

		HetSpecies sp = (HetSpecies) cohort.getSpecies();

		newKlass.growthHeight = sp.seedlingHeightGrowth.result(this.transmittance, this.heightAvg);
		newKlass.heightAvg = this.heightAvg + newKlass.growthHeight;

		// Transmittance was set by processLighting ()

		// fc+mj+fa+br-22.5.2019
		boolean initStage = false;
		updateSeedlingCharacteristics(initStage, refCell, sp, newAge, newKlass);

		// double newLeafBiomassAvg_kgC = 0d;
		double prevKlassLai = 0d;

		if (newKlass.heightAvg < newKlass.heightThreshold) {

			// fc+mj+fa-28.5.2019
			prevKlassLai = sp.seedlingHeightToLAI.result(this.heightAvg);

		} else {
			prevKlassLai = (this.number * this.leafAreaAvg) / (cell.getArea() * this.cover);

		}

		// There are cases were newKlass.leafBiomassAvg could not be calculated
		// -> use this.leafBiomassAvg
		double newLeafBiomassAvg = this.leafBiomassAvg_kgC;
		if (newKlass.leafBiomassAvg_kgC != 0)
			newLeafBiomassAvg = newKlass.leafBiomassAvg_kgC;

		double nppAvg_kgC = (newKlass.biomassAvg_kgC - this.getBiomassAvg_kgC())
				+ (1d + sp.minFineRootToFoliageRatio) * (newLeafBiomassAvg*(1-sp.leafRetranslocationRate));

		// Default number: copied
		int newNumber = number; // to be reviewed (parUseEfficiency approach)

		// fc+mj+br-4.10.2018 If available, use photosynthesis to update number
		if (ip.castaneaPhotosynthesisActivated && ip.waterBalanceActivated && ip.meteorology != null) {

			HetSeedlingCastaneaPhotosynthesis scp = new HetSeedlingCastaneaPhotosynthesis(ip, refScene, refCell, this,
					model, newYear, prevKlassLai);
			scp.run();

			newKlass.yearlyGPP_kgC = scp.getYearlyGPP_kgC();

		} else { // PUE
			double sunlitLeafArea = (1d - Math.exp(-sp.extinctionCoefficient * prevKlassLai)) / sp.extinctionCoefficient
					* cell.getArea();
			double shadedLeafArea = prevKlassLai * cell.getArea() - sunlitLeafArea;
			double interceptedParRadiation = (1 - 0.11) * this.getEnergy_MJ() * 4.55 * 0.46;
			double interceptedDirectParRadiation = interceptedParRadiation
					* refCell.getLightResult().get_horizontalEnergyDirect()
					/ (refCell.getLightResult().get_horizontalEnergyDirect()
							+ refCell.getLightResult().get_horizontalEnergyDiffuse());
			double interceptedDiffuseParRadiation = interceptedParRadiation
					* refCell.getLightResult().get_horizontalEnergyDiffuse()
					/ (refCell.getLightResult().get_horizontalEnergyDirect()
							+ refCell.getLightResult().get_horizontalEnergyDiffuse());
			double interceptedPAR_sunlitLeaves_m2leaf = interceptedDirectParRadiation / sunlitLeafArea
					+ interceptedDiffuseParRadiation / (sunlitLeafArea + shadedLeafArea);
			double interceptedPAR_shadedLeaves_m2leaf = interceptedDiffuseParRadiation
					/ (sunlitLeafArea + shadedLeafArea);
			double parUseEfficiency = (sp.sunlitPUE * interceptedPAR_sunlitLeaves_m2leaf * sunlitLeafArea
					+ sp.shadedPUE * interceptedPAR_shadedLeaves_m2leaf * shadedLeafArea) / interceptedParRadiation;
			// double parUseEfficiency = 0.001;

			// double sunlitLeafArea = (1d - Math.exp(-sp.extinctionCoefficient
			// * classLai)) / sp.extinctionCoefficient * cell.getArea();
			// double shadedLeafArea = classLai * cell.getArea() -
			// sunlitLeafArea;
			//
			// double interceptedParRadiation = (1 - 0.11) * this.getEnergy_MJ()
			// * 4.55 * 0.46;
			//
			// double parUseEfficiency = (sp.sunlitPUE *
			// refCell.getLightResult().get_horizontalEnergyDirect() +
			// (sp.sunlitPUE + sp.shadedPUE)
			// * refCell.getLightResult().get_horizontalEnergyDiffuse()) /
			// (refCell.getLightResult().get_horizontalEnergyDirect() +
			// refCell.getLightResult().get_horizontalEnergyDiffuse());
			newKlass.yearlyGPP_kgC = parUseEfficiency * interceptedParRadiation
					* refScene.getNextYearVegetationPeriodLength() / refScene.getRefVegetationPeriodLength(); // kgC
		}

		double nppToGppRatio = 0.5;
		newKlass.yearlyNPP_kgC = newKlass.yearlyGPP_kgC * nppToGppRatio;

		newNumber = (int) Math.floor((newKlass.yearlyNPP_kgC / nppAvg_kgC));
		newNumber = Math.min(newNumber, this.number);
		newKlass.number = newNumber;

		// Cover
		if (newKlass.heightAvg < newKlass.heightThreshold)
			newKlass.cover = (newKlass.number * newKlass.maxCrownProjectionAvg) / refCell.getArea();
		else
			newKlass.cover = (newKlass.number * newKlass.meanCrownProjectionAvg) / refCell.getArea();

		newKlass.cover = Math.min(newKlass.cover, 1d);

		// newKlass.leafAreaAvg & leafBiomassAvg_kgC were already calculated
		// in updateSeedlingCharacteristics ()
//		if (newKlass.heightAvg < heightThreshold) {
//			double newKlassLai = sp.seedlingHeightToLAI.result(newKlass.heightAvg);
//			newKlass.leafAreaAvg = (double) newKlassLai * cell.getArea() * newKlass.cover / newKlass.number;
//
//			newKlass.leafBiomassAvg_kgC = newKlass.leafAreaAvg / newKlass.sla / 2d;
//
//		} else {
//			// newKlass.leafAreaAvg & leafBiomassAvg_kgC were already calculated
//			// at the end of
//			// updateSeedlingCharacteristics ()
//		}

		newKlass.setYearlyNPPAvg_kgC(nppAvg_kgC);
		// newKlass.setYearlyNPP_kgC(newKlass.yearlyNPP_kgC);
		// newKlass.setYearlyGPP_kgC(newKlass.yearlyGPP_kgC);

		return newKlass;
	}

	/**
	 * The sizeClass is turned into adult trees
	 */
	public void recruit(HetCohort cohort, HetModel model, HetScene scene, HetCell cell) throws Exception {

		HetInitialParameters ip = model.getSettings();

		for (int j = 0; j < getNumber(); j++) {
			Random random = model.getRandom();
			int id = model.getTreeIdDispenser().getNext();

			double x = cell.getX() + random.nextDouble() * cell.getWidth();
			double y = cell.getY() + random.nextDouble() * cell.getWidth();
			double z = cell.getZ();

			HetSpecies sp = cohort.getSpecies();

			double height = this.getHeightAvg();

			double dbh = sp.treeHeight.getDbh(height);

//			double hlce = height * sp.hlceHeightProportion;
			double hlce = height * 0.5;
//			double hcb = height * sp.hcbHeightProportion;
			double hcb = height * 0.2;
			double c130_cm = dbh * Math.PI;

			double ctsd = sp.crownToStemDiameterEstimation.result(c130_cm);
			ctsd = Math.min(ctsd, 160);

			double rnorth = ctsd * dbh / 2d / 100d;

			double reast = rnorth;
			double rsouth = rnorth;
			double rwest = rnorth;

			HetTree newTree = new HetTree(id, scene, sp, dbh, height, hlce, hcb, rnorth, reast, rsouth, rwest, x, y, z,
					sp.crownForm, ip.treeChemistryDistribution, ip.foliarChemistryThresholds,
					ip.treeConcentrationLines);

			newTree.finishTreeInitialisation(ip);

			scene.addTree(newTree);
		}

	}

	public double getLeafAreaAvg() {
		return leafAreaAvg;
	}

	public void setLeafAreaAvg(double leafAreaAvg) {
		this.leafAreaAvg = leafAreaAvg;
	}

	public double getBiomassAvg_kgC() {
		return biomassAvg_kgC;
	}

	public void setBiomassAvg_kgC(double biomassAvg) {
		this.biomassAvg_kgC = biomassAvg;
	}

	public double getMaxCrownProjectionAvg() {
		return maxCrownProjectionAvg;
	}

	public double getDbh() {
		return dbh;
	}

	public double getSla() {
		return sla;
	}

	public void setMaxCrownProjectionAvg(double maxCrownProjectionAvg) {
		this.maxCrownProjectionAvg = maxCrownProjectionAvg;
	}

	public double getMeanCrownProjection() {
		return meanCrownProjectionAvg;
	}

	public void setMeanCrownProjection(double meanCrownProjection) {
		this.meanCrownProjectionAvg = meanCrownProjection;
	}

	public double getYearlyNPPAvg_kgC() {
		return yearlyNPPAvg_kgC;
	}

	public void setYearlyNPPAvg_kgC(double yearlyNPPAvg_kgC) {
		this.yearlyNPPAvg_kgC = yearlyNPPAvg_kgC;
	}

	public double getYearlyGPP_kgC() {
		return yearlyGPP_kgC;
	}

	public void setYearlyGPP_kgC(double yearlyGPP_kgC) {
		this.yearlyGPP_kgC = yearlyGPP_kgC;
	}

	public double getYearlyNPP_kgC() {
		return yearlyNPP_kgC;
	}

	public void setYearlyNPP_kgC(double yearlyNPP_kgC) {
		this.yearlyNPP_kgC = yearlyNPP_kgC;
	}

	public void setIncidentEnergy(double incidentEnergy) {
		this.incidentEnergy = incidentEnergy;
	}

	public double getIncidentEnergy() {
		return incidentEnergy;
	}

	public Map<String, HetWaterBalance> getWaterBalanceMap() {
		return waterBalanceMap;
	}

	public void setWaterBalanceMap(Map<String, HetWaterBalance> waterBalanceMap) {
		this.waterBalanceMap = waterBalanceMap;
	}

}
