/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.treechemistry;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jeeb.lib.util.ListMap;

/**
 * Foliar thresholds for given species and nutrients.
 * 
 * @author M. Jonard - March 2016
 */
public class HetFoliarChemistryThresholds implements Serializable {

	private ListMap<String, String> species_elementList;

	// Key: speciesName+'.'+elementName
	// Value: foliar deficiency concentration
	private Map<String, Double> deficiencyMap;

	// Key: speciesName+'.'+elementName
	// Value: foliar optimum concentration
	private Map<String, Double> optimumMap;

	/**
	 * Constructor
	 */
	public HetFoliarChemistryThresholds() {
		species_elementList = new ListMap<>();
		deficiencyMap = new HashMap<>();
		optimumMap = new HashMap<>();
	}

	public void add(String speciesName, String elementName, double foliarDeficiencyConcentration,
			double foliarOptimumConcentration) {
		
		species_elementList.addObject(speciesName, elementName);
		
		String key = speciesName+'.'+elementName;
		deficiencyMap.put(key, foliarDeficiencyConcentration);
		optimumMap.put(key, foliarOptimumConcentration);
		
	}

	public List<String> getElementNames (String speciesName) {
		return species_elementList.getObjects(speciesName);
	}
	
	public double getDeficiencyConcentration (String speciesName, String elementName) {
		String key = speciesName+'.'+elementName;
		return deficiencyMap.get(key);
	}
	
	public double getOptimumConcentration (String speciesName, String elementName) {
		String key = speciesName+'.'+elementName;
		return optimumMap.get(key);
	}
	
	// Mainly for checking in Capsis inspectors
	public Map<String, Double> getDeficiencyMap () {
		return deficiencyMap;
	}
	
	// Mainly for checking in Capsis inspectors
	public Map<String, Double> getOptimumMap() {
		return optimumMap;
	}
	
}
