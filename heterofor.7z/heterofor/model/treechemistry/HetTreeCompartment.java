/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.treechemistry;

import heterofor.model.HetElementState;
import heterofor.model.HetReporter;
import heterofor.model.HetSpecies;
import heterofor.model.HetTree;

import java.io.Serializable;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jeeb.lib.util.DefaultNumberFormat;
import jeeb.lib.util.ListMap;
import jeeb.lib.util.Log;

/**
 * HetTreeCompartment is a compartment in the tree, e.g. leaves, branches, fine
 * roots...
 * 
 * @author M. Jonard - February 2016
 */
public class HetTreeCompartment implements HetCompartment, Serializable {

	private static NumberFormat nf = DefaultNumberFormat.getInstance(2);

	// 13 compartment names
	public static final String LEAVES_UPPER_CURRENT = "LEAVES_UPPER_CURRENT";
	public static final String LEAVES_LOWER_CURRENT = "LEAVES_LOWER_CURRENT";
	public static final String LEAVES_UPPER_OLD = "LEAVES_UPPER_OLD";
	public static final String LEAVES_LOWER_OLD = "LEAVES_LOWER_OLD";
	public static final String BRANCHES_SMALL = "BRANCHES_SMALL"; // [0-4[ cm
	public static final String BRANCHES_MEDIUM = "BRANCHES_MEDIUM"; // [4-7[ cm
	public static final String BRANCHES_COARSE = "BRANCHES_COARSE"; // [7+ cm
	public static final String ROOTS_FINE = "ROOTS_FINE"; // [0-0.2[ cm
	public static final String ROOTS_SMALL = "ROOTS_SMALL"; // [0.2-4[ cm
	public static final String ROOTS_MEDIUM = "ROOTS_MEDIUM"; // [4-7[ cm
	public static final String ROOTS_COARSE = "ROOTS_COARSE"; // [7+ cm
	public static final String STEM = "STEM";
	public static final String MYCORRHIZAE = "MYCORRHIZAE";

	// names of tree compartment types
	public static final String TYPE_LEAF = "TYPE_LEAF";
	public static final String TYPE_BRANCH = "TYPE_BRANCH";
	public static final String TYPE_ROOT = "TYPE_ROOT";
	public static final String TYPE_STEM = "TYPE_STEM";
	public static final String TYPE_MYCORRHIZAE = "TYPE_MYCORRHIZAE";

	public static List<String> compartmentNames;
	public static Map<String, String> shortNames; // fc-28.9.2016
	public static Set<String> aboveGroundCompartmentTypes; // fc+mj-7.12.2016

	public static List<String> compartmentTypes;

	public static ListMap<String, String> type_names;
	
	
	static {
		compartmentNames = new ArrayList<>();
		compartmentNames.add(LEAVES_UPPER_CURRENT);
		compartmentNames.add(LEAVES_LOWER_CURRENT);
		compartmentNames.add(LEAVES_UPPER_OLD);
		compartmentNames.add(LEAVES_LOWER_OLD);
		compartmentNames.add(BRANCHES_SMALL);
		compartmentNames.add(BRANCHES_MEDIUM);
		compartmentNames.add(BRANCHES_COARSE);
		compartmentNames.add(ROOTS_FINE);
		compartmentNames.add(ROOTS_SMALL);
		compartmentNames.add(ROOTS_MEDIUM);
		compartmentNames.add(ROOTS_COARSE);
		compartmentNames.add(STEM);
		compartmentNames.add(MYCORRHIZAE);

		shortNames = new HashMap<>(); // fc-28.9.2016
		shortNames.put(LEAVES_UPPER_CURRENT, "tc.LUC");
		shortNames.put(LEAVES_LOWER_CURRENT, "tc.LLC");
		shortNames.put(LEAVES_UPPER_OLD, "tc.LUO");
		shortNames.put(LEAVES_LOWER_OLD, "tc.LLO");
		shortNames.put(BRANCHES_SMALL, "tc.BrS");
		shortNames.put(BRANCHES_MEDIUM, "tc.BrM");
		shortNames.put(BRANCHES_COARSE, "tc.BrC");
		shortNames.put(ROOTS_FINE, "tc.RoF");
		shortNames.put(ROOTS_SMALL, "tc.RoS");
		shortNames.put(ROOTS_MEDIUM, "tc.RoM");
		shortNames.put(ROOTS_COARSE, "tc.RoC");
		shortNames.put(STEM, "tc.St");
		shortNames.put(MYCORRHIZAE, "tc.My");

		aboveGroundCompartmentTypes = new HashSet<>();
		aboveGroundCompartmentTypes.add(TYPE_LEAF);
		aboveGroundCompartmentTypes.add(TYPE_BRANCH);
		aboveGroundCompartmentTypes.add(TYPE_STEM);

		compartmentTypes = new ArrayList<>();
		compartmentTypes.add(TYPE_LEAF);
		compartmentTypes.add(TYPE_BRANCH);
		compartmentTypes.add(TYPE_ROOT);
		compartmentTypes.add(TYPE_STEM);
		compartmentTypes.add(TYPE_MYCORRHIZAE);

		type_names = new ListMap<>();
		type_names.addObject(TYPE_LEAF, LEAVES_UPPER_CURRENT);
		type_names.addObject(TYPE_LEAF, LEAVES_LOWER_CURRENT);
		type_names.addObject(TYPE_LEAF, LEAVES_UPPER_OLD);
		type_names.addObject(TYPE_LEAF, LEAVES_LOWER_OLD);
		type_names.addObject(TYPE_BRANCH, BRANCHES_SMALL);
		type_names.addObject(TYPE_BRANCH, BRANCHES_MEDIUM);
		type_names.addObject(TYPE_BRANCH, BRANCHES_COARSE);
		type_names.addObject(TYPE_ROOT, ROOTS_FINE);
		type_names.addObject(TYPE_ROOT, ROOTS_SMALL);
		type_names.addObject(TYPE_ROOT, ROOTS_MEDIUM);
		type_names.addObject(TYPE_ROOT, ROOTS_COARSE);
		type_names.addObject(TYPE_STEM, STEM);
		type_names.addObject(TYPE_MYCORRHIZAE, MYCORRHIZAE);

	}

	public String name; // LEAVES_UPPER_CURRENT,... MYCORRHIZAE

	public double biomass; // kgC
	public double livingFraction; // [0, 1]
	public double diameter; // cm

	private HetElementState concentrations; // Nutrient name -> concentration
											// (mg/g)

	/**
	 * Constructor.
	 */
	public HetTreeCompartment(String name) {
		this.name = name;
		this.concentrations = new HetElementState();
	}

	public boolean isAboveGround() {
		return aboveGroundCompartmentTypes.contains(getType());
	}

	public HetTreeCompartment getCopy() {
		HetTreeCompartment copy = new HetTreeCompartment(this.name);

		copy.biomass = this.biomass;
		copy.livingFraction = this.livingFraction;
		copy.diameter = this.diameter;
		copy.concentrations = this.concentrations.getCopy();

		return copy;
	}

	public double getNutrientContent(String eName) {
		double Cconc = getConcentration(HetTreeElement.C);
		if (Cconc == 0)
			Cconc = 500;
		return biomass / (Cconc / 1000d) * (getConcentration(eName) / 1000d); // Kg
	}

	/**
	 * Inits the diameter and biomass of the compartment.
	 */
	public void init(HetTree tree) {

		HetSpecies sp = tree.getSpecies();
		
		if (getType().equals(TYPE_LEAF)) {
			diameter = 0;
			if (name.equals(LEAVES_UPPER_CURRENT)) {
				biomass = tree.getLeafBiomass_kgC() * sp.UFLB;
			} else if (name.equals(LEAVES_LOWER_CURRENT)) {
				biomass = tree.getLeafBiomass_kgC() * (1 - sp.UFLB);
			} else if (name.equals(LEAVES_UPPER_OLD)) {
				biomass = 0; // conifers: LATER
			} else if (name.equals(LEAVES_LOWER_OLD)) {
				biomass = 0; // conifers: LATER
			}
			livingFraction = 1;

		} else if (getType().equals(TYPE_BRANCH)) {

//			if (diameter == 0) {
//				System.out.println("HetTreeCompartment, TYPE_BRANCH, found a diameter 0, tc: "+this);
//				System.exit (-1);
//			}

			double branchBiomass = tree.getBranchBiomass_kgC();
			double smallBiomass = sp.smallBranchFracFunction.result(branchBiomass) * branchBiomass;
			double coarseBiomass = sp.coarseBranchFracFunction.result(branchBiomass) * branchBiomass;
			double mediumBiomass = 0;

			// fc+mj-9.5.2016 modified to convert coarse branch biomass into
			// medium branch biomass when medium branch biomass equals 0
			if (coarseBiomass + smallBiomass >= branchBiomass) {
				double coarseFraction = coarseBiomass / (coarseBiomass + smallBiomass);
				double smallFraction = smallBiomass / (coarseBiomass + smallBiomass);
				coarseBiomass = 0;
				mediumBiomass = branchBiomass * coarseFraction;
				smallBiomass = branchBiomass * smallFraction;
			} else {
				mediumBiomass = branchBiomass - smallBiomass - coarseBiomass;
			}

			if (name.equals(BRANCHES_SMALL)) {
				biomass = smallBiomass;
				diameter = 2; // cm
			} else if (name.equals(BRANCHES_MEDIUM)) {
				biomass = mediumBiomass;
				diameter = 5.5;
			} else if (name.equals(BRANCHES_COARSE)) {
				biomass = coarseBiomass;
				diameter = (7 + tree.getDbh() / 2) / 2d;
			}

			double sectionArea = diameter / 2d * diameter / 2d * Math.PI;
			livingFraction = tree.getSapwoodArea(this) / sectionArea;

		} else if (getType().equals(TYPE_ROOT)) {

			double rootBiomass = tree.getRootBiomass_kgC();
			double smallBiomass = sp.smallRootFracFunction.result(rootBiomass) * rootBiomass;
			double coarseBiomass = sp.coarseRootFracFunction.result(rootBiomass) * rootBiomass;
			double mediumBiomass = 0;

			// fc+mj-9.5.2016 modified to convert coarse root biomass into
			// medium root biomass when medium root biomass equals 0
			if (coarseBiomass + smallBiomass >= rootBiomass) {
				double coarseFraction = coarseBiomass / (coarseBiomass + smallBiomass);
				double smallFraction = smallBiomass / (coarseBiomass + smallBiomass);
				coarseBiomass = 0;
				mediumBiomass = rootBiomass * coarseFraction;
				smallBiomass = rootBiomass * smallFraction;
			} else {
				mediumBiomass = rootBiomass - smallBiomass - coarseBiomass;
			}

			if (name.equals(ROOTS_SMALL)) {
				biomass = smallBiomass;
				diameter = 2; // cm
			} else if (name.equals(ROOTS_MEDIUM)) {
				biomass = mediumBiomass;
				diameter = 5.5;
			} else if (name.equals(ROOTS_COARSE)) {
				biomass = coarseBiomass;
				diameter = (7 + tree.getDbh() / 2) / 2d; // to be reviewed
															// LATER//
			} else if (name.equals(ROOTS_FINE)) {
				biomass = tree.getFineRootBiomass_kgC();
				diameter = tree.getFineRootDiameter();
			}

			double sectionArea = diameter / 2d * diameter / 2d * Math.PI;
			livingFraction = tree.getSapwoodArea(this) / sectionArea;

		} else if (getType().equals(TYPE_STEM)) {

			biomass = tree.getStemBiomass_kgC();
			diameter = tree.getStemCylinderDiameter();

			double sectionArea = diameter / 2d * diameter / 2d * Math.PI;
			livingFraction = tree.getSapwoodArea(this) / sectionArea;

		} else if (getType().equals(TYPE_MYCORRHIZAE)) {

			biomass = tree.getMycorrhizaeBiomass_kgC();
			diameter = sp.hyphaDiameter / 10000;
			livingFraction = 1;
		}

	}

	public double getBiomassProduction(HetTree refTree, HetTree newTree) {

		HetSpecies sp = newTree.getSpecies();

		if (getType().equals(TYPE_LEAF)) {

			if (name.equals(LEAVES_UPPER_CURRENT)) {
				return newTree.getLeafBiomassProduction_kgC() * sp.UFLB;
			} else if (name.equals(LEAVES_LOWER_CURRENT)) {
				return newTree.getLeafBiomassProduction_kgC() * (1 - sp.UFLB);
			} else if (name.equals(LEAVES_UPPER_OLD)) {
				return 0; // conifers: LATER
			} else if (name.equals(LEAVES_LOWER_OLD)) {
				return 0; // conifers: LATER
			}

		} else if (getType().equals(TYPE_BRANCH)) {

			double branchBiomassProduction = newTree.getBranchAllocationCoefficient()
					* newTree.getTotalStructuralBiomassToAllocate_kgC();

			// Branch biomass computation considering that
			// branchRelativeLossRate is constant across branch categories
			double branchBiomass = refTree.getBranchBiomass_kgC();
			double smallBiomassProduction = sp.smallBranchFracFunction.result(branchBiomass) * branchBiomassProduction;
			double coarseBiomassProduction = sp.coarseBranchFracFunction.result(branchBiomass)
					* branchBiomassProduction;
			double mediumBiomassProduction = 0;

			// fc+mj-10.5.2016 modified to convert coarse branch biomass
			// production into medium branch biomass production when medium
			// branch biomass production equals 0
			if (coarseBiomassProduction + smallBiomassProduction > 0) {
				if (coarseBiomassProduction + smallBiomassProduction >= branchBiomassProduction) {
					double coarseFraction = coarseBiomassProduction
							/ (coarseBiomassProduction + smallBiomassProduction);
					double smallFraction = smallBiomassProduction / (coarseBiomassProduction + smallBiomassProduction);
					coarseBiomassProduction = 0;
					mediumBiomassProduction = branchBiomassProduction * coarseFraction;
					smallBiomassProduction = branchBiomassProduction * smallFraction;
				} else {
					mediumBiomassProduction = branchBiomassProduction - smallBiomassProduction
							- coarseBiomassProduction;
				}
			}

			if (Double.isNaN(smallBiomassProduction)) {
				HetReporter.printInLog("HetTreeCompartment.getBiomassProduction () smallBiomassProduction: *NaN* branchBiomass: "
						+ branchBiomass + " branchBiomassProduction: " + branchBiomassProduction
						+ " BranchAllocationCoefficient: " + newTree.getBranchAllocationCoefficient()
						+ " TotalStructuralBiomassToAllocate_kgC: " + newTree.getTotalStructuralBiomassToAllocate_kgC()
						+ " sp.smallBranchFracFunction.result(branchBiomass): "
						+ sp.smallBranchFracFunction.result(branchBiomass));
			}

			if (name.equals(BRANCHES_SMALL)) {
				return smallBiomassProduction;
			} else if (name.equals(BRANCHES_MEDIUM)) {
				return mediumBiomassProduction;
			} else if (name.equals(BRANCHES_COARSE)) {
				return coarseBiomassProduction;
			}

		} else if (getType().equals(TYPE_ROOT)) {

			double rootBiomassProduction = newTree.getRootAllocationCoefficient()
					* newTree.getTotalStructuralBiomassToAllocate_kgC();

			double rootBiomass = refTree.getRootBiomass_kgC();
			double smallBiomassProduction = sp.smallRootFracFunction.result(rootBiomass) * rootBiomassProduction;
			double coarseBiomassProduction = sp.coarseRootFracFunction.result(rootBiomass) * rootBiomassProduction;
			double mediumBiomassProduction = 0;

			// fc+mj-10.5.2016 modified to convert coarse root biomass
			// production into medium root biomass production when medium root
			// biomass production equals 0
			if (coarseBiomassProduction + smallBiomassProduction > 0) {
				if (coarseBiomassProduction + smallBiomassProduction >= rootBiomassProduction) {
					double coarseFraction = coarseBiomassProduction
							/ (coarseBiomassProduction + smallBiomassProduction);
					double smallFraction = smallBiomassProduction / (coarseBiomassProduction + smallBiomassProduction);
					coarseBiomassProduction = 0;
					mediumBiomassProduction = rootBiomassProduction * coarseFraction;
					smallBiomassProduction = rootBiomassProduction * smallFraction;
				} else {
					mediumBiomassProduction = rootBiomassProduction - smallBiomassProduction - coarseBiomassProduction;
				}
			}

			if (name.equals(ROOTS_SMALL)) {
				return smallBiomassProduction;
			} else if (name.equals(ROOTS_MEDIUM)) {
				return mediumBiomassProduction;
			} else if (name.equals(ROOTS_COARSE)) {
				return coarseBiomassProduction;
			} else if (name.equals(ROOTS_FINE)) {
				return newTree.getFineRootBiomassProduction_kgC();
			}

		} else if (getType().equals(TYPE_STEM)) {

			if (Double.isNaN(newTree.getStemAllocationCoefficient())
					|| Double.isNaN(newTree.getTotalStructuralBiomassToAllocate_kgC())) {
				HetReporter.printInLog("HetTreeCompartment.getBiomassProduction () TYPE_STEM *NaN* StemAllocationCoefficient: "
						+ newTree.getStemAllocationCoefficient() + " TotalStructuralBiomassToAllocate_kgC: "
						+ newTree.getTotalStructuralBiomassToAllocate_kgC());
			}

			return newTree.getStemAllocationCoefficient() * newTree.getTotalStructuralBiomassToAllocate_kgC();

		} else if (getType().equals(TYPE_MYCORRHIZAE)) {

			return newTree.getMycorrhizaeBiomassProduction_kgC();

		}
		return 0; // never happens
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public double getBiomass() {
		return biomass;
	}

	public double getLivingFraction() {
		return livingFraction;
	}

	public void setConcentration(String eName, double concentration) {
		concentrations.setValue(eName, concentration);
	}

	/**
	 * Returns the concentration for the given element name or null if the
	 * element is not in the ElementState
	 */
	public Double getConcentration(String eName) {
		return concentrations.getValue(eName);
	}

	public HetElementState getConcentrations() { // fc-22.9.2016
		return concentrations;
	}

	public String getType() {
		if (name.startsWith("LEAVES"))
			return TYPE_LEAF;
		else if (name.startsWith("BRANCHES"))
			return TYPE_BRANCH;
		else if (name.startsWith("ROOTS"))
			return TYPE_ROOT;
		else if (name.startsWith("STEM"))
			return TYPE_STEM;
		else if (name.startsWith("MYCORRHIZAE"))
			return TYPE_MYCORRHIZAE;
		else
			return "UNKNOWN_TYPE";
	}

	static public List<String> getNames(String type) {
		return type_names.get(type);
	}

	public String getFormattedHeader(String separatorBetweenElements) {

		StringBuffer b = new StringBuffer();

		b.append(getShortName(name) + " biomass(KgC)");
		b.append(separatorBetweenElements);

		String prefix = getShortName(name) + " "; // tc.LUC...
		String suffix = "(mg/g)";
		String s = concentrations.getFormattedHeader("\t", prefix, suffix);
		b.append(s);

		return b.toString();
	}

	public String getFormattedValues(String separatorBetweenElements) {

		StringBuffer b = new StringBuffer();
		b.append("" + nf.format(biomass));

		b.append(separatorBetweenElements);
		b.append(concentrations.getFormattedValues("\t"));

		return b.toString();

	}

	/**
	 * Returns this compartments concentration or nutrient content for each
	 * element name in a formatted String. e.g. possible outputs: "C N P S Ca Mg
	 * K Na Al Mn Fe Cl Si" OR "475.16 4.21 0.09 0.14 1.49 0.21 1.06 0 0 0.44 0
	 * 0 0"
	 * 
	 * @param concentrationIfTrueElseContent
	 *            : if true, writes concentration, else writes nutrient content
	 * @param separatorBetweenElements
	 *            : to be used between each element information
	 * @param includingElementNames
	 *            : if true, each element name is written
	 * @param useShortNames
	 *            : if true, short name is written instead of element name
	 * @param includingValues
	 *            : if true, each value is written
	 * @param separatorBetweenElementNameAndValue
	 *            : if both element name and valu are written, this separator is
	 *            written between them
	 * @param replaceNullAndNaNByZero
	 *            : if true, null and NaN values are replaced by zeroes
	 * @return
	 */
	// public String getFormatedString(boolean concentrationIfTrueElseContent,
	// String separatorBetweenElements,
	// boolean includingElementNames, boolean useShortNames, boolean
	// includingValues,
	// String separatorBetweenElementNameAndValue, boolean
	// replaceNullAndNaNByZero) {
	//
	// StringBuffer b = new StringBuffer();
	// boolean first = true;
	// for (String eName : HetTreeElement.elementNames) {
	//
	// if (first)
	// first = false;
	// else
	// b.append(separatorBetweenElements);
	//
	// if (includingElementNames)
	// b.append(eName);
	//
	// if (includingElementNames && includingValues)
	// b.append(separatorBetweenElementNameAndValue);
	//
	// if (includingValues) {
	//
	// Double v = null;
	// if (concentrationIfTrueElseContent)
	// v = concentrations.getValue(eName);
	// else
	// v = getNutrientContent(eName);
	//
	// if (v == null) {
	// b.append(replaceNullAndNaNByZero ? 0 : "null");
	// } else if (v.isNaN()) {
	// b.append(replaceNullAndNaNByZero ? 0 : "NaN");
	// } else {
	// b.append(nf.format(v));
	// }
	// }
	//
	// }
	// return b.toString();
	//
	// }

	/**
	 * Returns the short name of the given element, returns the given name if
	 * not found.
	 */
	public static String getShortName(String eName) { // fc-28.9.2016
		String sn = shortNames.get(eName);
		return sn != null ? sn : eName;
	}

	
	// mj+fa-02.03.2018: commented, moved to HetInitialParameters
//	/**
//	 * Q10 value for the tree component.
//	 */
//	public double getQ10 () {
//		this.Tr
//		
//		if (getType().equals(TYPE_LEAF)) {
//			// Vose & Bolstad, 1999
//			return 2.1;
//			
//		} else if (getType().equals(TYPE_BRANCH)) {
//			// Damesin et al. 2002
//			return 2.8;
//			
//		} else if (getType().equals(TYPE_STEM)) {
//			// Damesin et al. 2002
//			return 1.7;
//			
//		} else if (getType().equals(TYPE_ROOT)) {
//			if (name.equals(ROOTS_FINE)) {
//				// Epron et al., 2001
//				return 2.2;
//			
//			} else {
//				// Idem stem
//				return 1.7;
//				
//			}
//		} else {
//			return 2.1;
//		}
//	}

	public String toString() {
		StringBuffer c = new StringBuffer();
		for (String eName : HetTreeElement.elementNames) {
			c.append(" ");
			c.append(eName);
			c.append(": ");
			Double v = concentrations.getValue(eName);
			if (v == null) {
				c.append("null");
			} else {
				c.append(nf.format(v));
			}
		}

		return name + " biomass: " + biomass + " livingFraction: " + livingFraction + " diameter: " + diameter + c;
	}

}
