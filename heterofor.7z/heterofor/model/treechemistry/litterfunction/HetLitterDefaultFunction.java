/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.treechemistry.litterfunction;

import heterofor.model.treechemistry.HetLitterCompartment;


/**
 * A concentration function for an element in a litter compartment.
 * 
 * @author M. Jonard - March 2016
 */
public class HetLitterDefaultFunction extends HetLitterFunction {

	/**
	 * Constructor.
	 */
	public HetLitterDefaultFunction(String str) throws Exception { // e.g.
																// defaultFunction
		if (!str.startsWith("defaultFunction")) {
			throw new Exception("HetLitterDefaultFunction error, string should start with \"defaultFunction\": " + str);
		}

	}

	/**
	 * Returns a concentration value for the given compartment.
	 */
	@Override
	public double getValue(HetLitterCompartment compartment) {
		return 0;
	}

	
	public String toString () {
		return "defaultFunction";
	}

}
