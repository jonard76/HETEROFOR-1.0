/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.treechemistry.litterfunction;

import heterofor.model.treechemistry.HetLitterCompartment;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A concentration function for an element in a litter compartment.
 * 
 * @author M. Jonard - March 2016
 */
public class HetLitterLogNormalFunction extends HetLitterFunction {

	private double mean;
	private double sd;

	/**
	 * Constructor.
	 */
	public HetLitterLogNormalFunction(String str) throws Exception { // e.g.
		// logNormal(0.11;0.1)
		if (!str.startsWith("logNormal(")) {
			throw new Exception("HetLitterLogNormalFunction error, string should start with \"logNormal(\": " + str);
		}
		String s = str.replace("logNormal(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		mean = Check.doubleValue(st.nextToken());
		sd = Check.doubleValue(st.nextToken());

	}

	/**
	 * Returns a concentration value for the given compartment.
	 */
	@Override
	public double getValue(HetLitterCompartment compartment) {
		return Math.pow(10, mean);
	}

	public String toString() {
		return "logNormal(" + mean + ";" + sd + ")";
	}

}
