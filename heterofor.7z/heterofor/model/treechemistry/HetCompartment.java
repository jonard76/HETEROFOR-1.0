/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.treechemistry;

import heterofor.model.HetElementState;

/**
 * HetCompartment is a tree compartment or a litter compartment in the tree
 * 
 * @author M. Jonard - December2016
 */
public interface HetCompartment {

	public String getName(); // LEAVES_UPPER_CURRENT,... MYCORRHIZAE

	public double getBiomass(); // kgC

	public HetElementState getConcentrations(); // Nutrient name ->
												// concentration (mg/g)

	/**
	 * True if the compartment is above ground.
	 */
	public boolean isAboveGround ();
	
}
