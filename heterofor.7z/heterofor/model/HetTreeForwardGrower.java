/*
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their
 * permission.
 * It can be shared by the modellers of the Capsis co-development community
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory
 * for further information about licenses in Capsis.
 */

package heterofor.model;

import heterofor.model.meteorology.HetMeteoLine;
import heterofor.model.soil.HetHorizon;
import heterofor.model.treechemistry.HetTreeCompartment;
import heterofor.model.treechemistry.HetTreeElement;

import java.util.List;
import java.util.Random;

import jeeb.lib.util.Log;

//fa 19.06.2017

/**
 * The main part of the Heterofor growth process
 *
 * @author M. Jonard - March 2016
 */
public class HetTreeForwardGrower extends HetTreeGrower {

	private HetScene refScene; // fc+fa-17.5.2017 added
	private HetTree refTree;
	private int newYear;
	private HetModel model;

	private double forcedNppToGppRatio;

	// fc+mj+fa-14.11.2017
	private HetYearlyTranspirationMemory yearlyTranspirationMemory;

	//mj+fa-04.12.2017
	private double fruitLitterFall_kgC;

	private HetTreeRadiationStatus radiationStatus;
	private double parUseEfficiency;

	private double grossPrimaryProduction_kgC;
	private double maintenanceLeafRespiration_kgC; // fc-et-al-20.1.2017
													// (yearly)

	private double maintenanceRespiration_kgC;
	private double leafRetranslocation_kgC;
	private double fineRootRetranslocation_kgC;
	private double netPrimaryProduction_kgC;
	private HetFunctionalCompartmentsProduction production;
	private double totalStructuralBiomassToAllocate_kgC;
	private double deltaAboveGroundStructuralBiomass_kgC;
	private double deltaDbh2Height; //fa-31.10.2018, variable exported by calibration script
	private double deltaG; // fa-02.11.2018
	private double deltaHeight;
	private double deltaDbh_cm;

	/**
	 * Constructor
	 * @throws Exception
	 */
	public HetTreeForwardGrower(HetInitialParameters ip, Random random, HetScene refScene, HetTree refTree,
			int newYear, HetScene newScene, HetModel model, double forcedNppToGppRatio,
			HetYearlyTranspirationMemory yearlyTranspirationMemory, double fruitLitterFall_kgC) throws Exception { // fc-22.6.2017
		// added
		// Exception

		// fc+mj-12.9.017 added forcedNppToGppRatio, used if > 0

		// fc+fa-17.5.2017 added an arg: refScene, to get vegetationPeriod if
		// fineResolution mode

		this.refScene = refScene;
		this.refTree = refTree;
		this.newYear = newYear;
		this.model = model;
		this.forcedNppToGppRatio = forcedNppToGppRatio;

		this.yearlyTranspirationMemory = yearlyTranspirationMemory;

		this.fruitLitterFall_kgC = fruitLitterFall_kgC; //mj+fa-04.12.2017

		HetSpecies sp = refTree.getSpecies();

		HetSpecies species = refTree.getSpecies();
		HetScene scene = (HetScene) refTree.getScene();

		// PHASE 1: light
		radiationStatus = new HetTreeRadiationStatus(refTree);

		// PHASE 2: from interceptedParRadiation to dbh and height increments
		// Gross primary production

		double crownLeafArea = refTree.getLeafArea();

		double sunlitLeafArea = refTree.getSunlitLeafArea(); // fc+mj-13.9.2017
		double shadedLeafArea = refTree.getShadedLeafArea(); // fc+mj-13.9.2017

		// default value -1 means unknown (castanea is optional)
		double castaneaYearlyLeafRespiration_kgC = -1;

		// fc+mj-12.9.2017 we desactivated castaneaPhotosynthesisActivated in
		// fakeGrowth
		if (ip.castaneaPhotosynthesisActivated /* && !fakeGrowth */
				&& newScene != null && newScene.getSoil() != null && ip.meteorology != null) { // fc+mj-10.3.2017
																								// added
																								// tests
																								// on
																								// soil
																								// and
																								// meteo
			// fa-31.05.2017
			// System.out.println("Castanea !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

			try {
				// grossPrimaryProduction_kgC = castaneaPhotosynthesis(ip,
				// refScene, newScene, radiationStatus);

				HetCastaneaPhotosynthesis cp = new HetCastaneaPhotosynthesis(ip, refScene, refTree, newScene, newYear,
						model, radiationStatus, sunlitLeafArea, shadedLeafArea, crownLeafArea);

				cp.run();

				grossPrimaryProduction_kgC = cp.getYearlyGPP_kgC();
				castaneaYearlyLeafRespiration_kgC = cp.getYearlyLeafRespiration_kgC();

			} catch (Exception e) {
				Log.println(Log.ERROR, "HetTreeForwardGrower.c ()", "Error in castaneaPhotosynthesis", e);
				throw new RuntimeException("HetTreeForwardGrower, error in castaneaPhotosynthesis", e); // fc-22.6.2017
			}

		} else {
			// fa-31.05.2017
			// System.out.println("PUE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

			// mj+fa-22.09.2017: commented, moved to HetInitialParameters
			// boolean pueEmpiricalMethod = true;
			if (ip.pueEmpiricalMethod) {

				// fc+lj-13.9.2017 restored revision10456
				parUseEfficiency = species.parUseEfficiencyFunction.result(radiationStatus.lightCompetitionIndex,
						radiationStatus.interceptedParRadiation, refTree.getDbh());

//				System.out.println("HetTreeForwardGrower: treeId = " + refTree.getId() + ", LCI = " + radiationStatus.lightCompetitionIndex  + ", PAR = " + radiationStatus.interceptedParRadiation);

			} else {

				// fc+mj-13.9.2017 PUE based on the shaded and sunlit leaves
				double interceptedPAR_sunlitLeaves_m2leaf = radiationStatus.interceptedDirectParRadiation
						/ sunlitLeafArea + radiationStatus.interceptedDiffuseParRadiation / crownLeafArea;

				double interceptedPAR_shadedLeaves_m2leaf = radiationStatus.interceptedDiffuseParRadiation
						/ crownLeafArea;

				parUseEfficiency = (sp.sunlitPUE * interceptedPAR_sunlitLeaves_m2leaf * sunlitLeafArea + sp.shadedPUE
						* interceptedPAR_shadedLeaves_m2leaf * shadedLeafArea) / radiationStatus.interceptedParRadiation;

			}

			if (parUseEfficiency < 0.00006)
				parUseEfficiency = 0.00006;

			if (parUseEfficiency > 0.004)
				parUseEfficiency = 0.004;

			// fc+mj+fa-14.11.2017
			double transpirationModifier = 1;
			double transpirationModifierCorrection = 1;

			if (ip.waterBalanceActivated && ip.waterBalance_treeLevelTranspiration && yearlyTranspirationMemory != null) {

				double yearlyTranspiration = yearlyTranspirationMemory.getYearlyTranspiration(refTree.getId());
				double yearlyPotentialTranspiration = yearlyTranspirationMemory.getYearlyPotentialTranspiration(refTree
						.getId());

				if (yearlyPotentialTranspiration != 0) {
					transpirationModifier = yearlyTranspiration / yearlyPotentialTranspiration;
					transpirationModifierCorrection = sp.transpirationModifierCorrection;
				}
			}

			parUseEfficiency = parUseEfficiency * transpirationModifier * transpirationModifierCorrection;

			// grossPrimaryProduction_kgC = parUseEfficiency *
			// radiationStatus.interceptedParRadiation; // kgC
			// fa-5.7.2017: corrected for vegetation length difference between
			// current year and year of last radiative balance (reference)
			grossPrimaryProduction_kgC = parUseEfficiency * radiationStatus.interceptedParRadiation
					* refScene.getNextYearVegetationPeriodLength() / refScene.getRefVegetationPeriodLength(); // kgC

			if (Double.isNaN(grossPrimaryProduction_kgC)) {
				HetReporter.printInLog("TreeForwardGrower grossPrimaryProduction_kgC: *NaN* parUseEfficiency: " + parUseEfficiency
						+ " radiationStatus.interceptedParRadiation: " + radiationStatus.interceptedParRadiation
						+ " radiationStatus.lightCompetitionIndex: " + radiationStatus.lightCompetitionIndex);
			}

		}

		// Leaf and fineRoot retranslocation
		leafRetranslocation_kgC = species.leafRetranslocationRate * species.leafRelativeLossRate
				* refTree.getLeafBiomass_kgC();
		fineRootRetranslocation_kgC = species.fineRootRetranslocationRate * species.fineRootRelativeLossRate
				* refTree.getFineRootBiomass_kgC();
		double retranslocation_kgC = leafRetranslocation_kgC + fineRootRetranslocation_kgC;

		// Net primary production
		//mj+fa - 12.02.2018
		double nppToGppRatio = refTree.getNppToGppRatio();

		if (ip.constantNppToGppRatio) {

			boolean constantNppToGppRatio2 = false;// /!\temporary, to be set in correspondence with value in HetTreeInverseGrower
			if (constantNppToGppRatio2) {

				// fc+mj-12.9.2017 management of forcedNppToGppRatio
//				double nppToGppRatio = forcedNppToGppRatio > 0 ? forcedNppToGppRatio : refTree.getNppToGppRatio();
				nppToGppRatio = forcedNppToGppRatio > 0 ? forcedNppToGppRatio : refTree.getNppToGppRatio(); //mj+fa - 12.02.2018

				netPrimaryProduction_kgC = grossPrimaryProduction_kgC * nppToGppRatio;

				if (Double.isNaN(netPrimaryProduction_kgC)) {
					HetReporter.printInLog("TreeForwardGrower netPrimaryProduction_kgC: *NaN* nppToGppRatio: " + nppToGppRatio
							+ " grossPrimaryProduction_kgC: " + grossPrimaryProduction_kgC + " retranslocation_kgC: "
							+ retranslocation_kgC);
				}

			} else {
				//fa-23.02.2018
				// To be also implemented in inverse grower
//				double nppToGppRatioModel = 0d; // fa-29.10.2018: commented
				double D_d = refTree.getMean2CrownRadius() / (refTree.getDbh()/200d);
				
				//fa-26.10.2018: commented
//				if (refTree.getSpeciesCode() == 1) // oak
////					nppToGppRatioModel = 1.46 - 0.035*D_d; // Orthogonal regression
//					nppToGppRatioModel = 0.878 - 0.01552*D_d; // fa-26.10.2018
//				else if (refTree.getSpeciesCode() == 3) // carpinus, fa-26.10.2018
//					nppToGppRatioModel = 0.667 - 0.005114*D_d;
//				else // others
////					nppToGppRatioModel = 0.62 - 0.00851*D_d; // Orthogonal regression
//					nppToGppRatioModel = refTree.getNppToGppRatio(); // fa-26.10.2018
				
				// fa-26.10.2018
				double c130 = refTree.getDbh() * Math.PI;
				double D_dIndex = D_d / species.crownToStemDiameterEstimation.result(c130);
				//fa-29.10.2018
				double nppToGppRatioModel = species.nppToGppRatio_intercept + species.nppToGppRatio_slope*D_dIndex;
//				if (refTree.getSpeciesCode() == 1) // oak
//					nppToGppRatioModel = 0.9633 - 0.3721*D_dIndex;
//				else if (refTree.getSpeciesCode() == 2) // beech
//					nppToGppRatioModel = 0.9611 - 0.3559*D_dIndex;
//				else // others
//				nppToGppRatioModel = refTree.getNppToGppRatio();
				
				// fa-03.11.2018
//				nppToGppRatioModel = Math.max(nppToGppRatioModel, 0.2);
//				nppToGppRatioModel = Math.min(nppToGppRatioModel, 0.8);
				// for model calibration
				nppToGppRatioModel = Math.max(nppToGppRatioModel, 0.05);
				nppToGppRatioModel = Math.min(nppToGppRatioModel, 0.95);
				
				netPrimaryProduction_kgC = grossPrimaryProduction_kgC * nppToGppRatioModel;
				refTree.setNppToGppRatioForNextYear(nppToGppRatioModel);
				
			}

		} else {
			// fc+mj-8.3.2017 changed maintenance respiration calculation,
			// longer, executed in this else only if needed
			// fc+mj-8.3.2017 added ip and year
			// fc+fa-31.7.2017 added castaneaYearlyLeafRespiration_kgC


			maintenanceRespiration_kgC = calculateMaintenanceRespiration_kgC2(refScene, newScene, refTree, ip, newYear,
					castaneaYearlyLeafRespiration_kgC);

			netPrimaryProduction_kgC = (grossPrimaryProduction_kgC - maintenanceRespiration_kgC - ip.compartmentGrowthRespirationFraction
					* retranslocation_kgC)
					/ (1 + ip.compartmentGrowthRespirationFraction);


			// fc+mj+fa-31.7.2017
			 netPrimaryProduction_kgC = Math.max(netPrimaryProduction_kgC,grossPrimaryProduction_kgC * 0.2);
			 netPrimaryProduction_kgC = Math.min(netPrimaryProduction_kgC,grossPrimaryProduction_kgC * 0.8);
			//mj+fa - 12.02.2018
//			 netPrimaryProduction_kgC = Math.max(netPrimaryProduction_kgC,grossPrimaryProduction_kgC * (nppToGppRatio - 0.2));
//			 netPrimaryProduction_kgC = Math.min(netPrimaryProduction_kgC,grossPrimaryProduction_kgC * (nppToGppRatio + 0.2));

			// fc+mj+fa-31.7.2017 commented
			if (netPrimaryProduction_kgC < 0) { // fc+mj-10.3.2017
				netPrimaryProduction_kgC = 0;
				// System.out.println("HetTreeForwardGrower netPrimaryProduction_kgC was forced to 0");
			}

			if (Double.isNaN(netPrimaryProduction_kgC)) {
				HetReporter.printInLog("TreeForwardGrower netPrimaryProduction_kgC: *NaN*" + " grossPrimaryProduction_kgC: "
						+ grossPrimaryProduction_kgC + " retranslocation_kgC: " + retranslocation_kgC);
			}

		}

		// Biomass increment of structural treeCompartments (1/2)
		// Leaf and fineRoot biomass Production

		double bestDeltaDbh = species.defaultDeltaDbh; // fc+mj-3.3.2016
		if (refTree.getDeltaDbh_cm() >= 0)
			bestDeltaDbh = refTree.getDeltaDbh_cm();

		// Calculation of functional compartments biomass and production
		production = new HetFunctionalCompartmentsProduction(ip, refTree, bestDeltaDbh);

		// Correction to limit functional compartments production to NPP +
		// retranslocation
		production.correction(netPrimaryProduction_kgC, retranslocation_kgC);

		//
		if (netPrimaryProduction_kgC + retranslocation_kgC - production.newLeafBiomassProduction_kgC - production.newRhizosphereBiomassProduction_kgC - fruitLitterFall_kgC < 0)
			fruitLitterFall_kgC = netPrimaryProduction_kgC + retranslocation_kgC - production.newLeafBiomassProduction_kgC - production.newRhizosphereBiomassProduction_kgC;
		refTree.setFruitLitterFall_kgC(fruitLitterFall_kgC);
		
		totalStructuralBiomassToAllocate_kgC = netPrimaryProduction_kgC + retranslocation_kgC
				- production.newLeafBiomassProduction_kgC - production.newRhizosphereBiomassProduction_kgC - fruitLitterFall_kgC;

		if (Double.isNaN(totalStructuralBiomassToAllocate_kgC)) {
			HetReporter.printInLog("TreeForwardGrower totalStructuralBiomassToAllocate_kgC: *NaN* netPrimaryProduction_kgC: "
					+ netPrimaryProduction_kgC + " retranslocation_kgC: " + retranslocation_kgC
					+ " production.newLeafBiomassProduction_kgC: " + production.newLeafBiomassProduction_kgC
					+ " production.newRhizosphereBiomassProduction_kgC: "
					+ production.newRhizosphereBiomassProduction_kgC);
		}

		// mj+fa-24.10.2018
		double rootLitterCorrectionFactor = 1.0;
		if ((totalStructuralBiomassToAllocate_kgC - refTree.getBranchLitterFall_kgC() - refTree.getRootLitterFall_kgC()) < 0)
			rootLitterCorrectionFactor = totalStructuralBiomassToAllocate_kgC / (refTree.getBranchLitterFall_kgC() + refTree.getRootLitterFall_kgC());
		refTree.setRootLitterCorrectionFactor(rootLitterCorrectionFactor);
		
		deltaAboveGroundStructuralBiomass_kgC = (totalStructuralBiomassToAllocate_kgC
				- refTree.getBranchLitterFall_kgC() - refTree.getRootLitterFall_kgC())
				/ (1 + species.rootToShootRatio);

		if (deltaAboveGroundStructuralBiomass_kgC < 0)
			deltaAboveGroundStructuralBiomass_kgC = 0;

		// Dbh and height increment
		// The allometric relationship between aboveGroundStructuralBiomass and
		// dbh_m and height has
		// the form: alpha + beta * pow(dbh_m * dbh_m * height, gamma)
		double dbh_cm = refTree.getDbh();
		double dbh_m = dbh_cm / 100d;
		double c130 = dbh_cm * Math.PI; // cm
		double lnC130 = Math.log(c130);
		double height = refTree.getHeight(); // m

		// // Temporary residual
		// double residualVariance = 0.07;
		// double standardDeviation = Math.sqrt(residualVariance);
		// // double residual = random.nextGaussian () * standardDeviation;
		// // double residual = random.nextDouble () * 0.5;
		// double residual = 0;

		// fc+mj-29.4.2015 changed height growth
		deltaHeight = 0;
		double deltaDbh_m = 0;
		deltaDbh2Height = 0; //fa-31.10.2018
		deltaG = 0; //fa-02.11.2018

		if (deltaAboveGroundStructuralBiomass_kgC > 0) {

			// mj+fc-2.3.2016 Added * 0.5 below to convert OM into C
//			double deltaDbh2Height = deltaAboveGroundStructuralBiomass_kgC
//					/ (species.aboveBiomassBeta * 0.5 * species.aboveBiomassGamma * Math.pow(dbh_m * dbh_m * height,
//							species.aboveBiomassGamma - 1d));
			// fa-31.10.2018
			deltaDbh2Height = deltaAboveGroundStructuralBiomass_kgC
					/ (species.aboveBiomassBeta * 0.5 * species.aboveBiomassGamma * Math.pow(dbh_m * dbh_m * height,
							species.aboveBiomassGamma - 1d));

			double heightModifier = 1;
			if (refTree.getHeight() > 30)
				heightModifier = Math.exp(-0.5 * (refTree.getHeight() - 30));

			if (ip.heightGrowthOption.equals(HetInitialParameters.IPRFW)) {

				// mj+fc-6.12.2016 height increment decreased exponentially
				// beyond 30m
				deltaHeight = species.iprfwHeightGrowthFunction.result(refTree, scene, deltaDbh2Height,
						radiationStatus.lightCompetitionIndex, random) * heightModifier;

			} else if (ip.heightGrowthOption.equals(HetInitialParameters.BAILEUX_SITE)) {

				// mj+fc-6.12.2016 height increment decreased exponentially
				// beyond 30m
				deltaHeight = species.baileuxHeightGrowthFunction.result(refTree, scene, deltaDbh2Height,
						radiationStatus.lightCompetitionIndex, random) * heightModifier;

			} else if (ip.heightGrowthOption.equals(HetInitialParameters.POTENTIAL_MODIFIERS_HEIGHT_GROWTH)) {

				// fc+mj-6.12.2016
				deltaHeight = species.potentialModifiersHeightGrowth.result(refTree, scene, deltaDbh2Height,
						radiationStatus.lightCompetitionIndex, random) * heightModifier;

			}

			if (Double.isNaN(deltaHeight))
				HetReporter.printInStandardOutput("");

			// deltaDbh_m = (deltaDbh2Height - (dbh_m * dbh_m * deltaHeight)) /
			// (2 * height * dbh_m);

			deltaDbh_m = Math
					.sqrt((deltaDbh2Height - (dbh_m * dbh_m * deltaHeight) + (dbh_m * dbh_m * (height + deltaHeight)))
							/ (height + deltaHeight))
					- dbh_m;// MJ 28.06.2016

			 if (refTree.getSpecies().getName() == "quercus")
			 deltaDbh_m = Math.min(deltaDbh_m, 0.007);//mj+fa-06.10.2017
			 else
			 deltaDbh_m = Math.min(deltaDbh_m, 0.010);// MJ 28.06.2016
			
			// fa-02.11.2018
			double newDbh_m = dbh_m + deltaDbh_m;
			deltaG = (newDbh_m * newDbh_m * Math.PI / 4) - (dbh_m * dbh_m  * Math.PI / 4);

		}

		deltaDbh_cm = deltaDbh_m * 100;

	}

	/**
	 * Calculates the maintenance respiration for the given tree.
	 * castaneaYearlyLeafRespiration_kgC is optional, used if not -1.
	 * @throws Exception
	 */
	// mj+fa-05.03.2018
	static public double calculateMaintenanceRespiration_kgC2(HetScene refScene, HetScene newScene, HetTree refTree,
			HetInitialParameters ip, int year, double castaneaYearlyLeafRespiration_kgC) throws Exception { // Optimized implementation

		double maintenanceRespiration_kgC = 0;

		for (HetTreeCompartment tc : refTree.getTreeCompartments()) {
			//mj+fa-22.11.2017: commented
//			if (castaneaYearlyLeafRespiration_kgC != -1 && tc.getType().equals(HetTreeCompartment.TYPE_LEAF))
//				continue;

			double tcMaintenanceRespiration = 0.0;

			double livingBiomass = tc.getLivingFraction() * tc.getBiomass(); // kgC

			// mg/g = g/kg
			double CConcentration = tc.getConcentration(HetTreeElement.C); // mg/g
			double NConcentration = tc.getConcentration(HetTreeElement.N); // mg/g

			HetTreeCompartment mediumBranchesCompartment = null;
			for (HetTreeCompartment treeCompartment : refTree.getTreeCompartments()){
				if (treeCompartment.name.equals(HetTreeCompartment.BRANCHES_MEDIUM))
					mediumBranchesCompartment = treeCompartment;
			}
			double NConcentrationMediumBranches = ip.treeChemistryDistribution.getConcentration(refTree.getSpecies().getName(), mediumBranchesCompartment, HetTreeElement.N);

			if (refTree.getSpecies().getName().equals("quercus"))
				NConcentration = Math.max(NConcentration, NConcentrationMediumBranches);

			if (tc.getType().equals(HetTreeCompartment.TYPE_LEAF)) {

					// 12/1000: C molar mass (g) / 1000: converting g -> kg
				tcMaintenanceRespiration += 12d / 1000d * livingBiomass
						* refTree.getSpecies().referenceMaintenanceRespiration * NConcentration
						/ (CConcentration / 1000d) * newScene.getQ10SumMapLeaf().get(refTree.getSpecies().getId());

			} else if (tc.getName().equals(HetTreeCompartment.ROOTS_FINE)) {

					// 12/1000: C molar mass (g) / 1000: converting g -> kg
				tcMaintenanceRespiration += 12d / 1000d * livingBiomass
						* refTree.getSpecies().referenceMaintenanceRespiration * NConcentration
						/ (CConcentration / 1000d) * newScene.getQ10SumMapFineRoot().get(refTree.getSpecies().getId());

			} else {

					// 12/1000: C molar mass (g) / 1000: converting g -> kg
				tcMaintenanceRespiration = 12d / 1000d * livingBiomass
						* refTree.getSpecies().referenceMaintenanceRespiration * NConcentration
						/ (CConcentration / 1000d) * newScene.getQ10SumMap().get(tc.getType());
			}

			maintenanceRespiration_kgC += tcMaintenanceRespiration;

		}

		//mj+fa-22.11.2017: commented
//		if (castaneaYearlyLeafRespiration_kgC != -1)
//			maintenanceRespiration_kgC += castaneaYearlyLeafRespiration_kgC;

		return maintenanceRespiration_kgC;
	}

	/**
	 * Calculates the maintenance respiration for the given tree.
	 * castaneaYearlyLeafRespiration_kgC is optional, used if not -1.
	 * @throws Exception
	 */
	static public double calculateMaintenanceRespiration_kgC(HetScene refScene, HetScene newScene, HetTree refTree,
			HetInitialParameters ip, int year, double castaneaYearlyLeafRespiration_kgC) throws Exception { // Original implementation

		// fc+mj-8.3.2017
		List<HetMeteoLine> lines = ip.meteorology.getMeteoLines(year);

		double maintenanceRespiration_kgC = 0;

		for (HetMeteoLine line : lines) {

			for (HetTreeCompartment tc : refTree.getTreeCompartments()) {

				double exponent = 0.0;
				double temperatureDependency = 0.0;
				double hourlyTCMaintenanceRespiration = 0.0;

				// fc+mj+fa-31.7.2017 introduced
				// castaneaYearlyLeafRespiration_kgC
				//mj+fa-22.11.2017: commented
//				if (castaneaYearlyLeafRespiration_kgC != -1 && tc.getType().equals(HetTreeCompartment.TYPE_LEAF))
//					continue;

				double livingBiomass = tc.getLivingFraction() * tc.getBiomass(); // kgC

				// fc+mj+fa-31.7.2017
				if (tc.getType().equals(HetTreeCompartment.TYPE_LEAF)
						|| tc.getName().equals(HetTreeCompartment.ROOTS_FINE)) {

					double ladProp = 1d;
					double greenProp = 1d;

					if (ip.phenologyActivated) {
						ladProp = refScene.getLadProportionOfNextYear(refTree.getSpeciesCode(), line.getDoy());
						greenProp = refScene.getGreenProportionOfNextYear(refTree.getSpeciesCode(), line.getDoy());
					}
					livingBiomass *= greenProp;
				}

				// mg/g = g/kg
				double CConcentration = tc.getConcentration(HetTreeElement.C); // mg/g
				double NConcentration = tc.getConcentration(HetTreeElement.N); // mg/g

//				//mj+fa-13.12.2017
//				int mediumBranchesCompartmentIndex = refTree.getTreeCompartments().indexOf(HetTreeCompartment.BRANCHES_MEDIUM);
//				HetTreeCompartment mediumBranchesCompartment = refTree.getTreeCompartments().get(mediumBranchesCompartmentIndex);
				HetTreeCompartment mediumBranchesCompartment = null;
				for (HetTreeCompartment treeCompartment : refTree.getTreeCompartments()){
					if (treeCompartment.name.equals(HetTreeCompartment.BRANCHES_MEDIUM))
						mediumBranchesCompartment = treeCompartment;
				}
				double NConcentrationMediumBranches = ip.treeChemistryDistribution.getConcentration(refTree.getSpecies().getName(), mediumBranchesCompartment, HetTreeElement.N);

				if (refTree.getSpecies().getName().equals("quercus"))
				NConcentration = Math.max(NConcentration, NConcentrationMediumBranches);

//				double Q10 = tc.getQ10(); //mj+fa-02.03.2018: commented

				double lightInihibition = 1d; // no inhibition

				// Leaves + during daylight: special case // fc+mj-9.3.2017
				if (tc.getType().equals(HetTreeCompartment.TYPE_LEAF) && line.radiation > 0) {
					// For deciduous species only, to be reviewed for evergreen
					// trees: 1 - 0.51
					lightInihibition = 1d - 0.62;
				}

				if (tc.getType().equals(HetTreeCompartment.TYPE_ROOT)) {

					// Loop on horizons
					for (HetHorizon horizon : newScene.getSoil().getHorizons()) {

//						livingBiomass *= horizon.fineRootProportion;
						double horizonLivingBiomass = livingBiomass * horizon.fineRootProportion; //fa-05.03.2018

						// Reference temperature (15 degC) from Damesin et al.,
						// 2002
						String time = line.year + "_" + line.month + "_" + line.day + "_" + line.hour;

						double horizonTemperature;

						// fc+mj-12.9.2017 calculateMaintenanceRespiration_kgC
						// is not called
						// any more in fakeGrowth mode
						// // For fakeGrowth the temperature in soil horizons is
						// not yet calculated.
						// if (fakeGrowth) {
						// horizonTemperature = line.airTemperature;
						// } else {

						if (!horizon.isOrganic()) { // mineral horizon
							// System.out.println("calculateMaintenanceRespiration_kgC: TimeMineralHorizonTemperatureMap = "
							// + horizon.getTimeMineralHorizonTemperatureMap() +
							// ", time =" + time);
							horizonTemperature = horizon.getTimeMineralHorizonTemperatureMap().get(time);
						} else { // organic horizon
							horizonTemperature = (line.airTemperature + newScene.getSoil()
									.getSoilInterfaceTemperatureMap().get(time)) / 2.0;
						}

						// }

						exponent = (horizonTemperature - 15d) / 10d;
//						temperatureDependency = Math.pow(Q10, exponent);
						if (tc.getName().equals(HetTreeCompartment.ROOTS_FINE)) {
							temperatureDependency = Math.pow(ip.q10Map.get(HetTreeCompartment.TYPE_LEAF), exponent); // mj+fa-05.03.2018
						}else
							temperatureDependency = Math.pow(ip.q10Map.get(tc.getType()), exponent); // mj+fa-02.03.2018

						// 12/1000: C molar mass (g) / 1000: converting g -> kg
//						hourlyTCMaintenanceRespiration += 12d / 1000d * livingBiomass
//								* refTree.getSpecies().referenceMaintenanceRespiration * NConcentration
//								/ (CConcentration / 1000d) * temperatureDependency * lightInihibition;
						//fa-05.03.2018
						hourlyTCMaintenanceRespiration += 12d / 1000d * horizonLivingBiomass
								* refTree.getSpecies().referenceMaintenanceRespiration * NConcentration
								/ (CConcentration / 1000d) * temperatureDependency * lightInihibition;
					}
				} else {
					// Reference temperature (15 degC) from Damesin et al., 2002
					exponent = (line.airTemperature - 15d) / 10d;
//					temperatureDependency = Math.pow(Q10, exponent);
					temperatureDependency = Math.pow(ip.q10Map.get(tc.getType()), exponent); // mj+fa-02.03.2018

					// 12/1000: C molar mass (g) / 1000: converting g -> kg
					hourlyTCMaintenanceRespiration = 12d / 1000d * livingBiomass
							* refTree.getSpecies().referenceMaintenanceRespiration * NConcentration
							/ (CConcentration / 1000d) * temperatureDependency * lightInihibition;
				}

				/*
				 * if (Double.isNaN(hourlyTCMaintenanceRespiration) ||
				 * Double.isInfinite(hourlyTCMaintenanceRespiration)) {
				 * System.out.println(
				 * "\n*** HetTreeForwardGrower error, houlyTCMaintenanceRespiration: "
				 * + hourlyTCMaintenanceRespiration + " ***");
				 * System.out.println("\ntree species sapwoodarea function: " +
				 * refTree.getSpecies().sapwoodArea.getClass().getName());
				 * System.out.println("-> tree: " + refTree.getId() + " tc: " +
				 * tc + "\ntc.getLivingFraction(): " + tc.getLivingFraction() +
				 * " tc.getBiomass(): " + tc.getBiomass() + " NConcentration: "
				 * + NConcentration + " Q10: " + Q10 + " line.airTemperature: "
				 * + line.airTemperature + " exponent: " + exponent +
				 * " temperatureDependency: " + temperatureDependency + "\n"); }
				 */

				maintenanceRespiration_kgC += hourlyTCMaintenanceRespiration;

			}

		}
		//mj+fa-22.11.2017: commented
//		if (castaneaYearlyLeafRespiration_kgC != -1)
//			maintenanceRespiration_kgC += castaneaYearlyLeafRespiration_kgC;

		// OLD METHOD, replaced by fc+mj-8.3.2017
		/*
		 * HetSpecies species = tree.getSpecies(); double dbh = tree.getDbh();
		 * double height = tree.getHeight();
		 *
		 * double leafLivingFraction = 1; double branchLivingFraction =
		 * species.branchLivingFraction;
		 *
		 * double hdel = HetTree.getHDelevoy(species, dbh, height);
		 *
		 * double pastDbh = tree.getPastDbh(species.sapwoodYearNumber);
		 *
		 * double stemLivingFraction = 1; if (pastDbh > 0) { stemLivingFraction
		 * = (species.stemFormFactor * species.stemVolumetricMass * (dbh * dbh *
		 * hdel - (pastDbh pastDbh * hdel))) / (species.stemFormFactor *
		 * species.stemVolumetricMass * dbh * dbh * hdel); }
		 *
		 * double rootLivingFraction = species.rootLivingFraction; double
		 * fineRootLivingFraction = 1;
		 *
		 * double q10 = 2.2; // Piao et al., 2010 double currentTemperature = 8;
		 * // deg C double referenceTemperature = 25; // deg C
		 *
		 * // Sum the maintenance respiration for all treeCompartments double
		 * maintenanceRespiration_kgC =
		 * tree.getMaintenanceRespiration(species.specificRespirationRate,
		 * tree.getLeafBiomass_kgC(), leafLivingFraction,
		 * species.leafNConcentration, q10, currentTemperature,
		 * referenceTemperature); maintenanceRespiration_kgC +=
		 * tree.getMaintenanceRespiration(species.specificRespirationRate,
		 * tree.getBranchBiomass_kgC(), branchLivingFraction,
		 * species.branchNConcentration, q10, currentTemperature,
		 * referenceTemperature); maintenanceRespiration_kgC +=
		 * tree.getMaintenanceRespiration(species.specificRespirationRate,
		 * tree.getStemBiomass_kgC(), stemLivingFraction,
		 * species.stemNConcentration, q10, currentTemperature,
		 * referenceTemperature); maintenanceRespiration_kgC +=
		 * tree.getMaintenanceRespiration(species.specificRespirationRate,
		 * tree.getRootBiomass_kgC(), rootLivingFraction,
		 * species.rootNConcentration, q10, currentTemperature,
		 * referenceTemperature); maintenanceRespiration_kgC +=
		 * tree.getMaintenanceRespiration(species.specificRespirationRate,
		 * tree.getFineRootBiomass_kgC(), fineRootLivingFraction,
		 * species.fineRootNConcentration, q10, currentTemperature,
		 * referenceTemperature);
		 */

		return maintenanceRespiration_kgC;
	}

	public HetTree getTree() {
		return refTree;
	}

	public HetTreeRadiationStatus getRadiationStatus() {
		return radiationStatus;
	}

	public double getParUseEfficiency() {
		return parUseEfficiency;
	}

	public double getGrossPrimaryProduction_kgC() {
		return grossPrimaryProduction_kgC;
	}

	public double getMaintenanceLeafRespiration_kgC() {
		return maintenanceLeafRespiration_kgC;
	}

	public double getMaintenanceRespiration_kgC() {
		return maintenanceRespiration_kgC;
	}

	public double getLeafRetranslocation_kgC() {
		return leafRetranslocation_kgC;
	}

	public double getFineRootRetranslocation_kgC() {
		return fineRootRetranslocation_kgC;
	}

	public double getNetPrimaryProduction_kgC() {
		return netPrimaryProduction_kgC;
	}

	public HetFunctionalCompartmentsProduction getProduction() {
		return production;
	}

	public double getTotalStructuralBiomassToAllocate_kgC() {
		return totalStructuralBiomassToAllocate_kgC;
	}

	public double getDeltaAboveGroundStructuralBiomass_kgC() {
		return deltaAboveGroundStructuralBiomass_kgC;
	}
	
	// fa-31.10.2018
	public double getDeltaDbh2Height() {
		return deltaDbh2Height;
	}
	
	// fa-02.11.2018
	public double getDeltaG() {
		return deltaG;
	}
	
	public double getDeltaHeight() {
		return deltaHeight;
	}

	public double getDeltaDbh_cm() {
		return deltaDbh_cm;
	}

	public HetYearlyTranspirationMemory getYearlyTranspirationMemory() {
		return yearlyTranspirationMemory;
	}

}
