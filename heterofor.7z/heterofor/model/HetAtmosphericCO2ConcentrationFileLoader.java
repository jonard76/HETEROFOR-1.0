/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model;

import java.util.List;

import jeeb.lib.util.Record;
import jeeb.lib.util.fileloader.FileLoader;

/**
 * A file loader for the atmospheric CO2 concentrations file.
 * 
 * @author N. Beudez - March 2018
 *
 */
public class HetAtmosphericCO2ConcentrationFileLoader extends FileLoader {

	public List<AtmosphericCO2ConcentrationRecord> atmCO2ConcRecords;

	/**
	 * Constructor.
	 * @throws Exception
	 */
	public HetAtmosphericCO2ConcentrationFileLoader() throws Exception {
		super();
	}

	@Override
	protected void checks() throws Exception {
		// TODO FP Auto-generated method stub		
	}

	// A line in the atmospheric CO2 concentrations file.
	static public class AtmosphericCO2ConcentrationRecord extends Record {

		public int year;
		public double atmCO2Concentration;

		public AtmosphericCO2ConcentrationRecord(String line) throws Exception {
			super(line);
		}
	}
}
