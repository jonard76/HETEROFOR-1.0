/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model;

import jeeb.lib.util.RGB;
import jeeb.lib.util.Vertex3d;
import jeeb.lib.util.heightmap.HeightMap;
import capsis.defaulttype.plotofcells.SquareCell;
import capsis.lib.samsaralight.SLTargetLightResult;
import capsis.lib.regeneration.RGCell;
import capsis.lib.samsaralight.SLLightableTarget;

/**
 * A ground cell in heterofor...
 * 
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetCell extends RGCell implements SLLightableTarget, RGB {

	// private static Random random = new Random ();

	private SLTargetLightResult lightResult;
	private int[] rgb; // an optional color for the cell

	private double massLeafLitter_ha; // kgC / ha
	private double massBranchLitter_ha; // kgC / ha
	private double massRootLitter_ha; // kgC / ha
	private double massFineRootLitter_ha; // kgC / ha
	private double massSlowDecompositionPool_ha; // kgC / ha

	// this cell can have specific properties: horizons...

	/**
	 * Constructor signature modified the 17-05-2013 in order to compute z, GL
	 */
	public HetCell(HetPlot plot, int iGrid, int jGrid, double x, double y) {

		super(plot, plot.getId(iGrid, jGrid), 		
				new Vertex3d(x, y, HetModel.getZCoordinate(x, y,
				Math.toRadians(plot.getSlope_deg()), 
				Math.toRadians(plot.getAspect_deg()))), iGrid, jGrid);

		lightResult = new SLTargetLightResult(this);
	}

	@Override
	public Object clone() {

		HetCell copy = (HetCell) super.clone();

		// fc-9.5.2017 fixed a bug in radiative balance
		copy.lightResult = new SLTargetLightResult(copy);

		return copy;
	}

	public SLTargetLightResult getLightResult() {
		return lightResult;
	}

	public void setLightResult(SLTargetLightResult c) {
		lightResult = c;
	}

	/**
	 * This cal be called once a heightMap is available to recalculate all z
	 * values in the cell.
	 */
	public void updateZs(HeightMap hm) { // fc-14.6.2013
		getImmutable().origin.z = hm.getZ(getImmutable().origin.x, getImmutable().origin.y);
		getImmutable().center.z = hm.getZ(getImmutable().center.x, getImmutable().center.y);
		for (Vertex3d v : getVertices()) {
			v.z = hm.getZ(v.x, v.y);
		}

	}

	/**
	 * Returns the color of this object.
	 */
	public int[] getRGB() {
		return rgb;
		// return new int[] {random.nextInt (256), random.nextInt (256),
		// random.nextInt (256)};
	}

	/**
	 * Sets the color for this object.
	 */
	public void setRGB(int[] v) {
		this.rgb = v;
	}

	public double getMassLeafLitter_ha() {
		return massLeafLitter_ha;
	}

	public void setMassLeafLitter_ha(double leafLitterMass_ha) {
		this.massLeafLitter_ha = leafLitterMass_ha;
	}

	public double getMassBranchLitter_ha() {
		return massBranchLitter_ha;
	}

	public void setMassBranchLitter_ha(double branchLitterMass_ha) {
		this.massBranchLitter_ha = branchLitterMass_ha;
	}

	public double getMassRootLitter_ha() {
		return massRootLitter_ha;
	}

	public void setMassRootLitter_ha(double rootLitterMass_ha) {
		this.massRootLitter_ha = rootLitterMass_ha;
	}

	public double getMassFineRootLitter_ha() {
		return massFineRootLitter_ha;
	}

	public void setMassFineRootLitter_ha(double fineRootLitterMass_ha) {
		this.massFineRootLitter_ha = fineRootLitterMass_ha;
	}

	public double getMassSlowDecompositionPool_ha() {
		return massSlowDecompositionPool_ha;
	}

	public void setMassSlowDecompositionPool_ha(double slowDecompositionPoolOfOrganicMatter_ha) {
		this.massSlowDecompositionPool_ha = slowDecompositionPoolOfOrganicMatter_ha;
	}

	@Override
	public SquareCell getMatchingCell() {
		return this;
	}

	@Override
	public String toString() {
		return "HetCell_" + getPosition();
	}

	@Override
	public double getEnergy_MJ() {
		return getRemainingEnergy_MJ() >= 0 ? getRemainingEnergy_MJ() : lightResult.get_slopeEnergy() * getArea(); // MJ/m�
		// -> MJ
	}

}
