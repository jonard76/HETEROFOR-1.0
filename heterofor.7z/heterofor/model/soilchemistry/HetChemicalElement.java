/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.soilchemistry;

import java.io.Serializable;

import jeeb.lib.util.Record;

/**
 * A soil chemical element in the heterofor model.
 * 
 * @author M. Jonard - October 2015
 */
public class HetChemicalElement extends Record implements Serializable {

	public String name;
	public int charge; // positive or negative
	public double atomicMass; // g
	public double diffusionCoefficient; // m2/s
	public String treeElement; // fc+mj-12.5.2016, see HetTreeElement

	/**
	 * Constructor for record recognition.
	 */
	public HetChemicalElement() {
		super();
	}

	/**
	 * Constructor for record recognition.
	 */
	public HetChemicalElement(String line) throws Exception {
		super(line);
	}

	/**
	 * Constructor
	 */
	public HetChemicalElement(String name, int charge, double atomicMass) {
		this.name = name;
		this.charge = charge;
		this.atomicMass = atomicMass;
	}

	@Override
	public String toString() {
		return "HetChemicalElement [name: " + name + ", charge: " + charge
				+ ", atomicMass: " + atomicMass + ", diffusionCoefficient: "
						+ diffusionCoefficient + ", treeElement: "
								+ treeElement + "]";
	}

}
