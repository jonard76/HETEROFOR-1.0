/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.soilchemistry;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.soil.HetHorizon;
import heterofor.model.soil.HetSoil;

import java.util.List;
import java.util.StringTokenizer;

import jeeb.lib.util.Import;
import jeeb.lib.util.Log;
import jeeb.lib.util.Record;
import jeeb.lib.util.fileloader.FileLoader;

/**
 * A file loader for the Heterofor soil chemistry file.
 * 
 * @author F. de Coligny - October 2015 (reviewed Sep 216, soil horizons are now
 *         loaded apart)
 */
public class HetSoilChemistryFileLoader extends FileLoader {

	public List<HetChemicalElement> elementLines;
	public List<AtmosphericDepositionLine> depositionLines;

	/**
	 * Constructor
	 */
	public HetSoilChemistryFileLoader() throws Exception {
		super();

		// Needed: the complex sections will be evaluated afterwards based on
		// expected line prefixes (e.g. soilSolution...)
		// -> unrecognized lines are turned into UnknownRecords
		setMemorizeWrongLines(true);

		// addAdditionalClass(HetChemicalElement.class);
	}

	/**
	 * Loads the soil chemistry file and store the species in the given map.
	 */
	public void load(String fileName, HetInitialParameters ip,
			HetModel model, HetScene scene) throws Exception {

		// 1. Load the file
		super.load(fileName);

		// fc-6.12.2017 no more report in FileLoader
		
//		String report = super.load(fileName);

		// for (Record record : this) {
		// System.out.println("Record: " + record.getClass() + ": " + record);
		// }

		// 2. Evaluate content
		try {

			// Get the soil object
			// The soil has been created during the soilHorizons file loading.
			// If not found, an error must been sent to user

			// Create the soil object
			HetSoil soil = scene.getSoil();

			if (soil == null) {

				// In case we are called outside buildInitScene (), e.g. in
				// PUEEstimationTool
				try {
					ip.loadHorizonFile(model); // fc+mj-8.12.2016
				} catch (Exception e) {
					throw new Exception(
							"Soil chemistry file could not be loaded: please check soil horizons have been loaded correctly",
							e);
				}
			}

			// Chemical elements
			for (HetChemicalElement e : elementLines) {
				ip.chemicalElements.put(e.name, e);
			}

			// Atmospheric deposition // fc+mj+lw-6.9.2016
			for (AtmosphericDepositionLine line : depositionLines) {
				soil.getNutrientDeposition().addValue(line.treeElementName,
						line.deposition);
			}

			// Process complex sections, have been stored in UnknownRecords

			String[] elementNames = null;
			String[] cationExchNames = null;
			String[] anionExchNames = null;
			String[] mineralNames = null;

			for (Record record : this) {

				// System.out.println("-> " + record);

				if (record instanceof UnknownRecord) {

					String line = record.toString();

					if (line.startsWith("soilSolution")) {
						// Extract the column headers (i.e. chemical element
						// names)
						if (elementNames == null) {
							StringTokenizer st = new StringTokenizer(line, "\t");
							// elementNames: remove soilSolution and horizonId
							st.nextToken(); // "soilSolution"
							st.nextToken(); // "horizonId"
							int n = st.countTokens();

							// System.out.println("HetSoilFileLoader
							// soilSolution header, n: " + n);

							elementNames = new String[n];
							int i = 0;
							while (st.hasMoreTokens()) {
								String elementName = st.nextToken();

								// System.out.println("HetSoilFileLoader
								// elementName: " + elementName);

								elementNames[i] = elementName;
								i++;
							}
						} else {
							// Store solution concentrations in their horizon /
							// elementName
							StringTokenizer st = new StringTokenizer(line, "\t");
							// elementNames: remove soilSolution and horizonId
							st.nextToken(); // "soilSolution"
							int horizonId = Integer.parseInt(st.nextToken()); // horizonId

							// Store the concentrations in this horizon
							HetHorizon h = soil.getHorizon(horizonId);

							int i = 0;
							while (st.hasMoreTokens()) {
								String token = st.nextToken();
								double conc = Double.parseDouble(token);
								String eltName = elementNames[i];

								h.setSolutionConcentration(eltName, conc);
								i++;
							}

						}

					} else if (line.startsWith("cationExchangeable")) {
						// Extract the column headers (i.e. exchangeable
						// names)
						if (cationExchNames == null) {
							StringTokenizer st = new StringTokenizer(line, "\t");
							// exchNames: remove cationExchangeable and
							// horizonId
							st.nextToken(); // "cationExchangeable"
							st.nextToken(); // "horizonId"
							int n = st.countTokens();

							// System.out.println("HetSoilFileLoader
							// cationExchNames header, n: " + n);

							cationExchNames = new String[n];
							int i = 0;
							while (st.hasMoreTokens()) {
								String exchName = st.nextToken();

								// System.out.println("HetSoilFileLoader
								// cationExchName: " + exchName);

								cationExchNames[i] = exchName;
								i++;
							}
						} else {
							// Store cationExchConcentrations in their horizon /
							// exchName
							StringTokenizer st = new StringTokenizer(line, "\t");
							// exchNames: remove cationExchangeable and
							// horizonId
							st.nextToken(); // "cationExchangeable"
							int horizonId = Integer.parseInt(st.nextToken()); // horizonId

							// Store the concentrations in this horizon
							HetHorizon h = soil.getHorizon(horizonId);

							int i = 0;
							while (st.hasMoreTokens()) {
								String token = st.nextToken();
								double conc = Double.parseDouble(token);
								String exchName = cationExchNames[i];

								h.setExchCationConcentration(exchName, conc);
								i++;
							}

						}

					} else if (line.startsWith("anionExchangeable")) {
						// Extract the column headers (i.e. exchangeable
						// names)
						if (anionExchNames == null) {
							StringTokenizer st = new StringTokenizer(line, "\t");
							// exchNames: remove anionExchangeable and
							// horizonId
							st.nextToken(); // "anionExchangeable"
							st.nextToken(); // "horizonId"
							int n = st.countTokens();

							// System.out.println("HetSoilFileLoader
							// anionExchNames header, n: " + n);

							anionExchNames = new String[n];
							int i = 0;
							while (st.hasMoreTokens()) {
								String exchName = st.nextToken();

								// System.out.println("HetSoilFileLoader
								// anionExchName: " + exchName);

								anionExchNames[i] = exchName;
								i++;
							}
						} else {
							// Store anionExchConcentrations in their horizon /
							// exchName
							StringTokenizer st = new StringTokenizer(line, "\t");
							// exchNames: remove anionExchangeable and horizonId
							st.nextToken(); // "anionExchangeable"
							int horizonId = Integer.parseInt(st.nextToken()); // horizonId

							// Store the concentrations in this horizon
							HetHorizon h = soil.getHorizon(horizonId);

							int i = 0;
							while (st.hasMoreTokens()) {
								String token = st.nextToken();
								double conc = Double.parseDouble(token);
								String exchName = anionExchNames[i];

								h.setExchAnionConcentration(exchName, conc);
								i++;
							}

						}

					} else if (line.startsWith("mineral")) {
						// Extract the column headers (i.e. mineral
						// names)
						if (mineralNames == null) {
							StringTokenizer st = new StringTokenizer(line, "\t");
							// mineralNames: remove mineral and horizonId
							st.nextToken(); // "mineral"
							st.nextToken(); // "horizonId"
							int n = st.countTokens();

							mineralNames = new String[n];
							int i = 0;
							while (st.hasMoreTokens()) {
								String mineralName = st.nextToken();

								mineralNames[i] = mineralName;
								i++;
							}
						} else {
							// Store minerals in their horizon / mineralName
							StringTokenizer st = new StringTokenizer(line, "\t");
							// mineralNames: remove mineral and horizonId
							st.nextToken(); // "mineral"
							int horizonId = Integer.parseInt(st.nextToken()); // horizonId

							// Store the mineral in this horizon
							HetHorizon h = soil.getHorizon(horizonId);

							int i = 0;
							while (st.hasMoreTokens()) {
								String token = st.nextToken();
								String mineralEncodedString = token;
								String mineralName = mineralNames[i];

								h.setMineralConcentration(mineralName,
										new HetMineral(mineralName,
												mineralEncodedString));
								i++;
							}

						}
					}
				}

			}

		} catch (Exception e) {
			setSuccess (false);
			Log.println(Log.ERROR, "HetSoilChemistryFileLoader.load ()",
					"An error occurred during soil chemistry file loading", e);
			throw new Exception ("An error occurred during soil chemistry file loading: "
					+ e + ", see the Log for further information", e);
		}

//		return report;
	}

	@Override
	protected void checks() throws Exception {
		// // Each treeId must be found only once in the file
		// Set<Integer> treeIds = new HashSet<Integer> ();
		// for (Line l : lines) {
		// if (treeIds.contains(l.treeId))
		// throw new Exception
		// ("Error in file: found a treeId several times: "+l.treeId);
		// }

	}

	// An atmospheric deposition line in the file
	@Import
	static public class AtmosphericDepositionLine extends Record {

		public String treeElementName;
		public double deposition;

		public AtmosphericDepositionLine() {
			super();
		}

		public AtmosphericDepositionLine(String line) throws Exception {
			super(line);
		}

	}
}
