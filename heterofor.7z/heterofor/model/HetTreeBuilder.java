/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model;

import java.io.Serializable;

import capsis.lib.samsaralight.SLTreeLightResult;

/**
 * Builds a tree from a preliminary growth stage, by completing the biomass and
 * crown variables.
 * 
 * @author M. Jonard - March 2016
 */
public class HetTreeBuilder implements Serializable {

	private HetTree newTree;

	/**
	 * Constructor
	 */
	public HetTreeBuilder(HetTree refTree, HetTreeGrower grower) {

		newTree = new HetTree(refTree);

		// PHASE 3 : Update compartment biomasses and crown growth

		HetSpecies species = refTree.getSpecies();

		double refDbh = refTree.getDbh();
		double refDbh_m = refDbh / 100d;
		double refHeight = refTree.getHeight();
		double refHdel = HetTree.getHDelevoy(species, refDbh, refHeight);
		double refC130 = refDbh * Math.PI; // cm

		double newDbh = refTree.getDbh() + grower.getDeltaDbh_cm();
		double newDbh_m = newDbh / 100d;
		double newHeight = refTree.getHeight() + grower.getDeltaHeight();
		double newHdel = HetTree.getHDelevoy(species, newDbh, newHeight);
		double newC130 = newDbh * Math.PI; // cm

		double deltaDbh_m = grower.getDeltaDbh_cm() / 100d;

		newTree.setSpecies(species);
		newTree.setDbh(newDbh);
//		newTree.setDeltaDbh_cm(deltaDbh_m);
		newTree.setDeltaDbh_cm(grower.getDeltaDbh_cm()); // fa-02.11.2018: correction
		newTree.setHeight(newHeight);
		newTree.setCrownForm(refTree.getCrownForm());
		newTree.setSRL(refTree.getSRL());

		// fc+mj+fa-14.11.2017 tree yearly transpiration was calculated earlier
		// and passed there to be stored in newTree
		HetYearlyTranspirationMemory ytm = grower.getYearlyTranspirationMemory();
		if (ytm != null) {
			newTree.setYearlyTranspiration(ytm.getYearlyTranspiration(refTree.getId()));
			newTree.setYearlyPotentialTranspiration(ytm.getYearlyPotentialTranspiration(refTree.getId()));
		}

		// fc-22.6.2017 REMOVED, managed in HetModel.copyLight ()
		// // fc+fa-16.5.2017 Fixed a bug, refTree.treeLight was assigned to
		// // newTree, resulting in a bug in radiative balance
		// newTree.setTreeLight(refTree.getTreeLight().getCopy(newTree));
		// newTree.setTreeLight (null); // fc-22.6.2017

		// fc-23.6.2017 create a new TreeLight, needed for next
		// processLighting ()
		newTree.setLightResult(new SLTreeLightResult(newTree));

		newTree.setVirtual(refTree.isVirtual());
		newTree.setVirtualOriginalTreeId(refTree.getVirtualOriginalTreeId());
		newTree.setVirtualTreeIdsBasedOnMe(refTree.getVirtualTreeIdsBasedOnMe());

		// fc+mj-7.9.2016 In case there is no soil in the simulation, we copy
		// the tree nutrientStatusMap
		newTree.setNutrientStatusMap(refTree.getNutrientStatusMap().getCopy());

		newTree.setInterceptedParRadiation(grower.getRadiationStatus().interceptedParRadiation);
		newTree.setLightCompetitionIndex(grower.getRadiationStatus().lightCompetitionIndex);

		newTree.setParUseEfficiency(grower.getParUseEfficiency());
		newTree.setGrossPrimaryProduction_kgC(grower.getGrossPrimaryProduction_kgC());
		newTree.setMaintenanceRespiration_kgC(grower.getMaintenanceRespiration_kgC());
		newTree.setLeafRetranslocation_kgC(grower.getLeafRetranslocation_kgC());
		newTree.setFineRootRetranslocation_kgC(grower.getFineRootRetranslocation_kgC());
		newTree.setNetPrimaryProduction_kgC(grower.getNetPrimaryProduction_kgC());
		newTree.setTotalStructuralBiomassToAllocate_kgC(grower.getTotalStructuralBiomassToAllocate_kgC());
		newTree.setDeltaAboveGroundStructuralBiomass_kgC(grower.getDeltaAboveGroundStructuralBiomass_kgC());
		newTree.setDeltaDbh2Height(grower.getDeltaDbh2Height()); // fa-31.10.2018
		newTree.setDeltaG(grower.getDeltaG()); // fa-02.11.2018
		newTree.setDeltaHeight(grower.getDeltaHeight()); // fa-02.11.2018

		// fc+mj-7.12.2016 was missing
		newTree.setNppToGppRatio(grower.getNetPrimaryProduction_kgC() / grower.getGrossPrimaryProduction_kgC());

		newTree.setLeafBiomass(grower.getProduction().newLeafBiomass_kgC);
		newTree.setFineRootBiomass(grower.getProduction().newFineRootBiomass_kgC);
		newTree.setFineRootLength(grower.getProduction().newFineRootLength);
		newTree.setFineRootVolume(grower.getProduction().newFineRootVolume);
		newTree.setFineRootDiameter(grower.getProduction().newFineRootDiameter);
		newTree.setHyphaLength(grower.getProduction().newHyphaLength);
		newTree.setMycorrhizaeBiomass_kgC(grower.getProduction().newMycorrhizaeBiomass_kgC);

		newTree.setDefoliation(grower.getProduction().newDefoliation); // fc+mj-9.3.2017

		newTree.setLeafBiomassProduction_kgC(grower.getProduction().newLeafBiomassProduction_kgC);
		newTree.setFineRootBiomassProduction_kgC(grower.getProduction().newFineRootBiomassProduction_kgC);
		newTree.setMycorrhizaeBiomassProduction_kgC(grower.getProduction().newMycorrhizaeBiomassProduction_kgC);

		// mj+fc-2.3.2016 Added * 0.5 below to convert OM into C
		double deltaStemBiomass_kgC = species.stemFormFactor * species.stemVolumetricMass * 0.5
				* ((newDbh_m * newDbh_m * newHdel) - (refDbh_m * refDbh_m * refHdel));
		newTree.setStemBiomass_kgC(refTree.getStemBiomass_kgC() + deltaStemBiomass_kgC);

		// mj+fa-24.10.2018: commented, managed below
		double deltaRootBiomass_kgC = species.rootToShootRatio * grower.getDeltaAboveGroundStructuralBiomass_kgC();
//		newTree.setRootBiomass_kgC(refTree.getRootBiomass_kgC() + deltaRootBiomass_kgC);
//
//		if (grower.getDeltaAboveGroundStructuralBiomass_kgC() == 0)
//			newTree.setRootBiomass_kgC(refTree.getRootBiomass_kgC() - refTree.getRootLitterFall_kgC());

		double stemAllocationCoefficient = 0;
		double rootAllocationCoefficient = 0;
		double branchAllocationCoefficient = 0;

		if (grower.getTotalStructuralBiomassToAllocate_kgC() != 0) {
			stemAllocationCoefficient = deltaStemBiomass_kgC / grower.getTotalStructuralBiomassToAllocate_kgC();
//			rootAllocationCoefficient = (deltaRootBiomass_kgC + refTree.getRootLitterFall_kgC()
//				/ grower.getTotalStructuralBiomassToAllocate_kgC();
			rootAllocationCoefficient = (deltaRootBiomass_kgC + refTree.getRootLitterFall_kgC() * refTree.getRootLitterCorrectionFactor()) // mj+fa-24.10.2018
					/ grower.getTotalStructuralBiomassToAllocate_kgC();
			branchAllocationCoefficient = 1 - (stemAllocationCoefficient + rootAllocationCoefficient);
		}

		newTree.setStemAllocationCoefficient(stemAllocationCoefficient);
		newTree.setRootAllocationCoefficient(rootAllocationCoefficient);
		newTree.setBranchAllocationCoefficient(branchAllocationCoefficient);

		double deltaBranchBiomass_kgC = branchAllocationCoefficient * grower.getTotalStructuralBiomassToAllocate_kgC()
				- refTree.getBranchLitterFall_kgC();
		double newBranchBiomass_kgC = refTree.getBranchBiomass_kgC() + deltaBranchBiomass_kgC;
		
		// mj+fa-24.10.2018
		deltaRootBiomass_kgC = rootAllocationCoefficient * grower.getTotalStructuralBiomassToAllocate_kgC()
				- refTree.getRootLitterFall_kgC(); // correction for taking into account the case when root biomass decreases due to a lack of totalStrructuralBiomassToAllocate
		double newRootBiomass_kgC = refTree.getRootBiomass_kgC() + deltaRootBiomass_kgC;

		//mj+fa-24.10.2018: commented
//		if (grower.getDeltaAboveGroundStructuralBiomass_kgC() == 0)
//			newBranchBiomass_kgC = refTree.getBranchBiomass_kgC() - refTree.getBranchLitterFall_kgC();
//		newBranchBiomass_kgC = Math.max(newBranchBiomass_kgC, 0.1); //mj+fa-05.12.2017

		newTree.setBranchBiomass_kgC(newBranchBiomass_kgC);
		newTree.setRootBiomass_kgC(newRootBiomass_kgC); // mj+fa-24.10.2018

		// Temporary, crown dimensions
		double deltaHlce = species.hlceHeightProportion * grower.getDeltaHeight();
		newTree.setHlce(refTree.getHlce() + deltaHlce);

		double deltaHcb = species.hcbHeightProportion * grower.getDeltaHeight();
		newTree.setHcb(refTree.getHcb() + deltaHcb);

		double crownToStemDiameterRatio = species.crownToStemDiameterEstimation.result(newC130);

		// double deltaDbh_m = deltaDbh_cm / 100d;
		double deltaR = deltaDbh_m / 2d * crownToStemDiameterRatio;

		newTree.setRnorth(refTree.getRnorth() + deltaR);
		newTree.setReast(refTree.getReast() + deltaR);
		newTree.setRsouth(refTree.getRsouth() + deltaR);
		newTree.setRwest(refTree.getRwest() + deltaR);

		newTree.updateMean2CrownRadius();

		newTree.updateStemAndLitters(refTree.getLeafCarbonConcentration());
	}

	public HetTree getNewTree() {
		return newTree;
	}

}
