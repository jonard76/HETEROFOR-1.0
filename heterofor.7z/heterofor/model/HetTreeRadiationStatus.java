/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model;

import java.io.Serializable;
import java.util.List;

import capsis.lib.samsaralight.tag.SLTag;
import capsis.lib.samsaralight.tag.SLTagTreeResult;
import heterofor.model.fineresolutionradiativebalance.HetAverageRadiation;
import heterofor.model.fineresolutionradiativebalance.HetKeyDoy;
import heterofor.model.vegetationperiod.HetAbsorptionCoefficientEvaluator;
import heterofor.model.vegetationperiod.HetPhase;
import heterofor.model.vegetationperiod.HetVegetationPeriod;
import jeeb.lib.util.ListMapThreadSafe;

/**
 * Early stage in tree growth, tree radiation status.
 * 
 * @author M. Jonard - March 2016
 */
public class HetTreeRadiationStatus implements Serializable {

	public double interceptedParRadiation;
	public double interceptedDirectParRadiation; // fc+mj-13.9.2017
	public double interceptedDiffuseParRadiation; // fc+mj-13.9.2017
	
	public double lightCompetitionIndex;


	/**
	 * Phase 1 in growth process.
	 */
	public HetTreeRadiationStatus(HetTree tree) throws RuntimeException {
		
		// fa-22.12.2017
		HetScene scene = (HetScene) tree.getScene();
		HetInitialParameters ip = (HetInitialParameters) scene.getStep().getProject().getModel().getSettings();

		if (!ip.fineResolutionRadiativeBalanceActivated) { //fa-22.12.2017: Samsaralight Legacy mode
			// PHASE 1: light
			double interceptedGlobalRadiation = tree.getLightResult().getCrownEnergy();
			double interceptedDirectRadiation = tree.getLightResult().getCrownDirectEnergy();
			double interceptedDiffuseRadiation = tree.getLightResult().getCrownDiffuseEnergy();

			// 1 J/m2/s = 4.55 micro mol/m2/s (The, 2006, p.133)
			// The PAR = 46% of the global radiation (station meteo Baileux)
			interceptedParRadiation = (1 - 0.11) * interceptedGlobalRadiation * 4.55 * 0.46;
			interceptedDirectParRadiation = (1 - 0.11) * interceptedDirectRadiation * 4.55 * 0.46;
			interceptedDiffuseParRadiation = (1 - 0.11) * interceptedDiffuseRadiation * 4.55 * 0.46;

			// fc+mj-13.9.2017 added (1 - 0.11) upper, albedo
		
			// fc-18.12.2014 New computation for parUseEfficiency (by M. Jonard)
			if (tree.getLightResult().getCrownPotentialEnergy() != 0) {
				lightCompetitionIndex = tree.getLightResult().getCrownEnergy()
						/ tree.getLightResult().getCrownPotentialEnergy();
			} else {
				lightCompetitionIndex = 0;
			}
		}
		
		//fa-22.12.2017: Samsaralight Tag mode
		else { 
			
			// PHASE 1: light
			double crownDirectEnergySum = 0;
			double crownDiffuseEnergySum = 0;
			double crownPotentialEnergySum = 0;
			
			HetVegetationPeriod vegetationPeriod = scene.getVegetationPeriod();
			ListMapThreadSafe<String, SLTagTreeResult> tagResultMap = tree.getLightResult().getTagResultMap();
			
			HetAverageRadiation averageRadiation = scene.getBeamSetFactory().getAverageRadiation();
			HetAbsorptionCoefficientEvaluator coefEval = new HetAbsorptionCoefficientEvaluator(tree, scene, vegetationPeriod, averageRadiation);
			
			for (HetPhase phase : vegetationPeriod.getPhases()) {
				
				if (phase.isCompleteDevelopmentPhase()) { // Sum energies over the completeLeafDevelopment phase
					for (int hour = 0; hour < 24; hour++) {
				
						String beamTag = phase.name + "_" + hour;
						List<SLTagTreeResult> results = tagResultMap.get(beamTag);
								
						if (results != null) {
							for (SLTagTreeResult r : results) {

								// We ignore Tags TRUNK and LOWER_CROWN_POTENTIAL

								if (r.interceptionTag.equals(SLTag.CROWN) && r.energyTag.equals(SLTag.DIRECT)) {
									crownDirectEnergySum += r.energy_MJ;
							
								} else if (r.interceptionTag.equals(SLTag.CROWN) && r.energyTag.equals(SLTag.DIFFUSE)) {
									crownDiffuseEnergySum += r.energy_MJ;
							
//								} else if (r.interceptionTag.equals(SLTag.CROWN) && r.energyTag.equals(SLTag.CROWN_POTENTIAL)) { // For non-optimized tag mode
								} else if (r.interceptionTag.equals(SLTag.CROWN) && (r.energyTag.equals(SLTag.CROWN_POTENTIAL_DIRECT) || r.energyTag.equals(SLTag.CROWN_POTENTIAL_DIFFUSE))) { // For optimized tag mode
									crownPotentialEnergySum += r.energy_MJ;

								}
							}
						}
					}
				}
				
//				else if (phase.name.equals("LD") || phase.name.equals("LY")) { // keyDoys of leafDevelopment and leafYellowing phases, DO NOT consider intermediate doys
//					List<HetKeyDoy> keyDoys = phase.getKeyDoys();
//					for (HetKeyDoy kd : keyDoys) {
//						int doy = kd.doy;
//						for (int hour = 0; hour < 24; hour++) {
//							crownDirectEnergySum += coefEval.getCrownDirectCoefficient(doy, hour) / (1 - 0.11) * averageRadiation.getIncidentDirectRadiation(doy, hour);
//							crownDiffuseEnergySum += coefEval.getCrownDiffuseCoefficient(doy, hour) / (1 - 0.11) * averageRadiation.getIncidentDiffuseRadiation(doy, hour);
//							crownPotentialEnergySum += coefEval.getCrownPotentialCoefficient(doy, hour) / (1 - 0.11) * averageRadiation.getIncidentGlobalRadiation(doy, hour);
//						}
//					}
//				}
				
				
				
				
				else if (phase.name.equals("LD") || phase.name.equals("LY")) { // keyDoys of leafDevelopment and leafYellowing phases, and intermediate doys
					int startDoy = phase.startDoy;
					int endDoy = phase.endDoy;
					for (int doy = startDoy; doy <= endDoy; doy++) {
						for (int hour = 0; hour < 24; hour++) {
							crownDirectEnergySum += coefEval.getCrownDirectCoefficient(doy, hour) / (1 - 0.11) * averageRadiation.getIncidentDirectRadiation(doy, hour);
							crownDiffuseEnergySum += coefEval.getCrownDiffuseCoefficient(doy, hour) / (1 - 0.11) * averageRadiation.getIncidentDiffuseRadiation(doy, hour);
							crownPotentialEnergySum += coefEval.getCrownPotentialCoefficient(doy, hour) / (1 - 0.11) * averageRadiation.getIncidentGlobalRadiation(doy, hour);
						}
					}
				}
			}
						
			double interceptedGlobalRadiation = crownDirectEnergySum + crownDiffuseEnergySum;
			double interceptedDirectRadiation = crownDirectEnergySum;
			double interceptedDiffuseRadiation = crownDiffuseEnergySum;
			
//			System.out.println("HetTreeRadiationStatus: date = "  + scene.getDate() + ", treeId = " + tree.getId() + ", Direct = " + crownDirectEnergySum  + ", Diffuse = " + crownDiffuseEnergySum + ", Potential = " + crownPotentialEnergySum);

			// 1 J/m2/s = 4.55 micro mol/m2/s (The, 2006, p.133)
			// The PAR = 46% of the global radiation (station meteo Baileux)
			interceptedParRadiation = interceptedGlobalRadiation * 4.55 * 0.46; // albedo (1-0.11) already accounted for in coefficient computation
			interceptedDirectParRadiation = interceptedDirectRadiation * 4.55 * 0.46; // albedo (1-0.11) already accounted for in crownDirectCoefficient computation
			interceptedDiffuseParRadiation = interceptedDiffuseRadiation * 4.55 * 0.46; // albedo (1-0.11) already accounted for in crownDiffuseCoefficient computation
					
			if (crownPotentialEnergySum != 0) {
				lightCompetitionIndex = interceptedGlobalRadiation
						/ crownPotentialEnergySum;
			} else {
				lightCompetitionIndex = 0;
			}
		}
	}

}
