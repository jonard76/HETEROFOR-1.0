/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model;

import java.util.HashMap;
import java.util.Map;

import capsis.kernel.EvolutionParameters;
import jeeb.lib.util.Automatable;

/**
 * HetEvolutionParameters is a description of the parameters needed to run an
 * evolution stage in the Heterofor. It can be at for example a target date, or
 * a target age for a plantation, or a number of time steps.
 * 
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetEvolutionParameters implements EvolutionParameters, Automatable {

	private int numberOfYears; // number of years for an evolution process

	// Optional, will be checked during evolution if not null, fc+mj-27.4.2015
	public String trueThinningFileName;

	// Optional: a mode for PAR Use Efficiency estimation
	public boolean pueEstimationMode;
	// Requested if pueEstimationMode is true
	public HetScene pueEstimationTargetScene;
	
	/**
	 * Constructor
	 */
	public HetEvolutionParameters(int numberOfYears) {
		this.numberOfYears = numberOfYears;

	}

	/**
	 * Constructor 2, fc+mj-27.4.2015
	 */
	public HetEvolutionParameters(int numberOfYears, String trueThinningFileName) {
		this.numberOfYears = numberOfYears;
		this.trueThinningFileName = trueThinningFileName;

	}

	/**
	 * Constructor 3, fc+mj-21.3.2016, PAR Use Efficiency mode. trueThinningFileName is optional, may be null.
	 */
	public HetEvolutionParameters(HetScene pueEstimationTargetScene, String trueThinningFileName) {
		this.pueEstimationMode = true;
		this.pueEstimationTargetScene = pueEstimationTargetScene;
		this.trueThinningFileName = trueThinningFileName;

	}

	public int getNumberOfYears() {
		return numberOfYears;
	}

	public String getTrueThinningFileName() { // fc+mj-27.4.2015
		return trueThinningFileName;
	}

	/**
	 * Convenient method to load the file and return a map with key: treeId and
	 * value: its lastYear of presence in the stand.
	 */
	public static Map<Integer, Integer> getTrueThinningMap(String fileName) throws Exception {

		// fc-27.1.2017 trueThinningMap file is optional
		if (fileName == null || fileName.isEmpty())
			return null;
		
		HetTrueThinningFileLoader loader = new HetTrueThinningFileLoader();
		loader.load(fileName);

		// fc-6.12.2017 no more report in FileLoader
		
//		String loaderReport = loader.load(fileName);
//		// In case of trouble, tell user
//		if (!loader.succeeded()) {
//			throw new Exception(loaderReport);
//		}

		Map<Integer, Integer> map = new HashMap<Integer, Integer>();

		for (HetTrueThinningFileLoader.Line line : loader.lines) {
			map.put(line.treeId, line.lastYear);
		}

		return map;
	}

}
