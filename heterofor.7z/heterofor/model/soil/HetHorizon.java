/*
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their
 * permission.
 * It can be shared by the modellers of the Capsis co-development community
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory
 * for further information about licenses in Capsis.
 */

package heterofor.model.soil;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetReporter;
import heterofor.model.HetScene;
import heterofor.model.soilchemistry.HetChemicalElement;
import heterofor.model.soilchemistry.HetMineral;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import jeeb.lib.util.Log;

/**
 * A Soil horizon (layer) in the heterofor model.
 *
 * @author M. Jonard - October 2015
 */
public class HetHorizon implements Serializable {

	// Used at load time to manage NA (String) values in the file, will be
	// replaced temporarily by NOT_SET (double), will be detected and value will
	// be changed with a function
	public static final double NOT_SET = -999999;

	public int id;
	public String name;
	public double upperLimit; // m
	public double lowerLimit; // m
	public double thickness; // m
	public double volume; // m3, for an area of 1 m2
	public double coarseFraction; // "fraction grossi�re additionnelle non prise en compte dans le calcul de la bulkDensity" (cailloux), m3/m3 [0,
									// 1]
	public double bulkDensity; // kg of fine earth/m3
	public double sand; // g/g
	public double silt; // "limon", g/g
	public double clay; // "argile", g/g
	public double organicCarbon; // mg/g // fc+mj+lw-20.10.2016

	public double meanWaterContent; // m3/m3
	public double lastWaterContent; // m3/m3
	public double residualWaterContent; // m3/m3
	public double wiltingPointWaterContent; // m3/m3
	public double saturatedWaterContent; // m3/m3

	// fc+mj-10.3.2017
	public double fieldCapacityWaterContent; // m3/m3

	// public List<Double> waterContent;

	public double solution_pH;
	public double logpCO2; // with pCO2 in atm
	public double fineRootProportion; // %, [0, 1]
	public double tortuosityFactor; // (m/m) // fc+mj-10.5.2016
	public double totalFineRootLength; // m

	/**
	 * Map to store temperature of mineral horizons.
	 * Key: year_month_day_hour string
	 * Value: temperature of a mineral horizon averaged on the space discretisation points of this horizon
	 */
	private Map<String, Double> timeMineralHorizonTemperatureMap;

	// key is year_month_day_hour string, value: thermal diffusivity of horizon
	public Map<String, Double> timeThermalDiffusivityMap;

	// These maps must keep their insertion order (LinkedHashMap required)
	// fc-7.9.2016
	private Map<String, Double> solutionConcentrations; // mg/l
	private Map<String, HetMineral> mineralConcentrations; // concentration in
															// mole/kg
	private Map<String, Double> exchangeableCationConcentrations; // cmole/kg OR
																	// meq/100g
	private Map<String, Double> exchangeableAnionConcentrations; // cmole/kg OR
																	// meq/100g

	/**
	 * Constructor
	 */
	public HetHorizon(int id, String name, double upperLimit, double lowerLimit, double thickness, double volume,
			double coarseFraction, double bulkDensity, double sand, double silt, double clay, double organicCarbon,
			double meanWaterContent, double wiltingPointWaterContent, double saturatedWaterContent, double solution_pH,
			double logpCO2, double fineRootProportion, double tortuosityFactor) {
		super();
		this.id = id;
		this.name = name;
		this.upperLimit = upperLimit;
		this.lowerLimit = lowerLimit;
		this.thickness = thickness;
		this.volume = volume;
		this.coarseFraction = coarseFraction;
		this.bulkDensity = bulkDensity;
		this.sand = sand;
		this.silt = silt;
		this.clay = clay;
		this.organicCarbon = organicCarbon;
		this.meanWaterContent = meanWaterContent;
		this.lastWaterContent = meanWaterContent; // fc+mj+lw-20.10.2016
		this.residualWaterContent = 0;
		this.wiltingPointWaterContent = wiltingPointWaterContent;
		this.saturatedWaterContent = saturatedWaterContent;
		this.solution_pH = solution_pH;
		this.logpCO2 = logpCO2;
		this.fineRootProportion = fineRootProportion;
		this.tortuosityFactor = tortuosityFactor;

		if (saturatedWaterContent == HetHorizon.NOT_SET) {
			if (lowerLimit >= 0)
				// Special case for organic horizons
				this.saturatedWaterContent = 0.75;
			else
				this.saturatedWaterContent = 0.6355 + 0.0013 * clay * 100d - 0.1631 * bulkDensity / 1000d;
		}


		HetHydraulicPedotransferParameters pedoParams = new HetHydraulicPedotransferParameters(this);
		pedoParams.execute();

		if (wiltingPointWaterContent == HetHorizon.NOT_SET) {
			this.wiltingPointWaterContent = new HetVanGenuchten(this, pedoParams, 15000d).execute();
		}

		// fc+mj-10.3.2017
		this.fieldCapacityWaterContent = new HetVanGenuchten(this, pedoParams, 330d).execute();

		// Using LinkedHashMaps which keep the insertion order matter for
		// PhreeqC exchanges fc-7.9.2016
		solutionConcentrations = new LinkedHashMap<>();
		mineralConcentrations = new LinkedHashMap<>();
		exchangeableCationConcentrations = new LinkedHashMap<>();
		exchangeableAnionConcentrations = new LinkedHashMap<>();
	}

	/**
	 * Creates a copy of the given horizon.
	 */
	public HetHorizon(HetHorizon o) {
		// fc+mj+fa+lw-15.2.2017 fixed: wiltingPointWaterContent (was residualWaterContent!)
		this(o.id, o.name, o.upperLimit, o.lowerLimit, o.thickness, o.volume, o.coarseFraction, o.bulkDensity, o.sand,
				o.silt, o.clay, o.organicCarbon, o.meanWaterContent, o.wiltingPointWaterContent, o.saturatedWaterContent,
				o.solution_pH, o.logpCO2, o.fineRootProportion, o.tortuosityFactor);
//		this(o.id, o.name, o.upperLimit, o.lowerLimit, o.thickness, o.volume, o.coarseFraction, o.bulkDensity, o.sand,
//				o.silt, o.clay, o.organicCarbon, o.meanWaterContent, o.residualWaterContent, o.saturatedWaterContent,
//				o.solution_pH, o.logpCO2, o.fineRootProportion, o.tortuosityFactor);

		this.solution_pH = 0;
		this.totalFineRootLength = 0;

		this.lastWaterContent = o.lastWaterContent; // fc+mj+lw-20.10.2016

		// We copy the entries of the concentration maps with the names only,
		// and a 0 value fc-7.9.2016
		// These maps must have been prepared to help feed them after a call to
		// PhreeqC: fields are retrieved in the same order, order of the keys,
		// we use LinkedHashMaps to always keep the same insertion order
		for (String eltName : o.solutionConcentrations.keySet())
			setSolutionConcentration(eltName, 0d);
		for (String mineralName : o.mineralConcentrations.keySet()) {
			HetMineral m = o.mineralConcentrations.get(mineralName);
			// We store a copy of the mineral with its concentration set to 0
			setMineralConcentration(mineralName, new HetMineral(m));
		}
		for (String exchName : o.exchangeableCationConcentrations.keySet())
			setExchCationConcentration(exchName, 0d);
		for (String exchName : o.exchangeableAnionConcentrations.keySet())
			setExchAnionConcentration(exchName, 0d);

	}

	public Map<String, Double> concentrationToStock(HetInitialParameters ip, HetScene scene,
			Map<String, Double> concentrationMap) {
		Map<String, Double> stockMap = new HashMap<>();
		double area_m2 = scene.getArea();

		for (String eName : concentrationMap.keySet()) {
			double conc = concentrationMap.get(eName);

			HetChemicalElement elt = ip.getChemicalElement(eName);

			double stock = conc * 10d / 1000d * elt.atomicMass / Math.abs(elt.charge) * 1d / 1000d * volume * area_m2
					* bulkDensity * (1 - coarseFraction);
			stockMap.put(eName, stock); // Kg
		}

		return stockMap; // Kg
	}

	public Map<String, Double> stockToConcentration(HetInitialParameters ip, HetScene scene,
			Map<String, Double> stockMap) {
		Map<String, Double> concentrationMap = new HashMap<>();
		double area_m2 = scene.getArea();

		for (String eName : stockMap.keySet()) {
			double stock = stockMap.get(eName);

			HetChemicalElement elt = ip.getChemicalElement(eName);

			double conc = stock / (volume * area_m2 * bulkDensity * (1 - coarseFraction)) * 1000d
					* Math.abs(elt.charge) / elt.atomicMass * 100d;
			concentrationMap.put(eName, conc); // cmole/kg OR meq/100g
		}

		return concentrationMap;
	}

	public void removeElement(String elementName, double[] horizonValue) {
		// affect the horizons
	}

	/**
	 * Returns true if the horizon is organic. Returns false otherwise.
	 */
	public boolean isOrganic() {
		if (upperLimit > 0.0) return true;
		else return false;
	}

	/**
	 * Add the (time, temperature) pair to the timeTemperatureMap map
	 * @param time The year_month_day_hour string
	 * @param temperature The temperature of the horizon
	 */
	public void addTimeTemperature(String time, double temperature) {

		if (timeMineralHorizonTemperatureMap == null) {
			timeMineralHorizonTemperatureMap = new LinkedHashMap<String, Double>();
		}

		timeMineralHorizonTemperatureMap.put(time, temperature);
	}

	public void setSolutionConcentration(String eltName, double conc) {
		solutionConcentrations.put(eltName, conc);
	}

	/**
	 * Used at file load time, the given mineral contains the concentration.
	 */
	public void setMineralConcentration(String mineralName, HetMineral m) {
		mineralConcentrations.put(mineralName, m);
	}

	/**
	 * Used after PhreeqC returned, sets the new concentration value for the
	 * given mineral.
	 */
	public void setMineralConcentration(String mineralName, double conc) { // fc-7.9.2016
		HetMineral m = mineralConcentrations.get(mineralName);
		// if m == null, the pb must be solved at development time
		// -> the line below will stop the program
		// Log.println("HetHorizon setMineralConcentration () mineralName: "+mineralName+" conc: "+conc);
		m.concentration = conc;
	}

	public void setExchCationConcentration(String exchName, double conc) {
		exchangeableCationConcentrations.put(exchName, conc);
	}

	public void setExchAnionConcentration(String exchName, double conc) {
		exchangeableAnionConcentrations.put(exchName, conc);
	}

	public double getSolutionConcentration(String eltName) {
		Double v = solutionConcentrations.get(eltName);
		if (v == null) {
			HetReporter.printInLog(Log.WARNING, "HetHorizon.getSolutionConcentration ()", "Element " + eltName
					+ " could not be found in the list of elements in solution, returned 0");
			return 0;
		}
		return v;
	}

	public double getMineralConcentration(String mineralName) {
		HetMineral m = mineralConcentrations.get(mineralName);
		if (m == null) {
			HetReporter.printInLog(Log.WARNING, "HetHorizon.getMineralConcentration ()", "Error in horizon " + id + ": mineral "
					+ mineralName + " could not be found in the list of minerals, returned 0");
			return 0;
		}
		return m.concentration;
	}

	public HetMineral getMineral(String mineralName) {
		HetMineral m = mineralConcentrations.get(mineralName);
		return m;
	}

	public double getExchCationConcentration(String exchName) {
		Double v = exchangeableCationConcentrations.get(exchName);
		if (v == null) {
			HetReporter.printInLog(Log.WARNING, "HetHorizon.getExchCatConcentration ()", "Exchangeable " + exchName
					+ " could not be found in the list of exchangeable cations, returned 0");
			return 0;
		}
		return v;
	}

	static private boolean trace = false; // fc-7.9.2016 TMP

	/**
	 * Proportion of a cation exchangeable in the horizon.
	 */
	public double getExchangeableCationProportion(HetInitialParameters ip, String exchName) {
		HetChemicalElement elt = ip.getChemicalElement(exchName);
		String eName = elt.treeElement; // maybe "-"
		double conc = this.getExchangeableCationConcentrations().get(exchName);

		if (trace)
			HetReporter.printInLog("HetHorizon getExchangeableCationProportion() for exchName: " + exchName + " eName: " + eName
					+ " conc: " + conc);

		double sum = 0;
		for (String exchName2 : this.getExchangeableCationConcentrations().keySet()) {

			HetChemicalElement elt2 = ip.getChemicalElement(exchName2);
			String eName2 = elt2.treeElement; // maybe "-"

			if (eName2.equals(eName)) {

				double conc2 = this.getExchangeableCationConcentrations().get(exchName2);
				sum += conc2;

				if (trace)
					HetReporter.printInLog("   summing exchName2: " + exchName2 + " eName2: " + eName2 + " conc2: " + conc2 + " sum: " + sum);
			}
		}
		double proportion = conc / sum;

		if (trace)
			HetReporter.printInLog("   proportion: " + proportion);

		trace = false;

		return proportion;
	}

	public double getExchAnionConcentration(String exchName) {
		Double v = exchangeableAnionConcentrations.get(exchName);
		if (v == null) {
			HetReporter.printInLog(Log.WARNING, "HetHorizon.getExchAnConcentration ()", "Exchangeable " + exchName
					+ " could not be found in the list of exchangeable anions, returned 0");
			return 0;
		}
		return v;
	}

	public Map<String, Double> getSolutionConcentrations() {
		return solutionConcentrations;
	}

	public Map<String, HetMineral> getMineralConcentrations() {
		return mineralConcentrations;
	}

	public Map<String, Double> getExchangeableCationConcentrations() {
		return exchangeableCationConcentrations;
	}

	public Map<String, Double> getExchangeableAnionConcentrations() {
		return exchangeableAnionConcentrations;
	}

	public Map<String, Double> getTimeMineralHorizonTemperatureMap() {
		return timeMineralHorizonTemperatureMap;
	}

	// The four accessors upper have been added to help inspect the maps with
	// the intercative Inspector

	public void setExchangeableCationConcentrations(Map<String, Double> exchangeableCationConcentrations) {
		this.exchangeableCationConcentrations = exchangeableCationConcentrations;
	}

	public void setExchangeableAnionConcentrations(Map<String, Double> exchangeableAnionConcentrations) {
		this.exchangeableAnionConcentrations = exchangeableAnionConcentrations;
	}

	@Override
	public String toString() {
		return "HetHorizon [id: " + id + ", hashCode: " + hashCode() + ", name: " + name + ", upperLimit: "
				+ upperLimit + ", lowerLimit: " + lowerLimit + ", thickness: " + thickness + ", volume: " + volume
				+ ", coarseFraction: " + coarseFraction + ", bulkDensity: " + bulkDensity + ", sand: " + sand
				+ ", silt: " + silt + ", clay: " + clay + ", organicCarbon: " + organicCarbon + ", meanWaterContent: "
				+ meanWaterContent + ", lastWaterContent: " + lastWaterContent + ", residualWaterContent: "
				+ residualWaterContent + ", saturatedWaterContent: " + saturatedWaterContent + ", solution_pH: "
				+ solution_pH + ", logpCO2: " + logpCO2 + ", fineRootProportion: " + fineRootProportion
				+ ", tortuosityFactor: " + tortuosityFactor + ", totalFineRootLength: " + totalFineRootLength + "]";
	}

}
