/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.soil;

/**
 * The van Genuchten function computes water content from matric potential (cm).
 * 
 * @author M. Jonard, Louis de Wergifosse, F. de Coligny - October 2016
 */
public class HetVanGenuchten {

	private HetHorizon horizon;
	private HetHydraulicPedotransferParameters params;
	private double matricPotential;

	/**
	 * Constructor
	 */
	public HetVanGenuchten(HetHorizon horizon, HetHydraulicPedotransferParameters params, double matricPotential) {
		this.horizon = horizon;
		this.params = params;
		this.matricPotential = matricPotential;
	}

	public double execute() {

		double m = 1d - 1d / params.n;

		double a = Math.pow(params.alpha * Math.abs(matricPotential), params.n);

		double relativeSaturation = Math.pow(1d + a, -m);

		double waterContent = params.residualWaterContent
				+ (params.saturatedWaterContent - params.residualWaterContent) * relativeSaturation;

		return waterContent;

	}

}
