/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import jeeb.lib.util.Record;
import jeeb.lib.util.fileloader.FileLoader;

/**
 * A file loader for a true thinning file
 * 
 * @author F. de Coligny - April 2015
 */
public class HetTrueThinningFileLoader extends FileLoader {

	public List<Line> lines;

	@Override
	protected void checks() throws Exception {
		// Each treeId must be found only once in the file
		Set<Integer> treeIds = new HashSet<Integer> ();
		for (Line l : lines) {
			if (treeIds.contains(l.treeId))
				throw new Exception ("Error in file: found a treeId several times: "+l.treeId);
		}
		
	}

	/**
	 * A line in the input file
	 */
	static public class Line extends Record {
		
		public int treeId;
		public int lastYear;

		/**
		 * Constructor (super constructor is automatic, based on introspection).
		 * 
		 * @param line
		 *            : the line to be turned into a Line object
		 * @throws Exception
		 *             : if the line format does not match a Line
		 */
		public Line(String line) throws Exception {
			super(line);
		}

	}

	/**
	 * Constructor
	 */
	public HetTrueThinningFileLoader() throws Exception {
		super ();
	}

}
