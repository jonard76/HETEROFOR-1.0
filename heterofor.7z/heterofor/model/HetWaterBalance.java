/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * Stand water balance for a given hour.
 * 
 * @author M. Jonard, L. de Wergifosse, F. de Coligny, N. Beudez - September
 *         2016
 */
public class HetWaterBalance implements Serializable {

	public int year;
	public int month;
	public int day;
	public int hour;

	public double rainfall; // mm
	public double stemflow; // mm
	public double throughfall; // mm
	public double interception; // mm
	public double transpiration; // mm

	// fc+mj-13.9.2017
	public double standLevel_transpiration; // mm
	public double treeLevel_transpiration; // mm
	public double groundVegetationTranspiration; // mm
	
	public double barkEvaporation; // mm // fc+mj+lw-19.10.2016
	public double foliageEvaporation; // mm // fc+mj+lw-19.10.2016
	public double vegetationEvaporation; // mm
	public double soilEvaporation; // mm
	public double deepDrainage; // mm

	public double relativeExtractableWater; // mm/mm
	public double forestFloorRelativeExtractableWater; // mm/mm
	
	// key: horizon id, value: water content 
	public Map<Integer, Double> horizonWaterContent; // m3/m3
	
	private int integrationCounter; // for optional integration, see below

	/**
	 * Default Constructor
	 */
	public HetWaterBalance() {
		horizonWaterContent = new LinkedHashMap<Integer, Double>();
	}

	/**
	 * Constructor
	 */
	public HetWaterBalance(int year, int month, int day, int hour, Map<Integer, Double> horizonWaterContent,
			double rainfall, double stemflow, double throughfall, double interception, 
			double transpiration, double standLevel_transpiration, double treeLevel_transpiration, double groundVegetationTranspiration, 
			double barkEvaporation, double foliageEvaporation, double vegetationEvaporation, double soilEvaporation,
			double deepDrainage, double relativeExtractableWater, double forestFloorRelativeExtractableWater) {
		super();
		this.year = year;
		this.month = month;
		this.day = day;
		this.hour = hour;
		this.horizonWaterContent = horizonWaterContent;
		this.rainfall = rainfall;
		this.stemflow = stemflow;
		this.throughfall = throughfall;
		this.interception = interception;
		this.transpiration = transpiration;
		
		this.standLevel_transpiration = standLevel_transpiration;
		this.treeLevel_transpiration = treeLevel_transpiration;
		this.groundVegetationTranspiration = groundVegetationTranspiration;
		
		this.barkEvaporation = barkEvaporation;
		this.foliageEvaporation = foliageEvaporation;
		this.vegetationEvaporation = vegetationEvaporation;
		this.soilEvaporation = soilEvaporation;
		this.deepDrainage = deepDrainage;
		this.relativeExtractableWater = relativeExtractableWater;
		this.forestFloorRelativeExtractableWater = forestFloorRelativeExtractableWater;
	}

	/**
	 * Integration stage 1: sum the given water balance in this, see integrate
	 * ()
	 */
	public void add(HetWaterBalance wb) {

		integrationCounter++; // this will be used in integrate ()

		for (int hId : wb.horizonWaterContent.keySet()) {

			double prevValue;

			if (horizonWaterContent.get(hId) == null)
				prevValue = 0.0;
			else
				prevValue = horizonWaterContent.get(hId);
			double v = wb.horizonWaterContent.get(hId);

			this.horizonWaterContent.put(hId, prevValue + v);
		}

		this.rainfall += wb.rainfall;
		this.stemflow += wb.stemflow;
		this.throughfall += wb.throughfall;
		this.interception += wb.interception;
		this.transpiration += wb.transpiration;
		
		this.standLevel_transpiration += wb.standLevel_transpiration;
		this.treeLevel_transpiration += wb.treeLevel_transpiration;
		this.groundVegetationTranspiration += wb.groundVegetationTranspiration;
		
		this.barkEvaporation += wb.barkEvaporation;
		this.foliageEvaporation += wb.foliageEvaporation;
		this.vegetationEvaporation += wb.vegetationEvaporation;
		this.soilEvaporation += wb.soilEvaporation;
		this.deepDrainage += wb.deepDrainage;

		this.relativeExtractableWater += wb.relativeExtractableWater;
		this.forestFloorRelativeExtractableWater += wb.forestFloorRelativeExtractableWater;
	}

	/**
	 * Integration stage 2: to be called after a series of add(), average the
	 * values to be averaged (the other values are sums).
	 */
	public void integrate() {

		this.relativeExtractableWater /= integrationCounter;
		this.forestFloorRelativeExtractableWater /= integrationCounter;

		// System.out.println("dans integrate: horizonWaterContent, taille: " +
		// horizonWaterContent.keySet().size());

		for (int hId : horizonWaterContent.keySet()) {
			double v = horizonWaterContent.get(hId);
			v /= integrationCounter; // average

			horizonWaterContent.put(hId, v);

		}

		integrationCounter = 0;
	}

	/**
	 * Returns a full copy of the HetWaterBalance object
	 */
	public HetWaterBalance getCopy() { // nb-15.12.2016

		HetWaterBalance copiedWaterBalance = null;

		Map<Integer, Double> copiedHorizonWaterContentMap = new HashMap<Integer, Double>();

		for (Integer refKey : this.horizonWaterContent.keySet()) {
			copiedHorizonWaterContentMap.put(refKey, this.horizonWaterContent.get(refKey));
		}

		copiedWaterBalance = new HetWaterBalance(this.year, this.month, this.day, this.hour,
				copiedHorizonWaterContentMap, this.rainfall, this.stemflow, this.throughfall, this.interception,
				this.transpiration, this.standLevel_transpiration, this.treeLevel_transpiration, groundVegetationTranspiration, 
				this.barkEvaporation, this.foliageEvaporation, this.vegetationEvaporation,
				this.soilEvaporation, this.deepDrainage, this.relativeExtractableWater,
				this.forestFloorRelativeExtractableWater);

		return copiedWaterBalance;
	}

	// Tools to work with the key used in the maps containing WaterBalance
	// objects
	static public int[] decomposeKey(String year_month_day_hour) throws Exception {
		try {
			int[] res = new int[4];
			StringTokenizer st = new StringTokenizer(year_month_day_hour, "_");

			for (int i = 0; i < 4; i++) {
				String token = st.nextToken();
				res[i] = Integer.parseInt(token);
			}
			return res;
		} catch (Exception e) {
			throw new Exception("HetWaterBalance, could not decopomse this key, should be year_month_day_hour: "
					+ year_month_day_hour);
		}

	}

	// Tools to work with the key used in the maps containing WaterBalance
	// objects
	public String getKey() {
		return "" + year + "_" + month + "_" + day + "_" + hour;
	}

	/**
	 * Returns a string representation of the object.
	 */
	public String toString() {

		StringBuffer b = new StringBuffer(getKey());

		b.append(" rainfall: " + rainfall);
		b.append(" stemflow: " + stemflow);
		b.append(" throughfall: " + throughfall);
		b.append(" interception: " + interception);
		b.append(" transpiration: " + transpiration);
		
		b.append(" standLevel_transpiration: " + standLevel_transpiration);
		b.append(" treeLevel_transpiration: " + treeLevel_transpiration);
		b.append(" groundVegetationTranspiration: " + groundVegetationTranspiration);
		
		b.append(" barkEvaporation: " + barkEvaporation);
		b.append(" foliageEvaporation: " + foliageEvaporation);
		b.append(" vegetationEvaporation: " + vegetationEvaporation);
		b.append(" soilEvaporation: " + soilEvaporation);
		b.append(" deepDrainage: " + deepDrainage);
		b.append(" relativeExtractableWater: " + relativeExtractableWater);
		b.append(" forestFloorRelativeExtractableWater: " + forestFloorRelativeExtractableWater);

		return b.toString();
	}

}
