/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.vegetationperiod;

import heterofor.model.HetScene;
import heterofor.model.HetTree;

/**
 * Computes the equivalent surfaces for diffuse and direct radiation for a given
 * tree from a yearly radiation balance (LEGACY mode in SamsaraLight).
 *
 * @author F. André, F. de Coligny - May 2017
 *
 */
public class HetAbsorbedRaditionCoefficientsYearlyLevel {

	private double treeLeafAbsorbedDirectRadiationCoefficient = 0;
	private double treeLeafAbsorbedDiffuseRadiationCoefficient = 0;

	/**
	 * Constructor
	 */
	public HetAbsorbedRaditionCoefficientsYearlyLevel(HetScene newScene, HetTree refTree) {

		// Calculation of yearly leaf PAR interception coefficient: DIRECT
//		double treeBranchAbsorbedDirectRadiation = newScene.getBarkAbsorbedDirectRadiation()
//				* refTree.getBranchBarkArea();
		double treeCrownAbsorbedDirectRadiation = refTree.getLightResult().getCrownDirectEnergy() * (1 - 0.11);
		double treeLeafAbsorbedDirectRadiation = treeCrownAbsorbedDirectRadiation; //- treeBranchAbsorbedDirectRadiation;

		// MJ/tree/year / MJ/tree/year
		treeLeafAbsorbedDirectRadiationCoefficient = treeLeafAbsorbedDirectRadiation
				/ newScene.getStandIncidentDirectRadiation();

		// Calculation of yearly leaf PAR interception coefficient: DIFFUSE
//		double treeBranchAbsorbedDiffuseRadiation = newScene.getBarkAbsorbedDiffuseRadiation()
//				* refTree.getBranchBarkArea();
		double treeCrownAbsorbedDiffuseRadiation = refTree.getLightResult().getCrownDiffuseEnergy() * (1 - 0.11);
		double treeLeafAbsorbedDiffuseRadiation = treeCrownAbsorbedDiffuseRadiation;
				//- treeBranchAbsorbedDiffuseRadiation;

		// MJ/tree/year / MJ/tree/year
		treeLeafAbsorbedDiffuseRadiationCoefficient = treeLeafAbsorbedDiffuseRadiation
				/ newScene.getStandIncidentDiffuseRadiation();

	}

	public double getTreeLeafAbsorbedDirectRadiationCoefficient() {
		return treeLeafAbsorbedDirectRadiationCoefficient;
	}

	public double getTreeLeafAbsorbedDiffuseRadiationCoefficient() {
		return treeLeafAbsorbedDiffuseRadiationCoefficient;
	}

}
