/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.fineresolutionradiativebalance;

import java.io.Serializable;

/**
 * A key day in Heterofor fine resolution radiative balance mode, e.g. 2
 * specific days in the leaf development period, characterized by a leaf
 * development coefficient (ladProportion).
 * 
 * @author F. André, F. de Coligny - April 2017
 */
public class HetKeyDoy implements Serializable {

	public int doy; // day of year [1, 366]
	public String name; // for tag creation...

	// fc+fa-18.5.2017 REMOVED ladProportion, replaced by a doy in SLBeam and a
	// SLLadProportionManager for SLModel.processLighting ()
	// fa-19.06.2017: SLLadProportionManager refactored to SLFoliageStateManager, 
	// managing both ladProportion and greenProportion
	
	// key: speciesCode, value: ladProportion [0, 1] for this species
	// private Map<Integer, Double> ladProportionMap;

	/**
	 * Constructor.
	 */
	public HetKeyDoy(int doy, String name) {
		this.doy = doy;
		this.name = name;
		// this.ladProportionMap = new HashMap<> ();
	}

	// /**
	// * Adds a ladProportion for the given species at this doy.
	// */
	// public void addLadProportion (int speciesCode, double ladProportion) {
	// ladProportionMap.put(speciesCode, ladProportion);
	// }
	//
	// public Map<Integer, Double> getLadProportionMap() {
	// return ladProportionMap;
	// }

}
