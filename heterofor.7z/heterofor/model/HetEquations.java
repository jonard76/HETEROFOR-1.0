/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model;

import java.io.Serializable;

/**
 * The equations for the Heterofor model.
 * 
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetEquations implements Serializable {

	/**
	 * Calulate the ..
	 * dbh in cm.
	 */
//	static public double computeAboveGroundBiomass (double alpha, double beta, double dbh) {
//		return alpha * Math.pow (dbh, beta);
//	}

	
//	static public double computeDeltaAboveGroundBiomass (double interceptedRadiation, double radiationUseEfficiency, 
//			double respirationRatio, double aboveGroundFraction) {
//		return interceptedRadiation * radiationUseEfficiency * respirationRatio * aboveGroundFraction;
//	}
//
//	static public double computeDbh (double aboveGroundBiomass, double alpha, double beta) {
//		return Math.pow(aboveGroundBiomass / alpha, 1d / beta);
//	}
	
	
}
