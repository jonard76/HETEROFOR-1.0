/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.myscripts;

import heterofor.model.HetEvolutionParameters;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetTree;
import heterofor.model.HetWaterBalance;
import heterofor.model.HetWaterBalanceIntegrator;
// import heterofor.model.HetSensor;
import heterofor.model.meteorology.HetMeteorologyFileLoader;
import heterofor.model.soil.HetHorizon;

import java.awt.Rectangle;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.TreeSet;

import jeeb.lib.util.Check;
import jeeb.lib.util.Log;
import capsis.app.C4Script;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.util.GTreeIdComparator;
import capsis.extension.memorizer.DefaultMemorizer;


/**
 * A script for Heterofor. The script needs one parameter: a command file name (See
 * CommandFileReader_CORDEX). To run the script from a windows terminal:
 * 
 * <pre>
 * capsis -p script heterofor.myscripts.SimusCORDEX
 * </pre>
 * 
 * @author F. Andre, January 2018
 */
public class SimusCORDEX {

	public static void main (String[] args) throws Exception {
		
		// Check the parameters
		// args[0] is the name of this script: heterofor.myscripts.CommandScript (useless)
		// args[1] is the name of command file to be processed
		if (args == null || args.length != 2) { throw new Exception ("One parameter needed: missing command file name"); }
		
		// Check the command file
		String commandFileName = args[1];
		if (!Check.isFile (commandFileName)) { throw new Exception ("Wrong command file name: " + commandFileName); }
		System.out.println ("commandFileName: " + commandFileName);
		
		// Read and interpret the command file
		CommandFileReader_CORDEX commandFileReader = null;
		try {
			commandFileReader = new CommandFileReader_CORDEX (commandFileName);
		} catch (Exception e) {
			Log.println (Log.ERROR, "CommandScript.main ()", "CommandFileReader_CORDEX threw an exception", e);
			throw new Exception ("Error, CommandFileReader_CORDEX threw an exception: " + e.getMessage ()
					+ ", see Log for details");
		}
		
		// Set directories
		String heteroforDataDir = commandFileReader.getHeteroforDataDirectory();
		String outputDir = commandFileReader.getOutputDirectory();
		
		int commandLineIndex = 0;
		
		// Run a set of CORDEX simulations for each line in commandFileReader
		for (CommandFileReader_CORDEX.CommandLine line : commandFileReader.getCommandLines ()) {
			
			commandLineIndex++;

			// Output files
			String outputDendroFile = outputDir + line.outputDendroFile;
			String outputHydroFile = outputDir + line.outputHydroFile;
		
			
			// Simulation settings
			HetInitialParameters ip = new HetInitialParameters ();
			ip.speciesFileName = heteroforDataDir + line.speciesFileName;
			ip.castaneaFileName = heteroforDataDir + "CastaneaSpecies3.txt";
			ip.inventoryFileName = heteroforDataDir + line.inventoryFileName;
			ip.samsaraLightFileName = heteroforDataDir + "samsaralight/samsaraLight_settings_monthly.txt"; 
			ip.soilHorizonsFileName = heteroforDataDir + line.soilHorizonsFileName; 
//			ip.soilChemistryFileName = workingDir + "/" + line.soilChemistryFileName; 
			ip.meteorologyFileName = heteroforDataDir + line.meteorologyFileName; 
			ip.fineResolutionRadiativeBalanceActivated = false;
			ip.radiationCalculationTimeStep = 1;
			ip.phenologyActivated = true; 
			ip.waterBalanceActivated = true;
			ip.waterBalance_treeLevelTranspiration = true; 
			ip.castaneaPhotosynthesisActivated = true;
			ip.pueEmpiricalMethod = true;
			ip.constantNppToGppRatio = true;
			ip.mineralHorizonsTemperatureCalculationActivated = true;
			ip.discretisationSpaceStep = 0.01; // for soil horizons
			ip.competitionAccountedForCrownGrowth = false; 
			ip.generalNutrientLimitation = false;
			ip.nLimitation = false;
			ip.heightGrowthOption = line.heightGrowthOpt; // "IPRFW", "BAILEUX_SITE", "POTENTIAL_MODIFIERS_HEIGHT_GROWTH"
			ip.mortalityActivated = false;
			ip.variableAtmCO2ConcentrationOverTime = stringToBool(line.isVariableAtmCO2);
			if (ip.variableAtmCO2ConcentrationOverTime)
				ip.atmCO2ConcentrationsFileName = heteroforDataDir + line.atmCO2ConcentrationsFileName;
			else
				ip.Ca = Double.parseDouble(line.fixedAtmCO2Value);
		
			// Look for first and last years of in the meteorology data file
			String meteorologyFilePath = heteroforDataDir + line.meteorologyFileName;
			HetMeteorologyFileLoader l = new HetMeteorologyFileLoader();
			l.load(meteorologyFilePath, ip);
			int firstMeteoYear = ip.meteorology.getFirstYearInMeteoFile();
			int lastMeteoYear = ip.meteorology.getLastYearInMeteoFile();
			System.out.println("First year= " + firstMeteoYear + ", last year = " + lastMeteoYear);
		
			// Performs simulations (initialization + 1-year evolution) starting at each year of the meteorology file
			int count = 0;
			for(int startYear = firstMeteoYear; startYear < lastMeteoYear; ++startYear) {
				count++;
				runOneSimulation (startYear, ip, count, outputDendroFile, outputHydroFile);
			}
		
			System.out.println ("\n");
			System.out.println ("CORDEX simulation script for command line #" + commandLineIndex + " (inventory file " + line.inventoryFileName.substring(line.inventoryFileName.lastIndexOf("/")+1) + ", meteorology file " + line.meteorologyFileName.substring(line.meteorologyFileName.lastIndexOf("/")+1) + ") is over.");
			System.out.println ("\n");
			System.out.println ("######################################################################################");
			System.out.println ("\n");
		
		}
		
	}
	
	static private void runOneSimulation (int startYear, HetInitialParameters ip, int count, String outputDendroFile, String outputHydroFile) throws Exception {
		System.out.println ("\n");
		System.out.println (" - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
		System.out.println ("\n");
		System.out.println ("Heterofor CORDEX script, running simulation " + count + " for startYear " + startYear);
		System.out.println ("\n");
				
		C4Script s = new C4Script ("heterofor");
		
		// Initialize simulation
		HetModel model = (HetModel) s.getModel ();
		ip.buildInitScene(model);
		HetScene initScene = (HetScene) ip.getInitScene();
//		HetScene initScene = (HetScene) s.getRoot ().getScene ();
		initScene.setDate(startYear); // modify the date of the initial scene
		
		// Create project
		String projectName = s.getClass ().getName ();
		Project project = s.createProject (projectName, model, ip);
		try {
			s.setMemorizer (project, new DefaultMemorizer ());
		} catch (Exception e) {
			Log.println (Log.ERROR, "GScript2.init ()", "Memorizer error", e);
			throw new Exception ("Memorizer error", e);
		}
		
		// Evolution 
		HetEvolutionParameters ep = new HetEvolutionParameters (1, null);
		Step step = model.processEvolution(s.getRoot(),ep);
		
		HetScene finalScene = (HetScene) step.getScene();
		
		// Exports results in text files
		// 1. Results for trees
		try {
			File f = new File(outputDendroFile);
			if (f.exists() && count == 1) // delete existing exportFile if first simulation
				f.delete();
				
			BufferedWriter outDendro = new BufferedWriter(new FileWriter(outputDendroFile, true)); // true: to append at the end if file already exists

			// First line of the file
			if (count == 1) {
				outDendro.write("evolutionYear" + "\t" + "innerTreeId" + "\t" + "speciesName" + "\t" + "dbh" + "\t" + "height" + "\t" + "GPP" + "\t" + "NPP" + "\t" + "yearlyPotentialTranspiration" + "\t" + "yearlyTranspiration");
				outDendro.newLine();
			}
			
			Set sortedTrees = new TreeSet(new GTreeIdComparator());
			sortedTrees.addAll(finalScene.getTrees());
			
			Rectangle.Double innerZone = setInnerZone (initScene);
					
			for (Iterator i = sortedTrees.iterator(); i.hasNext();) {
				HetTree tree = (HetTree) i.next();
				
				if (tree.isVirtual())
					continue;
				
				if (!innerZone.contains(tree.getX(), tree.getY()))
					continue;
				
				outDendro.write(startYear+1 + "\t" + tree.getId() + "\t" + tree.getSpecies().getName() + "\t" + tree.getDbh() + "\t" + tree.getHeight() + "\t" + tree.getGrossPrimaryProduction_kgC() + "\t" + tree.getNetPrimaryProduction_kgC() + "\t" + tree.getYearlyPotentialTranspiration() + "\t" + tree.getYearlyTranspiration());
				outDendro.newLine();
			}

			outDendro.close();
		} catch (Exception e) {
			Log.println(Log.ERROR, "SimusCORDEX.runOneSimulation", "Could not write in file: " + outputDendroFile, e);
		}
		
		// 2. Results for water balance
		try {
			File f = new File(outputHydroFile);
			if (f.exists() && count == 1) // delete existing exportFile if first simulation
				f.delete();
						
			BufferedWriter outHydro = new BufferedWriter(new FileWriter(outputHydroFile, true)); // true to append at the end if file already exists

			Set<Integer> horizonIdsSet = finalScene.getSoil().getHorizonMap().keySet();
			// Sort horizon ids on ascending order
			Set<Integer> sortedHorizonIds = new TreeSet<>(horizonIdsSet);
					
			// First line of the file
			if (count == 1) {
				String columnNames = "evolutionYear" + "\t" + "month" + "\t" + "day" + "\t" + "rainfall (mm)" + "\t" + "stemflow (mm)" + "\t" + "throughfall (mm)" + "\t"
						+ "interception (mm)"
						+ "\t" + "transpiration (mm)" + "\t" + "standLevel_transpiration (mm)" + "\t" + "treeLevel_transpiration (mm)" + "\t" + "groundVegetationTranspiration (mm)"
						+ "\t" + "barkEvaporation (mm)" + "\t"
						+ "foliageEvaporation (mm)" + "\t" + "vegetationEvaporation (mm)" + "\t" + "soilEvaporation (mm)" + "\t"
						+ "deepDrainage (mm)" + "\t" + "relativeExtractableWater (mm.mm-1)" + "\t"
						+ "forestFloorRelativeExtractableWater (mm.mm-1)";
				for (int horizonId : sortedHorizonIds) {
					columnNames += "\t" + "horizonWaterContent (m3.m-3) for horizon " + horizonId + " - " + finalScene.getSoil().getHorizon(horizonId).name;
				}
				columnNames += "\t" + "waterContentStockVariation" + "\t" + "waterBalance";
						
				outHydro.write(columnNames);
				outHydro.newLine();
			}
					
			LinkedHashMap<String, HetWaterBalance> hourlyWaterBalanceMap = finalScene.waterBalanceMap;
			HetWaterBalanceIntegrator wbi = new HetWaterBalanceIntegrator(hourlyWaterBalanceMap, HetWaterBalanceIntegrator.DAY_LEVEL);
			// Daily waterbalance map (one entry per day) 
			// 		key: the year+month+day string 
			//		value: the waterbalance object containing physical variables summed and averaged over the day of the year
			LinkedHashMap<String, HetWaterBalance> dailyWaterBalanceMap = wbi.integrate();
			
			// Map with key: horizon's id, value: water content at previous day (at hour=23h of previous day)
			HashMap<Integer, Double> horizonIdPreviousWaterContentMap = new HashMap<Integer, Double>();
			// Value for initial scene (mean)
			for (HetHorizon horizon : initScene.getSoil().getHorizons()) {
				horizonIdPreviousWaterContentMap.put(horizon.id, horizon.meanWaterContent);
			}
			
			for (Iterator<String> i = dailyWaterBalanceMap.keySet().iterator(); i.hasNext();) {
				String key = i.next();
				HetWaterBalance wb = dailyWaterBalanceMap.get(key);
				
				// Last columns contains one value per horizon, separated by tabs
				// (horizons number may vary)
				// Sort horizon ids on ascending order
				Set<Integer> sortedHIds = new TreeSet<>(wb.horizonWaterContent.keySet());

				StringBuffer strBuffer = new StringBuffer();
				for (Iterator<Integer> j = sortedHIds.iterator(); j.hasNext();) {

					int hId = j.next();
					double v = wb.horizonWaterContent.get(hId);

					strBuffer.append(v);

					if (j.hasNext())
						strBuffer.append("\t");
				}
				String horizonWaterContents = strBuffer.toString();
				
				// Calculate water balance. nb-13.09.2017
				double waterContentStockVariation = 0.0;	
				
				for (int horizonId : sortedHIds) {

					HetHorizon horizon = finalScene.getSoil().getHorizon(horizonId);
//					LinkedHashMap<String, HetWaterBalance> hourlyWaterBalance = scene.waterBalanceMap;

					// waterContent is the value of water content at hour=23h of current day
					double waterContent = hourlyWaterBalanceMap.get(wb.year + "_" + wb.month + "_" + wb.day + "_23").horizonWaterContent.get(horizonId);
					double previousWaterContent = horizonIdPreviousWaterContentMap.get(horizonId); 

					waterContentStockVariation += (waterContent-previousWaterContent)*horizon.thickness*(1.0-horizon.coarseFraction)*1000.0;

					// Updates the previous water content for next hour. nb-13.09.2017
					horizonIdPreviousWaterContentMap.put(horizonId, waterContent);
					
				}

//				line.waterBalance = line.rainfall - (line.transpiration + line.vegetationEvaporation
//						+ line.soilEvaporation + line.deepDrainage + line.waterContentStockVariation);
				double waterBalance = wb.rainfall - (wb.transpiration + wb.interception
						+ wb.soilEvaporation + wb.deepDrainage + waterContentStockVariation); // mj+fa-26.09.2017
				
				outHydro.write(wb.year + "\t" + wb.month + "\t" + wb.day + "\t" + wb.rainfall + "\t" + wb.stemflow + "\t" + wb.throughfall + "\t"
						+ wb.interception
						+ "\t" + wb.transpiration + "\t" + wb.standLevel_transpiration + "\t" + wb.treeLevel_transpiration + "\t" + wb.groundVegetationTranspiration
						+ "\t" + wb.barkEvaporation + "\t"
						+ wb.foliageEvaporation + "\t" + wb.vegetationEvaporation + "\t" + wb.soilEvaporation + "\t"
						+ wb.deepDrainage + "\t" + wb.relativeExtractableWater + "\t"
						+ wb.forestFloorRelativeExtractableWater + "\t"
						+ horizonWaterContents + "\t"
						+ waterContentStockVariation + "\t"
						+ waterBalance);
				outHydro.newLine();
			}
					
							
//			for (Tree t : finalScene.getTrees()) {
//				HetTree tree = (HetTree) t;
//						
//				out.write(startYear + "\t" + tree.getId() + "\t" + tree.getDbh() + "\t" + tree.getHeight() + "\t" + tree.getGrossPrimaryProduction_kgC() + "\t" + tree.getNetPrimaryProduction_kgC() + "\t" + tree.getMaintenanceRespiration_kgC() + "\t" + tree.getYearlyPotentialTranspiration() + "\t" + tree.getYearlyTranspiration());
//				out.newLine();
//			}

			outHydro.close();
		} catch (Exception e) {
			Log.println(Log.ERROR, "SimusCORDEX.runOneSimulation", "Could not write in file: " + outputHydroFile, e);
		}

		
		s.closeProject();
	}
	
	private static Rectangle.Double setInnerZone (HetScene scene) throws Exception{
		
		double bufferWidth = 15; //m
			
		double x0 = scene.getOrigin().x;
		double y0 = scene.getOrigin().y;
		double w = scene.getXSize();
		double h = scene.getYSize();
			
		Rectangle.Double innerZone = new Rectangle.Double (x0 + bufferWidth, y0 + bufferWidth, w - 2 * bufferWidth, h - 2 * bufferWidth);
		
		return innerZone;
	}
	
	private static boolean stringToBool(String s) {
        s = s.toLowerCase();
        Set<String> trueSet = new HashSet<String>(Arrays.asList("1", "true", "yes"));
        Set<String> falseSet = new HashSet<String>(Arrays.asList("0", "false", "no"));

        if (trueSet.contains(s))
            return true;
        if (falseSet.contains(s))
            return false;

        throw new IllegalArgumentException(s + " is not a boolean.");
    }
}