# A script to perform optimization of HETEROFOR radiative balance and respiration parameters

# Modification Nicolas Beudez: The call to BayesianTools package is only needed for the first use of the script.
#install.packages("BayesianTools")
library("BayesianTools")

t_total_begin <- proc.time()[[3]] # 1: user time, 2: system time, 3: elapsed time

totalTimeInHeterofor <- 0
totalTimeForFilesReading <- 0

## Function launching Capsis simulations
# Function for optimization
Heterofor.Optimization_func <- function (CapsisDir, reconstructionExportFileName, simulationExportFileName, logFilePath, turbidMediumActivated, crownForm, ladOption, 
                                         extCoef_oak_arg, extCoef_beech_arg, extCoef_carpinus_arg, 
                                         SLAbottom_oak_arg, SLAbottom_beech_arg, SLAbottom_carpinus_arg,
                                         SLAtop_oak_arg, SLAtop_beech_arg, SLAtop_carpinus_arg,
                                         UFLB_oak_arg, UFLB_beech_arg, UFLB_carpinus_arg, 
                                         alpha_oak_arg, alpha_beech_arg, alpha_carpinus_arg, 
                                         beta_oak_arg, beta_beech_arg, beta_carpinus_arg,
                                         NppToGppRatio_intercept_oak_Baileux_arg, NppToGppRatio_intercept_beech_Baileux_arg, NppToGppRatio_intercept_carpinus_Baileux_arg,
                                         NppToGppRatio_slope_oak_Baileux_arg, NppToGppRatio_slope_beech_Baileux_arg, NppToGppRatio_slope_carpinus_Baileux_arg,
                                         NppToGppRatio_intercept_oak_Chimay_arg, NppToGppRatio_intercept_beech_Chimay_arg, NppToGppRatio_intercept_carpinus_Chimay_arg,
                                         NppToGppRatio_slope_oak_Chimay_arg, NppToGppRatio_slope_beech_Chimay_arg, NppToGppRatio_slope_carpinus_Chimay_arg,
                                         NppToGppRatio_intercept_oak_LLN_arg, NppToGppRatio_intercept_beech_LLN_arg, NppToGppRatio_intercept_carpinus_LLN_arg, 
                                         NppToGppRatio_slope_oak_LLN_arg, NppToGppRatio_slope_beech_LLN_arg, NppToGppRatio_slope_carpinus_LLN_arg,
                                         NppToGppRatio_intercept_oak_Virton_arg, NppToGppRatio_intercept_beech_Virton_arg, NppToGppRatio_intercept_carpinus_Virton_arg,
                                         NppToGppRatio_slope_oak_Virton_arg, NppToGppRatio_slope_beech_Virton_arg, NppToGppRatio_slope_carpinus_Virton_arg,
                                         reconstructionActivated_arg) {

  print("R --> begin Heterofor.Optimization_func")

  if (.Platform$OS.type == "windows") {
    cmd = paste("capsis -p script heterofor.myscripts.HetCalibrationScript_LADopt2", CapsisDir, reconstructionExportFileName, simulationExportFileName,
                turbidMediumActivated, crownForm, ladOption,
                extCoef_oak_arg, extCoef_beech_arg, extCoef_carpinus_arg,
                SLAbottom_oak_arg, SLAbottom_beech_arg, SLAbottom_carpinus_arg,
                SLAtop_oak_arg, SLAtop_beech_arg, SLAtop_carpinus_arg,
                UFLB_oak_arg, UFLB_beech_arg, UFLB_carpinus_arg,
                alpha_oak_arg, alpha_beech_arg, alpha_carpinus_arg,
                beta_oak_arg, beta_beech_arg, beta_carpinus_arg,
                NppToGppRatio_intercept_oak_Baileux_arg, NppToGppRatio_intercept_beech_Baileux_arg, NppToGppRatio_intercept_carpinus_Baileux_arg,
                NppToGppRatio_slope_oak_Baileux_arg, NppToGppRatio_slope_beech_Baileux_arg, NppToGppRatio_slope_carpinus_Baileux_arg,
                NppToGppRatio_intercept_oak_Chimay_arg, NppToGppRatio_intercept_beech_Chimay_arg, NppToGppRatio_intercept_carpinus_Chimay_arg,
                NppToGppRatio_slope_oak_Chimay_arg, NppToGppRatio_slope_beech_Chimay_arg, NppToGppRatio_slope_carpinus_Chimay_arg,
                NppToGppRatio_intercept_oak_LLN_arg, NppToGppRatio_intercept_beech_LLN_arg, NppToGppRatio_intercept_carpinus_LLN_arg,
                NppToGppRatio_slope_oak_LLN_arg, NppToGppRatio_slope_beech_LLN_arg, NppToGppRatio_slope_carpinus_LLN_arg,
                NppToGppRatio_intercept_oak_Virton_arg, NppToGppRatio_intercept_beech_Virton_arg, NppToGppRatio_intercept_carpinus_Virton_arg,
                NppToGppRatio_slope_oak_Virton_arg, NppToGppRatio_slope_beech_Virton_arg, NppToGppRatio_slope_carpinus_Virton_arg,
                reconstructionActivated_arg,
                "2>&1 >", logFilePath,
                sep = " ");
  } else {
    cmd = paste("sh capsis.sh -p script heterofor.myscripts.HetCalibrationScript_LADopt2", CapsisDir, reconstructionExportFileName, simulationExportFileName,
                turbidMediumActivated, crownForm, ladOption,
                extCoef_oak_arg, extCoef_beech_arg, extCoef_carpinus_arg,
                SLAbottom_oak_arg, SLAbottom_beech_arg, SLAbottom_carpinus_arg,
                SLAtop_oak_arg, SLAtop_beech_arg, SLAtop_carpinus_arg,
                UFLB_oak_arg, UFLB_beech_arg, UFLB_carpinus_arg,
                alpha_oak_arg, alpha_beech_arg, alpha_carpinus_arg,
                beta_oak_arg, beta_beech_arg, beta_carpinus_arg,
                NppToGppRatio_intercept_oak_Baileux_arg, NppToGppRatio_intercept_beech_Baileux_arg, NppToGppRatio_intercept_carpinus_Baileux_arg,
                NppToGppRatio_slope_oak_Baileux_arg, NppToGppRatio_slope_beech_Baileux_arg, NppToGppRatio_slope_carpinus_Baileux_arg,
                NppToGppRatio_intercept_oak_Chimay_arg, NppToGppRatio_intercept_beech_Chimay_arg, NppToGppRatio_intercept_carpinus_Chimay_arg,
                NppToGppRatio_slope_oak_Chimay_arg, NppToGppRatio_slope_beech_Chimay_arg, NppToGppRatio_slope_carpinus_Chimay_arg,
                NppToGppRatio_intercept_oak_LLN_arg, NppToGppRatio_intercept_beech_LLN_arg, NppToGppRatio_intercept_carpinus_LLN_arg,
                NppToGppRatio_slope_oak_LLN_arg, NppToGppRatio_slope_beech_LLN_arg, NppToGppRatio_slope_carpinus_LLN_arg,
                NppToGppRatio_intercept_oak_Virton_arg, NppToGppRatio_intercept_beech_Virton_arg, NppToGppRatio_intercept_carpinus_Virton_arg,
                NppToGppRatio_slope_oak_Virton_arg, NppToGppRatio_slope_beech_Virton_arg, NppToGppRatio_slope_carpinus_Virton_arg,
                reconstructionActivated_arg,
                "2>&1 >", logFilePath,
                sep = " ");
  }

  print(cmd)

  t1_begin <- proc.time()[[3]] # 1: user time, 2: system time, 3: elapsed time

  if (.Platform$OS.type == "windows") {
    shell(cmd);
  } else{
    system(cmd);
  }

  t1_end <- proc.time()[[3]] # 1: user time, 2: system time, 3: elapsed time
  t1_time <- t1_end-t1_begin
  totalTimeInHeterofor <- totalTimeInHeterofor + t1_time

  print("R -->          time elapsed in Heterofor:")
  print(t1_time)
  print("R -->          total time elapsed in Heterofor:")
  print(totalTimeInHeterofor)

  t2_begin <- proc.time()[[3]] # 1: user time, 2: system time, 3: elapsed time

  ReconstructionDataFile <- read.table(reconstructionExportFileName, header = TRUE)
  SimulationDataFile <- read.table(simulationExportFileName, header = TRUE)
 
  RecSim <- cbind(ReconstructionDataFile$plotName, ReconstructionDataFile$year, ReconstructionDataFile$treeId, ReconstructionDataFile$NPP, SimulationDataFile$plotName, SimulationDataFile$year, SimulationDataFile$treeId, SimulationDataFile$NPP)

  t2_end <- proc.time()[[3]] # 1: user time, 2: system time, 3: elapsed time
  t2_time <- t2_end-t2_begin
  totalTimeForFilesReading <- totalTimeForFilesReading + t2_time

  print("R -->          time elapsed for files reading:")
  print(t2_time)
  print("R -->          total time elapsed for files reading:")
  print(totalTimeForFilesReading)

  print("R --> end Heterofor.Optimization_func")

  return(RecSim)
}


likelihood <- function(p) {
  
  extCoef_oak = p[1]
  extCoef_beech = p[2]
  extCoef_carpinus = p[3]
  
  # SLAbottom_oak = p[1]
  # SLAbottom_beech = p[2]
  # SLAbottom_carpinus = p[3]
  
  # SLAtop_oak = p[1]
  # SLAtop_beech = p[2]
  # SLAtop_carpinus = p[3]
  
  UFLB_oak = p[4]
  UFLB_beech = p[5]
  UFLB_carpinus = p[6]
  
  alpha_oak = 10^(p[7])
  alpha_beech = 10^(p[8])
  alpha_carpinus = 10^(p[9])
  
  beta_oak = 2.0
  beta_beech = 2.0
  beta_carpinus = 2.0
  
  NppToGppRatio_intercept_oak_Baileux = p[10]
  NppToGppRatio_intercept_beech_Baileux = p[11] 
  NppToGppRatio_intercept_carpinus_Baileux = p[12]
  
  NppToGppRatio_slope_oak_Baileux = p[22]
  NppToGppRatio_slope_beech_Baileux = p[23] 
  NppToGppRatio_slope_carpinus_Baileux = p[24]
  
  NppToGppRatio_intercept_oak_Chimay = p[13]
  NppToGppRatio_intercept_beech_Chimay = p[14] 
  NppToGppRatio_intercept_carpinus_Chimay = p[15]
  
  NppToGppRatio_slope_oak_Chimay = p[22]
  NppToGppRatio_slope_beech_Chimay = p[23] 
  NppToGppRatio_slope_carpinus_Chimay = p[24]
  
  NppToGppRatio_intercept_oak_LLN = p[16]
  NppToGppRatio_intercept_beech_LLN = p[17] 
  NppToGppRatio_intercept_carpinus_LLN = p[18]
  
  NppToGppRatio_slope_oak_LLN = p[22]
  NppToGppRatio_slope_beech_LLN = p[23] 
  NppToGppRatio_slope_carpinus_LLN = p[24]
  
  NppToGppRatio_intercept_oak_Virton = p[19]
  NppToGppRatio_intercept_beech_Virton = p[20] 
  NppToGppRatio_intercept_carpinus_Virton = p[21]
  
  NppToGppRatio_slope_oak_Virton = p[22]
  NppToGppRatio_slope_beech_Virton = p[23] 
  NppToGppRatio_slope_carpinus_Virton = p[24]
  
  measSigma = p[25]

  
  RecSim <- Heterofor.Optimization_func(CapsisDir, reconstructionExportFileName, simulationExportFileName, logFilePath, turbidMediumActivated, crownForm, ladOption, 
                                        extCoef_oak, extCoef_beech, extCoef_carpinus,
                                        SLAbottom_oak, SLAbottom_beech, SLAbottom_carpinus,
                                        SLAtop_oak, SLAtop_beech, SLAtop_carpinus,
                                        UFLB_oak, UFLB_beech, UFLB_carpinus,
                                        alpha_oak, alpha_beech, alpha_carpinus,
                                        beta_oak, beta_beech, beta_carpinus,
                                        NppToGppRatio_intercept_oak_Baileux, NppToGppRatio_intercept_beech_Baileux, NppToGppRatio_intercept_carpinus_Baileux,
                                        NppToGppRatio_slope_oak_Baileux, NppToGppRatio_slope_beech_Baileux, NppToGppRatio_slope_carpinus_Baileux,
                                        NppToGppRatio_intercept_oak_Chimay, NppToGppRatio_intercept_beech_Chimay, NppToGppRatio_intercept_carpinus_Chimay,
                                        NppToGppRatio_slope_oak_Chimay, NppToGppRatio_slope_beech_Chimay, NppToGppRatio_slope_carpinus_Chimay, 
                                        NppToGppRatio_intercept_oak_LLN, NppToGppRatio_intercept_beech_LLN, NppToGppRatio_intercept_carpinus_LLN,
                                        NppToGppRatio_slope_oak_LLN, NppToGppRatio_slope_beech_LLN, NppToGppRatio_slope_carpinus_LLN,
                                        NppToGppRatio_intercept_oak_Virton, NppToGppRatio_intercept_beech_Virton, NppToGppRatio_intercept_carpinus_Virton,
                                        NppToGppRatio_slope_oak_Virton, NppToGppRatio_slope_beech_Virton, NppToGppRatio_slope_carpinus_Virton,
                                        reconstructionActivated)
      Rec <- as.numeric(RecSim[,4])
      Sim <- as.numeric(RecSim[,8])

      residuals <- Sim - Rec
      
      llValues <- dnorm(residuals, sd = measSigma, log = TRUE) # corresponds to lik 12 in Table B1 of Vrugt EMS2016 p.307
      
      return(sum(llValues))

}


## Main program

# # Slurm job IDs
# s = as.numeric(Sys.getenv("SLURM_ARRAY_TASK_ID")) # Job array index
# jobId = as.character(Sys.getenv("SLURM_ARRAY_JOB_ID"))
# taskId = as.character(Sys.getenv("SLURM_ARRAY_TASK_ID"))

## A. Set working environment
# Capsis install directory
if (.Platform$OS.type == "windows"){
  CapsisDir = "C:/Capsis4/"
} else {
  homePath = system("echo $HOME", intern = TRUE)

  # Modification Nicolas Beudez
  #CapsisDir = paste(homePath, "/Capsis4/", sep = "")
  CapsisDir = paste(homePath, "/workspace/capsis4/", sep = "")
}
setwd(CapsisDir) # Set working directory


## B. Optimization configuration
# Settings (considered as common to all species)
turbidMediumActivated <- "true"
# crownFormVector <- c("Bc","Bd","M")
# crownForm <- crownFormVector[s]
crownForm <- "M" # Bc, Bd or M
ladOption <- 2 #0: mean LAD, 1: mean SLA, 2: SLA model, 3: Quergus LAD
settingString = paste("/",crownForm,"_TM",turbidMediumActivated,"_LADopt",as.character(ladOption),"_NPP_RatioNppGpp_logLIKE", sep = "")

logFileName = paste("logFile_LADopt",as.character(ladOption),"_crownForm",crownForm,".txt", sep = "")

# Modification Nicolas Beudez: writes log file in capsis4/var directory.
#logFilePath = paste(CapsisDir,"/",logFileName, sep = "")
logFilePath = paste(CapsisDir,"var/",logFileName, sep = "")
#sprintf("logFilePath: %s", logFilePath)

# Export filename for Capsis output
script.name <- basename(strsplit(commandArgs(trailingOnly = FALSE)[4],"=")[[1]][2])
script.name <- substr(script.name,1,nchar(script.name)-2)

# Modification Nicolas Beudez: a "/" in excess
#outputDirPath = paste(CapsisDir, "/src/heterofor/myscripts/CalibrationOutputs/DREAMzs", settingString, sep = "")
outputDirPath = paste(CapsisDir, "src/heterofor/myscripts/CalibrationOutputs/DREAMzs", settingString, sep = "")
#sprintf("outputDirPath: %s", outputDirPath)

reconstructionExportFileName = paste("Reconstruction_", script.name, crownForm, ".out", sep = "")
simulationExportFileName = paste("Simulation_", script.name, crownForm, ".out", sep = "")

# Modification Nicolas Beudez: the following line generated an error.
#dir.create(outputDirPath)
dir.create(outputDirPath, recursive = TRUE)



# Set initial guesses to parameter values from speciesFile
# 1-Read speciesFile
speciesFile <- paste("/data/heterofor/inventories/CalibNPP/heterofor_species_", crownForm, ".txt", sep = "")
speciesParameters <- data.frame()
con <- file(paste(CapsisDir, speciesFile, sep = ""), open = "r")
conLine <- scan(con, character(0), nlines = 1, sep = "\t", quiet = TRUE)
while (conLine[1] != "# speciesId"){
  conLine <- scan(con, character(0), nlines = 1, sep = "\t", quiet = TRUE)
}
parameterNames <- conLine

options(stringsAsFactors=FALSE)
for (l in 1:6){ # Read species parameters
  conLine <- scan(con, character(0), nlines = 1, sep = "\t", quiet = TRUE)
  speciesParameters <- rbind(speciesParameters, conLine)
}
names(speciesParameters) <- parameterNames
close(con)
# 2-Set initial guesses
extCoef_oak <- as.double(speciesParameters$extinctionCoefficient[1])
extCoef_beech <- as.double(speciesParameters$extinctionCoefficient[2])
extCoef_carpinus <- as.double(speciesParameters$extinctionCoefficient[3])

SLAbottom_oak <- as.double(speciesParameters$SLAbottom[1])
SLAbottom_beech <- as.double(speciesParameters$SLAbottom[2])
SLAbottom_carpinus <- as.double(speciesParameters$SLAbottom[3])

SLAtop_oak <- as.double(speciesParameters$SLAtop[1])
SLAtop_beech <- as.double(speciesParameters$SLAtop[2])
SLAtop_carpinus <- as.double(speciesParameters$SLAtop[3])

UFLB_oak <- as.double(speciesParameters$UFLB[1])
UFLB_beech <- as.double(speciesParameters$UFLB[2])
UFLB_carpinus <- as.double(speciesParameters$UFLB[3])

# oak
strLeafBiom_oak <- speciesParameters$leafBiomassAllometry[1]
indexBracket <- gregexpr("(", strLeafBiom_oak, fixed=TRUE)[[1]][1] #index of character "("
indexComa1 <- gregexpr(";", strLeafBiom_oak, fixed=TRUE)[[1]][1] #index of first ";"
indexComa2 <- gregexpr(";", strLeafBiom_oak, fixed=TRUE)[[1]][2] #index of second ";"
alpha_oak <- as.double(substr(strLeafBiom_oak, indexBracket+1, indexComa1-1))
beta_oak <- as.double(substr(strLeafBiom_oak, indexComa1+1, indexComa2-1))
# beech
strLeafBiom_beech <- speciesParameters$leafBiomassAllometry[2]
indexBracket <- gregexpr("(", strLeafBiom_beech, fixed=TRUE)[[1]][1] #index of character "("
indexComa1 <- gregexpr(";", strLeafBiom_beech, fixed=TRUE)[[1]][1] #index of first ";"
indexComa2 <- gregexpr(";", strLeafBiom_beech, fixed=TRUE)[[1]][2] #index of second ";"
alpha_beech <- as.double(substr(strLeafBiom_beech, indexBracket+1, indexComa1-1))
beta_beech <- as.double(substr(strLeafBiom_beech, indexComa1+1, indexComa2-1))
# carpinus
strLeafBiom_carpinus <- speciesParameters$leafBiomassAllometry[3]
indexBracket <- gregexpr("(", strLeafBiom_carpinus, fixed=TRUE)[[1]][1] #index of character "("
indexComa1 <- gregexpr(";", strLeafBiom_carpinus, fixed=TRUE)[[1]][1] #index of first ";"
indexComa2 <- gregexpr(";", strLeafBiom_carpinus, fixed=TRUE)[[1]][2] #index of second ";"
alpha_carpinus <- as.double(substr(strLeafBiom_carpinus, indexBracket+1, indexComa1-1))
beta_carpinus <- as.double(substr(strLeafBiom_carpinus, indexComa1+1, indexComa2-1))

NppToGppRatio_intercept_oak_Baileux <- as.double(speciesParameters$nppToGppRatio_intercept[1])
NppToGppRatio_intercept_beech_Baileux <- as.double(speciesParameters$nppToGppRatio_intercept[2])
NppToGppRatio_intercept_carpinus_Baileux <- as.double(speciesParameters$nppToGppRatio_intercept[3])

NppToGppRatio_slope_oak_Baileux <- as.double(speciesParameters$nppToGppRatio_slope[1])
NppToGppRatio_slope_beech_Baileux <- as.double(speciesParameters$nppToGppRatio_slope[2])
NppToGppRatio_slope_carpinus_Baileux <- as.double(speciesParameters$nppToGppRatio_slope[3])

NppToGppRatio_intercept_oak_Chimay <- as.double(speciesParameters$nppToGppRatio_intercept[1])
NppToGppRatio_intercept_beech_Chimay <- as.double(speciesParameters$nppToGppRatio_intercept[2])
NppToGppRatio_intercept_carpinus_Chimay <- as.double(speciesParameters$nppToGppRatio_intercept[3])

NppToGppRatio_slope_oak_Chimay <- as.double(speciesParameters$nppToGppRatio_slope[1])
NppToGppRatio_slope_beech_Chimay <- as.double(speciesParameters$nppToGppRatio_slope[2])
NppToGppRatio_slope_carpinus_Chimay <- as.double(speciesParameters$nppToGppRatio_slope[3])

NppToGppRatio_intercept_oak_LLN <- as.double(speciesParameters$nppToGppRatio_intercept[1])
NppToGppRatio_intercept_beech_LLN <- as.double(speciesParameters$nppToGppRatio_intercept[2])
NppToGppRatio_intercept_carpinus_LLN <- as.double(speciesParameters$nppToGppRatio_intercept[3])

NppToGppRatio_slope_oak_LLN <- as.double(speciesParameters$nppToGppRatio_slope[1])
NppToGppRatio_slope_beech_LLN <- as.double(speciesParameters$nppToGppRatio_slope[2])
NppToGppRatio_slope_carpinus_LLN <- as.double(speciesParameters$nppToGppRatio_slope[3])

NppToGppRatio_intercept_oak_Virton <- as.double(speciesParameters$nppToGppRatio_intercept[1])
NppToGppRatio_intercept_beech_Virton <- as.double(speciesParameters$nppToGppRatio_intercept[2])
NppToGppRatio_intercept_carpinus_Virton <- as.double(speciesParameters$nppToGppRatio_intercept[3])

NppToGppRatio_slope_oak_Virton <- as.double(speciesParameters$nppToGppRatio_slope[1])
NppToGppRatio_slope_beech_Virton <- as.double(speciesParameters$nppToGppRatio_slope[2])
NppToGppRatio_slope_carpinus_Virton <- as.double(speciesParameters$nppToGppRatio_slope[3])

initGuess <- c(extCoef_oak, extCoef_beech, extCoef_carpinus,
               SLAbottom_oak, SLAbottom_beech, SLAbottom_carpinus, 
               SLAtop_oak, SLAtop_beech, SLAtop_carpinus,
               UFLB_oak, UFLB_beech, UFLB_carpinus,
               alpha_oak, alpha_beech, alpha_carpinus,
               beta_oak, beta_beech, beta_carpinus,
               NppToGppRatio_intercept_oak_Baileux, NppToGppRatio_intercept_beech_Baileux, NppToGppRatio_intercept_carpinus_Baileux,
               NppToGppRatio_slope_oak_Baileux, NppToGppRatio_slope_beech_Baileux, NppToGppRatio_slope_carpinus_Baileux,
               NppToGppRatio_intercept_oak_Chimay, NppToGppRatio_intercept_beech_Chimay, NppToGppRatio_intercept_carpinus_Chimay,
               NppToGppRatio_slope_oak_Chimay, NppToGppRatio_slope_beech_Chimay, NppToGppRatio_slope_carpinus_Chimay,
               NppToGppRatio_intercept_oak_LLN, NppToGppRatio_intercept_beech_LLN, NppToGppRatio_intercept_carpinus_LLN,
               NppToGppRatio_slope_oak_LLN, NppToGppRatio_slope_beech_LLN, NppToGppRatio_slope_carpinus_LLN,
               NppToGppRatio_intercept_oak_Virton, NppToGppRatio_intercept_beech_Virton, NppToGppRatio_intercept_carpinus_Virton,
               NppToGppRatio_slope_oak_Virton, NppToGppRatio_slope_beech_Virton, NppToGppRatio_slope_carpinus_Virton)

# 3-Optimization bounds
LB <- c(0.01, 0.01, 0.01,  # extCoef
        0.01, 0.01, 0.01,  # UFLB
        -3.0, -0.5, -0.5,  # alpha
        0.35, 0.35, 0.35,  # NppToGppRatio_int_Baileux
        0.35, 0.35, 0.35,  # NppToGppRatio_int_Chimay
        0.35, 0.35, 0.35,  # NppToGppRatio_int_LLN
        0.35, 0.35, 0.35,  # NppToGppRatio_int_Virton
        -0.4, -0.4, -0.4,  # NppToGppRatio_slope_all
        0.1)               # measSigma

UB <- c(1.20, 1.20, 1.20,  # ext_coef
        0.99, 0.99, 0.99,  # UFLB
        -2.0, 0.80, 0.80,  # alpha
        1.10, 1.10, 1.10,  # NppToGppRatio_int_Baileux
        1.10, 1.10, 1.10,  # NppToGppRatio_int_Chimay
        1.10, 1.10, 1.10,  # NppToGppRatio_int_LLN
        1.10, 1.10, 1.10,  # NppToGppRatio_int_Virton
        0.00, 0.00, 0.00,  # NppToGppRatio_slope_all
        30.0)              # measSigma

parNames <- c("extCoef_oak","extCoef_beech","extCoef_carpinus",
              "UFLB_oak","UFLB_beech","UFLB_carpinus",
              "alpha_oak","alpha_beech","alpha_carpinus",
              "NppToGppRatio_int_oak_Baileux","NppToGppRatio_int_beech_Baileux","NppToGppRatio_int_carpinus_Baileux",
              "NppToGppRatio_int_oak_Chimay","NppToGppRatio_int_beech_Chimay","NppToGppRatio_int_carpinus_Chimay",
              "NppToGppRatio_int_oak_LLN","NppToGppRatio_int_beech_LLN","NppToGppRatio_int_carpinus_LLN",
              "NppToGppRatio_int_oak_Virton","NppToGppRatio_int_beech_Virton","NppToGppRatio_int_carpinus_Virton",
              "NppToGppRatio_slope_oak_all","NppToGppRatio_slope_beech_all","NppToGppRatio_slope_carpinus_all",
              "measSigma")


# 4-Optimization

# First run for computation of reconstruction
reconstructionActivated <- "true"

print("R --> avant Heterofor.Optimization_func")
sprintf("R --> reconstructionExportFileName: %s", reconstructionExportFileName)

RecSim_init <- Heterofor.Optimization_func(CapsisDir, reconstructionExportFileName, simulationExportFileName, logFilePath, turbidMediumActivated, crownForm, ladOption,
                                           extCoef_oak, extCoef_beech, extCoef_carpinus,
                                           SLAbottom_oak, SLAbottom_beech, SLAbottom_carpinus,
                                           SLAtop_oak, SLAtop_beech, SLAtop_carpinus,
                                           UFLB_oak, UFLB_beech, UFLB_carpinus, 
                                           alpha_oak, alpha_beech, alpha_carpinus,
                                           beta_oak, beta_beech, beta_carpinus,
                                           NppToGppRatio_intercept_oak_Baileux, NppToGppRatio_intercept_beech_Baileux, NppToGppRatio_intercept_carpinus_Baileux,
                                           NppToGppRatio_slope_oak_Baileux, NppToGppRatio_slope_beech_Baileux, NppToGppRatio_slope_carpinus_Baileux,
                                           NppToGppRatio_intercept_oak_Chimay, NppToGppRatio_intercept_beech_Chimay, NppToGppRatio_intercept_carpinus_Chimay,
                                           NppToGppRatio_slope_oak_Chimay, NppToGppRatio_slope_beech_Chimay, NppToGppRatio_slope_carpinus_Chimay,
                                           NppToGppRatio_intercept_oak_LLN, NppToGppRatio_intercept_beech_LLN, NppToGppRatio_intercept_carpinus_LLN, 
                                           NppToGppRatio_slope_oak_LLN, NppToGppRatio_slope_beech_LLN, NppToGppRatio_slope_carpinus_LLN,
                                           NppToGppRatio_intercept_oak_Virton, NppToGppRatio_intercept_beech_Virton, NppToGppRatio_intercept_carpinus_Virton,
                                           NppToGppRatio_slope_oak_Virton, NppToGppRatio_slope_beech_Virton, NppToGppRatio_slope_carpinus_Virton,
                                           reconstructionActivated)

print("R --> apres Heterofor.Optimization_func")
reconstructionActivated <- "false" # Computation of reconstruction not necessary after first run

prior <- createUniformPrior(lower = LB, upper = UB)
bayesianSetup <- createBayesianSetup(likelihood, prior, names = parNames)

# Modif Nicolas Beudez: initially iterations = 30000
settings = list(iterations = 10, nCR = 3, gamma = NULL, eps = 0, e = 0.05, pCRupdate = TRUE, updateInterval = 10, burnin = 0, thin = 1, adaptation = 0.2, parallel = NULL, Z = NULL, ZupdateFrequency = 10, pSnooker = 0.1, DEpairs = 2, consoleUpdates = 10, startValue = NULL, currentChain = 1, message = TRUE)

out <- runMCMC(bayesianSetup = bayesianSetup, sampler = "DREAMzs", settings = settings)

OutputFileName = paste(outputDirPath,"/CalibrationResults.RData", sep = "")
save(out, file = OutputFileName)

t_total_end <- proc.time()[[3]] # 1: user time, 2: system time, 3: elapsed time

total_time <- t_total_end-t_total_begin
print("R -->total time elapsed:")
print(total_time)






