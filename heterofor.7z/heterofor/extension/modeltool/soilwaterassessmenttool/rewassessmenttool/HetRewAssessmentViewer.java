/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.extension.modeltool.soilwaterassessmenttool.rewassessmenttool;

import heterofor.extension.modeltool.soilwaterassessmenttool.HetSoilWaterAssessmentViewer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;

import javax.swing.JButton;
import javax.swing.JLabel;

import jeeb.lib.util.ColumnPanel;
import jeeb.lib.util.LinePanel;
import jeeb.lib.util.Translator;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYSeriesCollection;

/**
 * This class allows to display the values of observed and simulated relative extractable water (REW).
 *
 * @author N. Beudez - October 2017
 */
public class HetRewAssessmentViewer extends HetSoilWaterAssessmentViewer implements ActionListener {

	static {
		Translator.addBundle("heterofor.extension.modeltool.soilwaterassessmenttool.HetSoilWaterAssessmentTool");
	}

	// The relative extractable water assessment tool
	private HetRewAssessmentTool tool;

	// Graph part
	JButton openFloatingTableButton;
	
	/**
	 * Constructor.
	 * 
	 * @param dataSet The set containing series of observed and simulated REW values
	 * @param tool The reference to the relative extractable water assessment tool 
	 */
	public HetRewAssessmentViewer(XYSeriesCollection dataSet, HetRewAssessmentTool tool) {		

		// Initialization
		this.dataSet = dataSet;
		this.tool = tool;

		createUI();
	}
	
	/**
	 * Creates the user interface.
	 */
	private void createUI() {

		ColumnPanel columnPanel = new ColumnPanel(8, 8);

		// Creates the label containing the name of the choosen observations file
		LinePanel observationFileNameLinePanel = new LinePanel();
		JLabel choosenObservationFileNameLabel = new JLabel(Translator.swap("HetSoilWaterAssessmentTool.observationFileName") + " : " + tool.getObservationFileName());
		observationFileNameLinePanel.add(choosenObservationFileNameLabel);
		observationFileNameLinePanel.addGlue();
		columnPanel.add(observationFileNameLinePanel);
		
		// Creates the chart: REW (observed and simulated values) over time per horizon
		JFreeChart chart = createXYLineChart();
		ChartPanel chartPanel = new ChartPanel(chart);
		columnPanel.add(chartPanel);
		
		// Creates the button allowing to see the values of the chart in a floating table
		LinePanel createFloatingTableLinePanel = new LinePanel();
		openFloatingTableButton = new JButton(Translator.swap("HetSoilWaterAssessmentTool.seeResultsInAFloatingTable"));
		openFloatingTableButton.addActionListener(this);
		createFloatingTableLinePanel.add(openFloatingTableButton);
		createFloatingTableLinePanel.addGlue();
		columnPanel.add(createFloatingTableLinePanel);
		columnPanel.addStrut0();
		
		// Adds the column panel in the north of the viewer panel. The BorderLayout.NORTH layout is chosen 
		// in order the free space below the chart can grow if the dialog box is enlarged manually by the user.
		this.setLayout(new BorderLayout());
		this.add(columnPanel, BorderLayout.NORTH);		
	}
	
	/**
	 * Creates a XY line chart given the data set.
	 */
	private JFreeChart createXYLineChart() {

		// Creates chart
		JFreeChart chart = ChartFactory.createXYLineChart(
				   Translator.swap("HetRewAssessmentViewer.graphTitle"), // title
				   Translator.swap("HetRewAssessmentViewer.graphXAxisLabel"), // x-axis Label
				   Translator.swap("HetRewAssessmentViewer.graphYAxisLabel"), // y-axis Label
				   dataSet, // dataset
				   PlotOrientation.VERTICAL, // plot orientation
				   true, // show legend
				   false, // configure chart to generate tool tips ?
				   false // configure chart to generate URLs ?
				);

		// Customizes renderer: displays the points of curves with a smaller size
		XYPlot plot = chart.getXYPlot();
		
		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer() {

			/**
			 * Shape scaling (dynamic override)
			 */
			public Shape getItemShape(int row, int column) {
				
				Shape shape = super.getItemShape(row, column);
				
				double scale = 0.5;
				AffineTransform t = new AffineTransform();
				t.scale(scale, scale);

				Shape newShape = t.createTransformedShape(shape);
				
				return newShape;
			}

		};

		// Fixes colors
		renderer.setSeriesPaint(0, Color.BLUE); // series #0: observed values
		renderer.setSeriesPaint(1, Color.RED);  // series #1: simulated values

		plot.setRenderer(renderer);
		
		return chart;
	}

	/**
	 * From ActionListener interface.
	 */
	@Override
	public void actionPerformed(ActionEvent evt) {

		if (evt.getSource().equals(openFloatingTableButton)) {
			openFloatingTableAction(Translator.swap("HetRewAssessmentViewer.tableTitle"), 
									Translator.swap("HetRewAssessmentViewer.xName"), 
									Translator.swap("HetRewAssessmentViewer.xUnit"), 
									Translator.swap("HetRewAssessmentViewer.yUnit"));
		}
	}

}