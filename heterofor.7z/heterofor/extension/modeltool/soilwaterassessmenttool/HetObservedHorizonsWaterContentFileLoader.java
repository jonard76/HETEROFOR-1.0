/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.extension.modeltool.soilwaterassessmenttool;

import java.util.List;

import jeeb.lib.util.Record;
import jeeb.lib.util.fileloader.FileLoader;

/**
 * A loader for a file containing hourly or daily water content records for different soil horizons.
 * 
 * @author N. Beudez - October 2017
 */
public class HetObservedHorizonsWaterContentFileLoader extends FileLoader {
	
	public List<HorizonHourlyWaterContentRecord> horizonHourlyWaterContentList;
	public List<HorizonDailyWaterContentRecord> horizonDailyWaterContentList;
	
	/**
	 * A hourly water content record for an horizon.
	 * 
	 * @author N. Beudez - September 2017
	 */
	static public class HorizonHourlyWaterContentRecord extends Record {

		public int horizonId;
		public int year;
		public int month;
		public int day;
		public int hour;
		public double waterContent;

		/**
		 * Constructor
		 */
		public HorizonHourlyWaterContentRecord(String line) throws Exception {

			super(line);
		}
	}
	
	/**
	 * A daily water content record for an horizon.
	 * 
	 * @author N. Beudez - September 2017
	 */
	static public class HorizonDailyWaterContentRecord extends Record {

		public int horizonId;
		public int year;
		public int month;
		public int day;
		public double waterContent;

		/**
		 * Constructor
		 */
		public HorizonDailyWaterContentRecord(String line) throws Exception {

			super(line);
		}
	}

	/**
	 * Constructor
	 */
	public HetObservedHorizonsWaterContentFileLoader() throws Exception {
		super ();
	}


	@Override
	protected void checks() throws Exception {
		// TODO FP Auto-generated method stub
		
	}	
	
}
