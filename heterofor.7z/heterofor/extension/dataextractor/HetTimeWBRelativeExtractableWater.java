/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.extension.dataextractor;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Vector;

import capsis.extension.dataextractor.format.DFListOfXYSeries;
import capsis.extension.dataextractor.superclass.AbstractDataExtractor;
import capsis.extension.datarenderer.drgraph.DRGraph;
import capsis.kernel.GModel;
import capsis.kernel.Step;
import capsis.util.Calendar;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetWaterBalance;
import heterofor.model.HetWaterBalanceIntegrator;
import heterofor.model.meteorology.HetMeteorology;
import jeeb.lib.util.Log;
import jeeb.lib.util.Translator;
import jeeb.lib.util.XYSeries;

/**
 * Relative extractable water over time.
 * 
 * @author F. de Coligny - March 2017
 */
public class HetTimeWBRelativeExtractableWater extends AbstractDataExtractor implements DFListOfXYSeries {

	static {
		Translator.addBundle("heterofor.extension.dataextractor.DELabels");
	}

	// nb-13.08.2018
	//public static final String NAME = Translator.swap("HetTimeWBRelativeExtractableWater");
	//public static final String DESCRIPTION = Translator.swap("HetTimeWBRelativeExtractableWater.description");
	//public static final String AUTHOR = "F. de Coligny, M. Jonard";
	//public static final String VERSION = "1.0";

	protected List<XYSeries> listOfXYSeries;

	/**
	 * Constructor.
	 */
	public HetTimeWBRelativeExtractableWater() {
	}

	@Override
	public void init(GModel m, Step s) throws Exception {
		super.init(m, s);

		try {
			// Nothing more, no configuration at this time
		} catch (Exception e) {
			Log.println(Log.ERROR, "HetTimeWBRelativeExtractableWater.init ()", "Exception", e);
			throw e;
		}

	}

	/**
	 * Extension dynamic compatibility mechanism. This matchwith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		return referent instanceof HetModel;
	}

	/**
	 * All extractors must be able to return their name. The caller can try to
	 * translate it with Translator.swap (name) if necessary (ex: gui renderer
	 * translates, file writer does not).
	 */
	public String getName() {
		return getNamePrefix() + Translator.swap("HetTimeWBRelativeExtractableWater.name");
	}

	@Override
	public String getAuthor() {
		return "F. de Coligny, M. Jonard";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetTimeWBRelativeExtractableWater.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * All extractors must be able to return their default data renderer class
	 * name.
	 */
	public String getDefaultDataRendererClassName() { // in DataFormat
		return DRGraph.class.getName();
	}

	/**
	 * This method is called by superclass DataExtractor constructor. If
	 * previous config was saved in a file, this method may not be called. See
	 * etc/extensions.settings file
	 */
	public void setConfigProperties() {
		
		// Config properties
		addBooleanProperty("HetTimeWBRelativeExtractableWater.forestFloorRelativeExtractableWater", true);
		
		
	}

	/**
	 * From DataExtractor SuperClass.
	 * 
	 * Computes the data series. This is the real output building. It refers to
	 * a reference Step.
	 * 
	 * Return false if trouble while extracting.
	 */
	public boolean doExtraction() {

		if (upToDate)
			return true;

		if (step == null)
			return false;

		try {

			LinkedHashMap<String, HetWaterBalance> fullWBMap = new LinkedHashMap<>();

			// Retrieve Steps from root to reference step
			Vector steps = step.getProject().getStepsFromRoot(step);

			XYSeries xy1s = new XYSeries(Translator.swap("HetTimeWBRelativeExtractableWater.relativeExtractableWater"), Color.BLACK);
			XYSeries xy2s = new XYSeries(Translator.swap("HetTimeWBRelativeExtractableWater.forestFloorRelativeExtractableWater"), Color.GREEN);

			listOfXYSeries = new ArrayList<XYSeries>();
			listOfXYSeries.add(xy1s);
			
			if (isSet ("HetTimeWBRelativeExtractableWater.forestFloorRelativeExtractableWater"))
				listOfXYSeries.add(xy2s); // optional

			// Concatenate all water balance maps found in the simulation
			// from root step to reference step
			for (Iterator i = steps.iterator(); i.hasNext();) {
				Step s = (Step) i.next();

				HetScene scene = (HetScene) s.getScene();

				if (scene.waterBalanceMap != null) // root step...
					fullWBMap.putAll(scene.waterBalanceMap);

			}

			// Run daily integration on fullWBMap
			HetWaterBalanceIntegrator wbi = new HetWaterBalanceIntegrator(fullWBMap,
					HetWaterBalanceIntegrator.DAY_LEVEL);
			LinkedHashMap<String, HetWaterBalance> wbMapDaily = wbi.integrate();

			int cptDay = -1;
			int prevYear = -1;

			for (String key : wbMapDaily.keySet()) {
				
				String[] yearMonthDayHourTab = key.split(HetMeteorology.SEP);
				int year = Integer.valueOf(yearMonthDayHourTab[0]);				
				
				// key is a new year
				if (year != prevYear) {
					cptDay = 1;
				}
				
				double time;

				if (Calendar.isLeap(year)) {
					time = year + cptDay/366.0;
				} else {
					time = year + cptDay/365.0;
				}								
				
				HetWaterBalance wb = wbMapDaily.get(key);

				xy1s.addPoint(time, wb.relativeExtractableWater);
				
				if (isSet("HetTimeWBRelativeExtractableWater.forestFloorRelativeExtractableWater")) // optional
					xy2s.addPoint(time, wb.forestFloorRelativeExtractableWater);

				prevYear = year;
				++cptDay;
			}

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetTimeWBRelativeExtractableWater.doExtraction ()", "Exception", e);
			return false;
		}

		upToDate = true;
		return true;
	}

	/**
	 * Returns x and y axes names in this order for a graph where all the
	 * xySeries can be drawn together.
	 */
	public List<String> getAxesNames() {
		Vector v = new Vector();
		v.add(Translator.swap("HetTimeWBRelativeExtractableWater.xLabel"));
		v.add(Translator.swap("HetTimeWBRelativeExtractableWater.yLabel"));
		return v;
	}

	/**
	 * Returns the list of XYSeries.
	 */
	public List<XYSeries> getListOfXYSeries() {
		return listOfXYSeries;
	}

}
