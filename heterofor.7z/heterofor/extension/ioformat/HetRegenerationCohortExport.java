/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2018: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.extension.ioformat;

import java.util.Date;
import java.util.Iterator;

import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.lib.regeneration.RGCohort;
import capsis.lib.regeneration.RGCohortSizeClass;
import capsis.util.StandRecordSet;
import heterofor.model.HetCell;
import heterofor.model.HetCohort;
import heterofor.model.HetCohortSizeClass;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import jeeb.lib.util.Import;
import jeeb.lib.util.Log;
import jeeb.lib.util.Record;
import jeeb.lib.util.Translator;

/**
 * HetRegenerationCohortExport exports the regeneration cohorts in a file.
 *
 * @author M. Jonard, B. Ryelandt, F. de Coligny - October 2018
 */
public class HetRegenerationCohortExport extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// A cohort size class line in the file
	@Import
	static public class ClassLine extends Record {

		public ClassLine() {
			super();
		}

		public ClassLine(String line) throws Exception {
			super(line);
		}

		// public String getSeparator () {return ";";} // to change default "\t"
		// separator
		public int date;

		public int cellId;
		public int cellIGrid;
		public int cellJGrid;

		public int cohortYear;
		public String species;

		public int classId;
		public double heightAvg;
		public double diameterAvg;
		public double dbh;
		public int number;
		public double transmittance;
		public double growthHeight;
		public double energy_Above_MJ;
		public double energy_MJ;
		public double energy_Below_MJ;
		public double interception;
		public double cover;
		
		// fc+mj+fa-28.5.2019
		public double lai;
		public double sla;
		
		public double eTo;
		public double eTr;

		public double leafAreaAvg;
		public double biomassAvg;
		public double meanCrownProjection;
		public double maxCrownProjectionAvg;
		public double yearlyNPPAvg_kgC;
		public double yearlyNPP_kgC;
		public double yearlyGPP_kgC;

	}

	/**
	 * Constructor
	 */
	public HetRegenerationCohortExport() {
		super();
		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		try {
			if (!(referent instanceof HetModel)) {
				return false;
			}

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetRegenerationCohortExport.matchWith ()", "Error in matchWith () (returned false)",
					e);
			return false;
		}

		return true;
	}

	@Override
	public String getName() {
		return Translator.swap("HetRegenerationCohortExport.name");
	}

	@Override
	public String getAuthor() {
		return "M. Jonard, B. Ryelandt, F. de Coligny";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetRegenerationCohortExport.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Export: turns the given Scene into a collection of records In script
	 * mode, save (fileName) must be called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {
		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		// 1. Custom headers
		add(new CommentRecord("Heterofor regeneration cohorts export (HetRegenerationCohortExport) at " + new Date()));
		add(new EmptyRecord());

		// Tree line header
		add(new CommentRecord("Cohort size classes"));

		String TAB = "\t";
		add(new CommentRecord("date" + TAB + " " + "cellId" + TAB + " " + "cellIGrid" + TAB + " " + "cellJGrid" + TAB
				+ " " + "cohortYear" + TAB + " " + "species" + TAB + " " + "classId" + TAB + " " + "heightAvg" + TAB
				+ " " + "diameterAvg" + TAB + " " + "dbh" + TAB + " " + "number" + TAB + " " + "transmittance" + TAB + " " + "growthHeight"
				+ TAB + " " + "energy_Above_MJ" + TAB + " " + "energy_MJ" + TAB + " " + "energy_Below_MJ" + TAB + " "
				+ "interception" + TAB + " " + "cover" + TAB + " " + "lai"  + TAB + " " + "sla"+ TAB + " " + "eTo" + TAB + " " + "eTr" + TAB + " "
				+ "leafAreaAvg" + TAB + " " + "biomassAvg_kgC" + TAB + " " + "meanCrownProjectionAvg" + TAB + " " + "maxCrownProjectionAvg" + TAB + " "
				+ "yearlyNPPAvg_kgC" + TAB + " " + "yearlyNPP_kgC" + TAB + " " + "yearlyGPP_kgC" + TAB));

		// For each step in the scenario from the root, write all trees
		Step step = scene.getStep();
		Project project = step.getProject();
		for (Step st : project.getStepsFromRoot(step)) {

			// add (new EmptyRecord ());
			writeLines((HetScene) st.getScene());

		}

	}

	private void writeLines(HetScene scene) {

		// // Sort the trees on their ids
		// Set sortedTrees = new TreeSet(new GTreeIdComparator());
		// sortedTrees.addAll(scene.getTrees());

		for (Iterator i = scene.getPlot().getCells().iterator(); i.hasNext();) {
			HetCell c = (HetCell) i.next();

			if (c.getCohorts() == null)
				continue; // jump to next

			for (RGCohort co : c.getCohorts().allValues()) {
				HetCohort cohort = (HetCohort) co;

				if (cohort.getSizeClasses() == null)
					continue; // jump to next

				for (RGCohortSizeClass cl : cohort.getSizeClasses()) {
					HetCohortSizeClass klass = (HetCohortSizeClass) cl;

					ClassLine r = new ClassLine();

					r.date = scene.getDate();

					r.cellId = c.getId();
					r.cellIGrid = c.getIGrid();
					r.cellJGrid = c.getJGrid();

					r.cohortYear = cohort.getYear();
					r.species = cohort.getSpecies().niceName;

					r.classId = klass.getId();
					r.heightAvg = klass.getHeightAvg();
					r.diameterAvg = klass.getDiameterAvg();
					r.dbh = klass.getDbh();
					r.number = klass.getNumber();
					r.transmittance = klass.getTransmittance();
					r.growthHeight = klass.getGrowthHeight();
					r.energy_Above_MJ = klass.getEnergy_Above_MJ();
					r.energy_MJ = klass.getEnergy_MJ();
					r.energy_Below_MJ = klass.getEnergy_Below_MJ();
					r.interception = klass.getWaterInterception();
					r.cover = klass.getCover();

					r.lai = klass.getNumber() * klass.getLeafAreaAvg() / c.getArea();
					r.sla = klass.getSla ();
					
					r.eTo = klass.getETo();
					r.eTr = klass.getETr();
					r.leafAreaAvg = klass.getLeafAreaAvg();
					r.biomassAvg = klass.getBiomassAvg_kgC();
					
					r.meanCrownProjection = klass.getMeanCrownProjection ();
					r.maxCrownProjectionAvg = klass.getMaxCrownProjectionAvg();
					
					r.yearlyNPPAvg_kgC = klass.getYearlyNPPAvg_kgC();
					r.yearlyNPP_kgC = klass.getYearlyNPP_kgC();
					r.yearlyGPP_kgC = klass.getYearlyGPP_kgC();
					
					add(r);

				}

			}

		}

	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel m) throws Exception {
		return null;
	}

}
