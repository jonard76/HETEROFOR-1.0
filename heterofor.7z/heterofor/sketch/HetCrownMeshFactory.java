/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.sketch;

import java.util.ArrayList;
import java.util.List;

import javax.vecmath.Point3f;

import jeeb.lib.structure.geometry.mesh.SimpleMesh;

/**
 * An object to build simple mesh instances.
 * 
 * @author F. de Coligny - June 2012, February 2013
 */
public class HetCrownMeshFactory {

	/**
	 * Creates a mesh to represent the given paraboloid. The center of the
	 * paraboloid base is (x0, y0, z0), the 2 base radii are a (on the x axis), b (on the
	 * y axis) and h is the paraboloid height (on the z axis). We build a mesh with 4 * nSectors sectors
	 * and 1* nSlices slices. All the faces are ordered in the trigonometric
	 * order (convenient for further rendering).
	 * 
	 * @author F. Andr�, May 2019, adapted from the original code developed by F. de Coligny for createEllipsoid
	 */
	static public SimpleMesh createParaboloid(double x0, double y0, double z0,
			double a, double b, double h, int nSectors, int nSlices)
			throws Exception {

		if (a == 0)
			throw new Exception(
					"HetCrownMeshFactory.createParaboloid() Error, a must be different than 0");
		if (b == 0)
			throw new Exception(
					"HetCrownMeshFactory.createParaboloid() Error, b must be different than 0");
		if (h == 0)
			throw new Exception(
					"HetCrownMeshFactory.createParaboloid() Error, h must be different than 0");

		a = Math.abs(a);
		b = Math.abs(b);
		h = Math.abs(h);

		List<SimpleMesh> meshList = new ArrayList<SimpleMesh>();

		meshList.add(createParaboloid4th(x0, y0, z0, a, b, h, nSectors, nSlices));
		meshList.add(createParaboloid4th(x0, y0, z0, -a, b, h, nSectors, nSlices));
		meshList.add(createParaboloid4th(x0, y0, z0, -a, -b, h, nSectors, nSlices));
		meshList.add(createParaboloid4th(x0, y0, z0, a, -b, h, nSectors, nSlices));

		// Merge all meshes
		return SimpleMesh.concatenate(meshList); // and purify () ?

	}


	/**
	 * Creates a mesh to represent the given paraboloid 4th. The center of the
	 * paraboloid base is (x0, y0, z0), the 2 base radii are a (on the x axis), b (on the
	 * y axis) and h is the paraboloid height (on the z axis). We can know what part of the paraboloid is
	 * under consideration by testing the signs of a, b. We build a mesh
	 * with nSectors sectors and nSlices slices. All the faces are ordered in
	 * the trigonometric order (convenient for further rendering).
	 * 
	 * @author F. Andr�, May 2019, adapted from the original code developed by F. de Coligny for createEllipsoid8th
	 */
	static public SimpleMesh createParaboloid4th(double x0, double y0,
			double z0, double a, double b, double h, int nSectors, int nSlices)
			throws Exception {
		if (nSectors < 1)
			throw new Exception(
					"HetCrownMeshFactory.createParaboloid4th() Cannot create a paraboloid 4th, nSectors: "
							+ nSectors + " must be >= 1.");
		if (a == 0 || b == 0 || h == 0)
			throw new Exception(
					"HetCrownMeshFactory.createParaboloid4th() Cannot create a paraboloid 4th, a, b and h must be different than 0, a: "
							+ a + " b: " + b + " h: " + h);

		double sector0 = 0;
		if (a < 0 && b > 0)
			sector0 = Math.PI / 2;
		if (a < 0 && b < 0)
			sector0 = Math.PI;
		if (a > 0 && b < 0)
			sector0 = 3 * Math.PI / 2;

		Point3f[] points = new Point3f[(nSectors + 1) * nSlices + 1];
		int[][] faces = new int[nSectors * (nSlices - 1) * 2 + nSectors][3]; // i.e.
																				// triangles

		double sectorAngle = (Math.PI / 2) / nSectors;
		double sliceSize = h / nSlices;
		int p = 0; // an index in points
		int f = 0; // an index in faces

		// Starting point
		for (p = 0; p <= nSlices; p++) {
			// u: sector, v: slice
			double u = sector0;
			double v = p * sliceSize;
			points[p] = getPointInParaboloid(x0, y0, z0, a, b, h, u, v);
			
		}
		int extreme = nSlices;

		// Triangulated slices
		for (int i = 1; i <= nSectors; i++) {
			double u = sector0 + i * sectorAngle;

			for (int j = 0; j < nSlices; j++) {
				double v = j * sliceSize;

				Point3f p0 = getPointInParaboloid(x0, y0, z0, a, b, h, u, v);

				int i0 = p;
				points[i0] = p0;

				int m0 = p - (nSlices + 1);

				if (i > 1)
					m0++; // extreme is only once in points
				int m1 = m0 + 1;

				if (j == 0) { // 1 single triangle
					faces[f++] = new int[] { m0, i0, m1 };

				} else { // 2 triangles
					int m2 = p - 1;
					
					if (j == (nSlices - 1))
						m1 = extreme; // one vertex is extreme
					
					faces[f++] = new int[] { m0, m2, i0 };
					faces[f++] = new int[] { m0, i0, m1 };
				}

				p++;
			}

		}

		SimpleMesh mesh = new SimpleMesh(points, faces);

		return mesh;

	}

	/**
	 * In a paraboloid (x0, y0, z0, a, b, h), calculates the point at the given
	 * u (sector angle) and v (slice level).
	 * 
	 * @author F. Andr�, May 2019
	 */
	static private Point3f getPointInParaboloid(double x0, double y0, double z0,
			double a, double b, double h, double u, double v) {
		double x = x0 + Math.abs(a) * Math.sqrt((h-v)/h) * Math.cos(u);
		double y = y0 + Math.abs(b) * Math.sqrt((h-v)/h) * Math.sin(u);
		double z = z0 + v;
		return new Point3f((float) x, (float) y, (float) z);
	}
	
	/**
	 * Creates a mesh to represent the given cone. The center of the
	 * cone base is (x0, y0, z0), the 2 base radii are a (on the x axis), b (on the
	 * y axis) and h is the cone height (on the z axis). We build a mesh with 4 * nSectors sectors
	 * and 1* nSlices slices. All the faces are ordered in the trigonometric
	 * order (convenient for further rendering).
	 * 
	 * @author F. Andr�, May 2019, adapted from the original code developed by F. de Coligny for createEllipsoid
	 */
	static public SimpleMesh createCone(double x0, double y0, double z0,
			double a, double b, double h, int nSectors, int nSlices)
			throws Exception {

		if (a == 0)
			throw new Exception(
					"HetCrownMeshFactory.createCone() Error, a must be different than 0");
		if (b == 0)
			throw new Exception(
					"HetCrownMeshFactory.createCone() Error, b must be different than 0");
		if (h == 0)
			throw new Exception(
					"HetCrownMeshFactory.createCone() Error, h must be different than 0");

		a = Math.abs(a);
		b = Math.abs(b);
		h = Math.abs(h);

		List<SimpleMesh> meshList = new ArrayList<SimpleMesh>();

		meshList.add(createCone4th(x0, y0, z0, a, b, h, nSectors, nSlices));
		meshList.add(createCone4th(x0, y0, z0, -a, b, h, nSectors, nSlices));
		meshList.add(createCone4th(x0, y0, z0, -a, -b, h, nSectors, nSlices));
		meshList.add(createCone4th(x0, y0, z0, a, -b, h, nSectors, nSlices));

		// Merge all meshes
		return SimpleMesh.concatenate(meshList); // and purify () ?

	}

	/**
	 * Creates a mesh to represent the given cone 4th. The center of the
	 * cone base is (x0, y0, z0), the 2 base radii are a (on the x axis), b (on the
	 * y axis) and h is the cone height (on the z axis). We can know what part of the cone is
	 * under consideration by testing the signs of a, b. We build a mesh
	 * with nSectors sectors and nSlices slices. All the faces are ordered in
	 * the trigonometric order (convenient for further rendering).
	 * 
	 * @author F. Andr�, May 2019, adapted from the original code developed by F. de Coligny for createEllipsoid8th
	 */
	static public SimpleMesh createCone4th(double x0, double y0,
			double z0, double a, double b, double h, int nSectors, int nSlices)
			throws Exception {
		if (nSectors < 1)
			throw new Exception(
					"HetCrownMeshFactory.createCone4th() Cannot create a cone 4th, nSectors: "
							+ nSectors + " must be >= 1.");
		if (a == 0 || b == 0 || h == 0)
			throw new Exception(
					"HetCrownMeshFactory.createCone4th() Cannot create a cone 4th, a, b and h must be different than 0, a: "
							+ a + " b: " + b + " h: " + h);

		double sector0 = 0;
		if (a < 0 && b > 0)
			sector0 = Math.PI / 2;
		if (a < 0 && b < 0)
			sector0 = Math.PI;
		if (a > 0 && b < 0)
			sector0 = 3 * Math.PI / 2;

		Point3f[] points = new Point3f[(nSectors + 1) * nSlices + 1];
		int[][] faces = new int[nSectors * (nSlices - 1) * 2 + nSectors][3]; // i.e.
																				// triangles

		double sectorAngle = (Math.PI / 2) / nSectors;
		double sliceSize = h / nSlices;
		int p = 0; // an index in points
		int f = 0; // an index in faces

		// Starting point
		for (p = 0; p <= nSlices; p++) {
			// u: sector, v: slice
			double u = sector0;
			double v = p * sliceSize;
			points[p] = getPointInCone(x0, y0, z0, a, b, h, u, v);
			
		}
		int extreme = nSlices;

		// Triangulated slices
		for (int i = 1; i <= nSectors; i++) {
			double u = sector0 + i * sectorAngle;

			for (int j = 0; j < nSlices; j++) {
				double v = j * sliceSize;

				Point3f p0 = getPointInCone(x0, y0, z0, a, b, h, u, v);

				int i0 = p;
				points[i0] = p0;

				int m0 = p - (nSlices + 1);

				if (i > 1)
					m0++; // extreme is only once in points
				int m1 = m0 + 1;

				if (j == 0) { // 1 single triangle
					faces[f++] = new int[] { m0, i0, m1 };

				} else { // 2 triangles
					int m2 = p - 1;
					
					if (j == (nSlices - 1))
						m1 = extreme; // one vertex is extreme
					
					faces[f++] = new int[] { m0, m2, i0 };
					faces[f++] = new int[] { m0, i0, m1 };
				}

				p++;
			}

		}

		SimpleMesh mesh = new SimpleMesh(points, faces);

		return mesh;

	}

	/**
	 * In a cone (x0, y0, z0, a, b, h), calculates the point at the given
	 * u (sector angle) and v (slice level).
	 * 
	 * @author F. Andr�, May 2019
	 */
	static private Point3f getPointInCone(double x0, double y0, double z0,
			double a, double b, double h, double u, double v) {
		double x = x0 + Math.abs(a) * (h-v)/h * Math.cos(u);
		double y = y0 + Math.abs(b) * (h-v)/h * Math.sin(u);
		double z = z0 + v;
		return new Point3f((float) x, (float) y, (float) z);
	}

}
